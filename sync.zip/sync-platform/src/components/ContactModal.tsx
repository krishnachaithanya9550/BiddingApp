"use client";

import { useState, type FormEvent } from "react";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { value: "general",     label: "General Inquiry",         icon: "💬" },
  { value: "bug",         label: "Bug Report",              icon: "🐛" },
  { value: "suggestion",  label: "Suggestion / Feedback",   icon: "💡" },
  { value: "partnership", label: "Partnership / Business",  icon: "🤝" },
  { value: "other",       label: "Other",                   icon: "📌" },
];

// Which areas of the site to suggest improvements on (shown only for suggestions)
const SITE_AREAS = [
  "Dashboard",
  "Marketplace",
  "Problems & Proposals",
  "Community / Social",
  "Messages",
  "Developer Profile",
  "Company Dashboard",
  "Leaderboard",
  "Payment / Wallet",
  "Design / UI",
  "Performance",
  "Other",
];

interface Props {
  onClose: () => void;
}

export default function ContactModal({ onClose }: Props) {
  const [name,     setName]     = useState("");
  const [email,    setEmail]    = useState("");
  const [category, setCategory] = useState("general");
  const [subject,  setSubject]  = useState("");
  const [area,     setArea]     = useState("");
  const [message,  setMessage]  = useState("");
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState("");
  const [success,  setSuccess]  = useState(false);

  const isSuggestion = category === "suggestion";

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    const res = await fetch("/api/contact", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, category, subject, message, area }),
    });

    const d = await res.json();
    setLoading(false);

    if (res.ok) {
      setSuccess(true);
    } else {
      setError(d.error ?? "Something went wrong. Please try again.");
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Contact us"
      className="fixed inset-0 z-50 flex items-end justify-center sm:items-center p-4"
      onClick={onClose}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/75 backdrop-blur-sm" aria-hidden="true" />

      {/* Panel */}
      <div
        className="relative w-full max-w-lg rounded-3xl border border-white/10 bg-black/95 shadow-2xl overflow-hidden"
        style={{ boxShadow: "0 0 80px rgba(34,197,94,0.12), 0 32px 64px rgba(0,0,0,0.8)" }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top glow bar */}
        <div
          className="absolute top-0 left-0 right-0 h-px"
          style={{ background: "linear-gradient(90deg, transparent, rgba(34,197,94,0.6), transparent)" }}
        />

        {/* Header */}
        <div className="flex items-start justify-between border-b border-white/8 px-7 py-6">
          <div>
            <h2 className="text-xl font-extrabold text-white">Contact Us</h2>
            <p className="mt-0.5 text-sm text-secondary">
              Questions, ideas, bugs — we read everything.
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="ml-4 shrink-0 rounded-full p-1.5 text-secondary hover:bg-white/8 hover:text-white transition-colors"
          >
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Success state */}
        {success ? (
          <div className="flex flex-col items-center justify-center gap-5 px-7 py-16 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full border border-primary/30 bg-primary/10 text-3xl">
              ✓
            </div>
            <div>
              <p className="text-lg font-extrabold text-white">Message sent!</p>
              <p className="mt-1 text-sm text-secondary max-w-xs">
                Thanks for reaching out. We&apos;ll get back to you at <span className="text-white font-medium">{email}</span>{" "}
                as soon as possible.
              </p>
            </div>
            <button
              onClick={onClose}
              className="mt-2 rounded-full border border-white/10 px-6 py-2.5 text-sm font-semibold text-secondary hover:border-primary/30 hover:text-primary transition-colors"
            >
              Close
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="overflow-y-auto max-h-[75vh]">
            <div className="px-7 py-6 space-y-5">

              {/* Name + Email */}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-secondary/70 mb-1.5">
                    Your Name <span className="text-primary">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Jane Smith"
                    className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/40 outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-secondary/70 mb-1.5">
                    Email <span className="text-primary">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="jane@example.com"
                    className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/40 outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-colors"
                  />
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-secondary/70 mb-2">
                  What is this about? <span className="text-primary">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {CATEGORIES.map((c) => (
                    <button
                      key={c.value}
                      type="button"
                      onClick={() => setCategory(c.value)}
                      className={cn(
                        "flex items-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-semibold transition-all text-left",
                        category === c.value
                          ? "border-primary/40 bg-primary/10 text-primary"
                          : "border-white/8 bg-white/3 text-secondary hover:border-white/20 hover:text-white"
                      )}
                    >
                      <span>{c.icon}</span>
                      <span className="leading-tight">{c.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Site area — only for suggestions */}
              {isSuggestion && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-secondary/70 mb-1.5">
                    Which part of SYNC? <span className="text-secondary/40">(optional)</span>
                  </label>
                  <select
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-[#0f0f0f] px-4 py-2.5 text-sm text-white outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-colors"
                  >
                    <option value="">Select an area…</option>
                    {SITE_AREAS.map((a) => (
                      <option key={a} value={a}>{a}</option>
                    ))}
                  </select>
                </div>
              )}

              {/* Subject */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-secondary/70 mb-1.5">
                  Subject <span className="text-primary">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={160}
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder={
                    isSuggestion
                      ? "e.g. Add dark mode toggle to dashboard"
                      : "Brief summary of your message"
                  }
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/40 outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-colors"
                />
              </div>

              {/* Message */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-secondary/70 mb-1.5">
                  {isSuggestion ? "Your Suggestion" : "Message"} <span className="text-primary">*</span>
                </label>
                <textarea
                  required
                  rows={5}
                  maxLength={4000}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={
                    isSuggestion
                      ? "Describe what you'd like to see improved or added. The more detail, the better!"
                      : "Tell us what's on your mind…"
                  }
                  className="w-full resize-none rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-secondary/40 outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-colors"
                />
                <p className="mt-1 text-right text-[10px] text-secondary/40">{message.length}/4000</p>
              </div>

              {/* Error */}
              {error && (
                <div className="rounded-xl border border-red-500/20 bg-red-500/8 px-4 py-3 text-sm text-red-400">
                  {error}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="border-t border-white/8 px-7 py-5 flex items-center justify-between gap-4">
              <p className="text-xs text-secondary/50">
                We typically reply within 24–48 hours.
              </p>
              <button
                type="submit"
                disabled={loading}
                className="shrink-0 rounded-full bg-primary px-7 py-2.5 text-sm font-bold text-black hover:opacity-90 disabled:opacity-40 transition-opacity"
              >
                {loading ? "Sending…" : "Send Message"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
