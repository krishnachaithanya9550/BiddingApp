"use client";

import { useState, useEffect } from "react";
import ContactModal from "@/components/ContactModal";

export default function ContactButton() {
  const [open, setOpen] = useState(false);

  // Open via the footer's "Contact" anchor link
  useEffect(() => {
    function onHashChange() {
      if (window.location.hash === "#contact") {
        setOpen(true);
        // Remove the hash so clicking again works
        history.replaceState(null, "", window.location.pathname);
      }
    }
    window.addEventListener("hashchange", onHashChange);
    // Also handle if user landed with #contact
    if (typeof window !== "undefined" && window.location.hash === "#contact") {
      setOpen(true);
      history.replaceState(null, "", window.location.pathname);
    }
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  // Close on Escape
  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) { if (e.key === "Escape") setOpen(false); }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <>
      {/* Floating pill button — fixed bottom-right */}
      <button
        onClick={() => setOpen(true)}
        aria-label="Open contact form"
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2.5 rounded-full border border-primary/30 bg-black/90 px-5 py-3 text-sm font-bold text-primary shadow-lg backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-primary/60 hover:shadow-[0_0_24px_rgba(34,197,94,0.3)]"
        style={{ boxShadow: "0 4px 24px rgba(0,0,0,0.6), 0 0 0 1px rgba(34,197,94,0.15)" }}
      >
        {/* Icon */}
        <svg
          className="h-4 w-4"
          fill="none"
          stroke="currentColor"
          strokeWidth={2}
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"
          />
        </svg>
        Contact Us
      </button>

      {/* Modal */}
      {open && <ContactModal onClose={() => setOpen(false)} />}
    </>
  );
}
