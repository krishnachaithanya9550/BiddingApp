"use client";

import Link from "next/link";
import { useEffect, useRef } from "react";
import { siteConfig } from "@/config/site";

export default function Hero() {
  // Refs for direct DOM mutation (avoids re-renders on every mousemove/scroll)
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const glow1Ref   = useRef<HTMLDivElement>(null);
  const glow2Ref   = useRef<HTMLDivElement>(null);
  const card1Ref   = useRef<HTMLDivElement>(null);
  const card2Ref   = useRef<HTMLDivElement>(null);
  const card3Ref   = useRef<HTMLDivElement>(null);
  const card4Ref   = useRef<HTMLDivElement>(null);
  const mouseRef   = useRef({ x: 0, y: 0 });
  const targetRef  = useRef({ x: 0, y: 0 });
  const rafRef     = useRef<number>(0);

  // ── Mouse parallax + scroll parallax (direct DOM, no state) ──────────────
  useEffect(() => {
    const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

    function onMouse(e: MouseEvent) {
      targetRef.current = {
        x: (e.clientX / window.innerWidth  - 0.5) * 2,
        y: (e.clientY / window.innerHeight - 0.5) * 2,
      };
    }

    function onScroll() {
      if (contentRef.current) {
        contentRef.current.style.transform = `translateY(${-window.scrollY * 0.18}px)`;
      }
    }

    function tick() {
      mouseRef.current.x = lerp(mouseRef.current.x, targetRef.current.x, 0.055);
      mouseRef.current.y = lerp(mouseRef.current.y, targetRef.current.y, 0.055);
      const { x, y } = mouseRef.current;

      if (glow1Ref.current) {
        glow1Ref.current.style.transform = `translate(calc(-50% + ${x * 38}px), calc(-50% + ${y * 38}px))`;
      }
      if (glow2Ref.current) {
        glow2Ref.current.style.transform = `translate(${x * -22}px, ${y * -18}px)`;
      }
      if (card1Ref.current) {
        card1Ref.current.style.transform = `translate(${x * -24}px, ${y * -12}px)`;
      }
      if (card2Ref.current) {
        card2Ref.current.style.transform = `translate(${x * 20}px, ${y * 14}px)`;
      }
      if (card3Ref.current) {
        card3Ref.current.style.transform = `translate(${x * 30}px, ${y * -10}px)`;
      }
      if (card4Ref.current) {
        card4Ref.current.style.transform = `translate(${x * -18}px, calc(-50% + ${y * 24}px))`;
      }

      rafRef.current = requestAnimationFrame(tick);
    }

    window.addEventListener("mousemove", onMouse, { passive: true });
    window.addEventListener("scroll",    onScroll, { passive: true });
    rafRef.current = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener("mousemove", onMouse);
      window.removeEventListener("scroll",    onScroll);
      cancelAnimationFrame(rafRef.current);
    };
  }, []);

  // ── Canvas particle network ───────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let animId: number;

    function resize() {
      if (!canvas) return;
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener("resize", resize, { passive: true });

    type Pt = { x: number; y: number; vx: number; vy: number; r: number };
    const N = window.innerWidth < 768 ? 28 : 55;

    const pts: Pt[] = Array.from({ length: N }, () => ({
      x:  Math.random() * canvas.width,
      y:  Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35,
      r:  Math.random() * 1.4 + 0.5,
    }));

    function draw() {
      if (!canvas || !ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const mxP = (mouseRef.current.x * 0.5 + 0.5) * canvas.width;
      const myP = (mouseRef.current.y * 0.5 + 0.5) * canvas.height;

      for (const p of pts) {
        const dx = mxP - p.x, dy = myP - p.y;
        const d  = Math.hypot(dx, dy);
        if (d < 190 && d > 0) { p.vx += (dx / d) * 0.003; p.vy += (dy / d) * 0.003; }
        p.vx *= 0.99; p.vy *= 0.99;
        p.x   = (p.x + p.vx + canvas.width)  % canvas.width;
        p.y   = (p.y + p.vy + canvas.height) % canvas.height;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(34,197,94,0.55)";
        ctx.fill();
      }

      for (let i = 0; i < pts.length; i++) {
        for (let j = i + 1; j < pts.length; j++) {
          const a = pts[i], b = pts[j];
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          if (d < 115) {
            ctx.beginPath();
            ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
            ctx.strokeStyle = `rgba(34,197,94,${(1 - d / 115) * 0.13})`;
            ctx.lineWidth = 0.7;
            ctx.stroke();
          }
        }
      }
      animId = requestAnimationFrame(draw);
    }

    draw();
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <section
      id="hero"
      className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 text-center"
    >
      {/* ── Particle canvas ──────────────────────────────── */}
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{ opacity: 0.78 }}
      />

      {/* ── Atmospheric glows ────────────────────────────── */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        {/* Primary — lerp mouse-reactive */}
        <div
          ref={glow1Ref}
          className="absolute top-1/2 left-1/2 h-[820px] w-[820px] rounded-full will-change-transform"
          style={{
            background: "radial-gradient(circle, rgba(34,197,94,0.13) 0%, transparent 65%)",
            transform:  "translate(-50%,-50%)",
          }}
        />
        {/* Secondary — lerp mouse-reactive */}
        <div
          ref={glow2Ref}
          className="absolute top-1/4 right-1/4 h-80 w-80 rounded-full blur-[100px] opacity-30 will-change-transform"
          style={{ background: "rgba(34,197,94,0.14)" }}
        />
        {/* Ambient — CSS animated */}
        <div
          className="animate-mesh-1 absolute bottom-1/3 left-[20%] h-60 w-60 rounded-full blur-[80px] opacity-20"
          style={{ background: "rgba(20,184,166,0.16)" }}
        />
        <div
          className="animate-mesh-2 absolute top-2/3 right-[22%] h-44 w-44 rounded-full blur-[60px] opacity-15"
          style={{ background: "rgba(74,222,128,0.12)" }}
        />
      </div>

      {/* ── Grid overlay ─────────────────────────────────── */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 grid-overlay opacity-30" />

      {/* ── Floating 3-D cards (mouse-parallax) ─────────── */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">

        {/* Card 1 – top right: AI Agent Marketplace stats */}
        <div
          ref={card1Ref}
          className="animate-float absolute top-20 right-[8%] hidden lg:block will-change-transform"
          style={{ perspective: "600px" }}
        >
          <div className="w-56 rounded-2xl glass p-5" style={{ transform: "rotateY(-15deg) rotateX(5deg)" }}>
            <div className="mb-3 flex items-center gap-2">
              <span className="text-base">🤖</span>
              <span className="text-xs font-semibold text-secondary">AI Agent Marketplace</span>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-1">
              <div className="rounded-lg bg-white/5 px-2 py-2 text-center">
                <div className="text-lg font-black text-primary">1,240</div>
                <div className="text-[9px] text-secondary uppercase tracking-wide">Agents Listed</div>
              </div>
              <div className="rounded-lg bg-white/5 px-2 py-2 text-center">
                <div className="text-lg font-black text-white">386</div>
                <div className="text-[9px] text-secondary uppercase tracking-wide">Sold Today</div>
              </div>
            </div>
            <div className="mt-3 h-1 rounded-full bg-white/10">
              <div className="h-1 w-3/4 rounded-full bg-primary" />
            </div>
          </div>
        </div>

        {/* Card 2 – bottom left: Active users */}
        <div
          ref={card2Ref}
          className="animate-float-delay absolute bottom-32 left-[6%] hidden lg:block will-change-transform"
          style={{ perspective: "600px" }}
        >
          <div className="w-52 rounded-2xl glass p-5" style={{ transform: "rotateY(15deg) rotateX(-5deg)" }}>
            <div className="mb-3 flex items-center justify-between">
              <span className="text-xs font-semibold text-secondary">Platform Stats</span>
              <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-secondary">👨‍💻 Developers</span>
                <span className="text-xs font-bold text-white">8,400+</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-secondary">🏢 Companies</span>
                <span className="text-xs font-bold text-white">620+</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-secondary">📦 Products</span>
                <span className="text-xs font-bold text-primary">1,240+</span>
              </div>
            </div>
          </div>
        </div>

        {/* Card 3 – top left: Open problems */}
        <div
          ref={card3Ref}
          className="animate-float-slow absolute top-36 left-[10%] hidden xl:block will-change-transform"
          style={{ perspective: "600px" }}
        >
          <div className="w-48 rounded-2xl glass p-4" style={{ transform: "rotateY(12deg) rotateX(8deg)" }}>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-base">💼</span>
              <span className="text-xs font-semibold text-secondary">Open Problems</span>
            </div>
            <div className="text-2xl font-black text-primary mb-0.5">342</div>
            <div className="text-[10px] text-secondary mb-3">problems awaiting proposals</div>
            <div className="flex gap-1">
              {["React", "Python", "AI/ML"].map((tag) => (
                <span key={tag} className="rounded-full border border-primary/20 bg-primary/5 px-1.5 py-0.5 text-[9px] text-primary">{tag}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Card 4 – mid right: Recent proposals */}
        <div
          ref={card4Ref}
          className="animate-float absolute top-1/2 right-[4%] hidden xl:block will-change-transform"
          style={{ perspective: "600px", transform: "translateY(-50%)" }}
        >
          <div className="w-44 rounded-2xl glass p-4" style={{ transform: "rotateY(-10deg) rotateX(-3deg)" }}>
            <div className="text-xs font-semibold text-secondary mb-3">🧠 Latest Proposals</div>
            <div className="space-y-2">
              {[
                { name: "Alex K.", color: "#22c55e", label: "Accepted" },
                { name: "Sara M.", color: "#3b82f6", label: "Pending" },
                { name: "Raj T.",  color: "#a855f7", label: "Pending" },
              ].map(({ name, color, label }) => (
                <div key={name} className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <div className="h-5 w-5 rounded-full flex items-center justify-center text-[9px] font-black text-black" style={{ background: color }}>
                      {name[0]}
                    </div>
                    <span className="text-[10px] text-white">{name}</span>
                  </div>
                  <span className={`text-[9px] font-semibold ${label === "Accepted" ? "text-primary" : "text-secondary"}`}>{label}</span>
                </div>
              ))}
            </div>
            <div className="mt-3 text-[9px] text-secondary">↑ 18 new this week</div>
          </div>
        </div>
      </div>

      {/* ── Main content (scroll parallax) ──────────────── */}
      <div
        ref={contentRef}
        className="relative z-10 flex flex-col items-center gap-6 max-w-5xl will-change-transform"
      >
        {/* Badge */}
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-5 py-2 text-xs font-semibold uppercase tracking-widest text-primary backdrop-blur-sm">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
            Platform live · v{siteConfig.version}
          </span>
        </div>

        {/* Headline */}
        <div className="animate-fade-up-delay">
          <h1 className="text-7xl font-black tracking-tighter text-white sm:text-8xl lg:text-[9rem] leading-none">
            <span className="block">
              <span className="gradient-text-animate">
                {siteConfig.name}
              </span>
            </span>
          </h1>
        </div>

        {/* Sub-headline */}
        <div className="animate-fade-up-delay-2">
          <p className="max-w-2xl text-lg font-medium leading-relaxed text-secondary sm:text-xl">
            Where{" "}
            <span className="text-white font-semibold">companies</span> find{" "}
            <span className="text-primary font-semibold">world-class developers</span>.
            Post challenges. Get proposals. Ship faster.
          </p>
        </div>

        {/* CTA */}
        <div className="animate-fade-up-delay-2 mt-2 flex flex-col items-center gap-4 sm:flex-row">
          <Link
            href="/signup"
            className="btn-glow glow-pulse relative rounded-full bg-primary px-9 py-3.5 text-sm font-bold text-black transition-all duration-300 hover:-translate-y-1"
          >
            Get Started Free
          </Link>
          <Link
            href="#features"
            className="rounded-full border border-white/15 px-9 py-3.5 text-sm font-semibold text-secondary transition-all duration-300 hover:border-primary/40 hover:text-white hover:-translate-y-0.5"
          >
            How it works ↓
          </Link>
        </div>

      </div>

    </section>
  );
}
