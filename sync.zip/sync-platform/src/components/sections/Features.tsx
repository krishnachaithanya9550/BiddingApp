"use client";

import type React from "react";
import { useRef } from "react";
import Section from "@/components/ui/Section";
import { useScrollReveal } from "@/lib/useScrollReveal";

const features = [
  {
    icon: "🏢",
    title: "Post Challenges",
    description: "Companies post real problems with budgets and deadlines. Get targeted proposals from vetted developers within hours.",
    accent: "from-green-500/10 to-emerald-500/5",
  },
  {
    icon: "⚡",
    title: "Instant Matching",
    description: "Our platform connects the right developer to the right problem. No middlemen, no overhead — just results.",
    accent: "from-blue-500/10 to-cyan-500/5",
  },
  {
    icon: "💼",
    title: "Manage Proposals",
    description: "Companies review, accept, or reject submissions with full context. Developers track every application in real-time.",
    accent: "from-violet-500/10 to-purple-500/5",
  },
  {
    icon: "🔒",
    title: "Secure by Design",
    description: "Role-based access, JWT sessions, and bcrypt hashing built in. Your data stays safe without extra configuration.",
    accent: "from-rose-500/10 to-pink-500/5",
  },
  {
    icon: "🚀",
    title: "Ship Faster",
    description: "Skip weeks of talent search. Post today, receive quality proposals tomorrow, and ship by next week.",
    accent: "from-amber-500/10 to-orange-500/5",
  },
  {
    icon: "🌍",
    title: "Real-Time Status",
    description: "Live submission tracking, problem status updates, and dashboard analytics keep every stakeholder informed.",
    accent: "from-teal-500/10 to-green-500/5",
  },
];

export default function Features() {
  const sectionRef = useRef<HTMLDivElement>(null);
  useScrollReveal(sectionRef as React.RefObject<Element | null>);

  return (
    <Section id="features" className="py-32 border-t border-white/5">
      <div ref={sectionRef}>
        {/* Section header */}
        <div className="mb-20 text-center reveal" data-delay="0">
          <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-primary">Why SYNC</p>
          <h2 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
            Everything you need to{" "}
            <span className="gradient-text-animate">close the gap</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-secondary">
            A full-stack platform connecting companies with developers. No noise, just signal.
          </p>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, i) => (
            <div
              key={feature.title}
              className={`reveal group relative rounded-2xl border border-white/8 bg-gradient-to-br ${feature.accent} p-8 tilt-card cursor-default`}
              data-delay={`${i * 0.08}`}
              style={{ transformStyle: "preserve-3d" }}
              onMouseMove={onTiltMove}
              onMouseLeave={onTiltLeave}
            >
              {/* Shimmer */}
              <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 shimmer" />
              {/* Bottom accent */}
              <div className="absolute bottom-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <span
                className="feat-icon relative mb-5 block text-3xl"
                style={{ display: "inline-block", transformStyle: "preserve-3d" }}
              >
                {feature.icon}
              </span>
              <h3 className="relative mb-2 text-lg font-bold text-white">{feature.title}</h3>
              <p className="relative text-sm leading-relaxed text-secondary">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

// ── JS mouse-tilt handlers ───────────────────────────────────────────────────
function onTiltMove(e: React.MouseEvent<HTMLDivElement>) {
  const card = e.currentTarget;
  const rect  = card.getBoundingClientRect();
  const x = (e.clientX - rect.left) / rect.width  - 0.5;
  const y = (e.clientY - rect.top)  / rect.height - 0.5;
  card.style.transition = "transform 0.08s ease, box-shadow 0.08s ease";
  card.style.transform  = `perspective(700px) rotateX(${y * -14}deg) rotateY(${x * 14}deg) translateY(-10px) scale(1.025)`;
  card.style.boxShadow  = `${x * 28}px ${y * 28}px 55px rgba(34,197,94,0.22), 0 0 0 1px rgba(34,197,94,0.28)`;
  const icon = card.querySelector<HTMLSpanElement>(".feat-icon");
  if (icon) { icon.style.transition = "transform 0.08s ease"; icon.style.transform = "translateZ(30px) scale(1.25)"; }
}
function onTiltLeave(e: React.MouseEvent<HTMLDivElement>) {
  const card = e.currentTarget;
  card.style.transition = "transform 0.55s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.55s ease";
  card.style.transform  = "";
  card.style.boxShadow  = "";
  const icon = card.querySelector<HTMLSpanElement>(".feat-icon");
  if (icon) { icon.style.transition = "transform 0.55s cubic-bezier(0.34,1.56,0.64,1)"; icon.style.transform = ""; }
}
