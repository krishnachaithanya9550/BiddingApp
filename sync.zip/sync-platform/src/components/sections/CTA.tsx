"use client";

import type React from "react";
import Link from "next/link";
import { useEffect, useRef } from "react";
import Section from "@/components/ui/Section";
import { useScrollReveal } from "@/lib/useScrollReveal";

export default function CTA() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const orb1Ref    = useRef<HTMLDivElement>(null);
  const orb2Ref    = useRef<HTMLDivElement>(null);

  useScrollReveal(sectionRef as React.RefObject<Element | null>);

  // Scroll-driven parallax for background orbs
  useEffect(() => {
    function onScroll() {
      if (!orb1Ref.current || !orb2Ref.current) return;
      const section = sectionRef.current?.parentElement;
      if (!section) return;
      const rect   = section.getBoundingClientRect();
      const ratio  = 1 - Math.max(0, Math.min(1, rect.top / window.innerHeight));
      orb1Ref.current.style.transform = `translate(-50%, ${-ratio * 25}px) scale(${1 + ratio * 0.15})`;
      orb2Ref.current.style.transform = `translate(50%, ${ratio * 25}px)  scale(${1 + ratio * 0.1})`;
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <Section id="get-started" className="py-32 border-t border-white/5">
      <div ref={sectionRef}>
        <div className="gradient-border reveal relative overflow-hidden rounded-3xl bg-black px-8 py-24 text-center sm:px-16">
          {/* Radial bg */}
          <div
            className="absolute inset-0 rounded-3xl"
            style={{ background: "radial-gradient(ellipse at 50% -10%, rgba(34,197,94,0.18) 0%, transparent 65%)" }}
          />
          <div className="absolute inset-0 grid-overlay opacity-30 rounded-3xl" />

          {/* Parallax orbs */}
          <div
            ref={orb1Ref}
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 -left-24 h-56 w-56 rounded-full blur-[80px] will-change-transform"
            style={{ background: "rgba(34,197,94,0.2)" }}
          />
          <div
            ref={orb2Ref}
            aria-hidden="true"
            className="pointer-events-none absolute -bottom-24 -right-24 h-56 w-56 rounded-full blur-[80px] will-change-transform"
            style={{ background: "rgba(34,197,94,0.14)" }}
          />

          {/* Extra depth rings */}
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="h-[500px] w-[500px] rounded-full border border-primary/5 animate-mesh-1" />
          </div>
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="h-[350px] w-[350px] rounded-full border border-primary/8 animate-mesh-2" />
          </div>

          <div className="relative">
            <p className="reveal mb-3 text-xs font-semibold uppercase tracking-widest text-primary" data-delay="0.1">
              Get Started Today
            </p>
            <h2 className="reveal mb-6 text-4xl font-extrabold tracking-tight text-white sm:text-5xl" data-delay="0.2">
              Ready to bridge the gap?
            </h2>
            <p className="reveal mx-auto mb-10 max-w-lg text-secondary" data-delay="0.3">
              Join as a company to find exceptional developers, or sign up as a developer to work
              on real-world problems that matter.
            </p>
            <div className="reveal flex flex-col items-center justify-center gap-4 sm:flex-row" data-delay="0.4">
              <Link
                href="/signup"
                className="btn-glow glow-pulse rounded-full bg-primary px-10 py-4 text-sm font-bold text-black transition-all duration-300 hover:-translate-y-1"
              >
                Create Free Account
              </Link>
              <Link
                href="/login"
                className="rounded-full border border-white/15 px-10 py-4 text-sm font-semibold text-secondary transition-all duration-300 hover:border-white/30 hover:text-white"
              >
                Sign In
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}
