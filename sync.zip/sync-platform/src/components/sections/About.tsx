"use client";

import type React from "react";
import { useEffect, useRef, useState } from "react";
import Section from "@/components/ui/Section";
import { useScrollReveal } from "@/lib/useScrollReveal";

const stats = [
  { num: 2,   suffix: "x",  label: "Faster hiring",       icon: "🚀" },
  { num: 100, suffix: "%",  label: "Transparent process",  icon: "🔍" },
  { num: 0,   suffix: "",   label: "Hidden fees",          icon: "✔️" },
  { num: 24,  suffix: "h",  label: "First proposals",      icon: "⚡" },
];

const steps = [
  { n: "01", title: "Company posts a problem", desc: "Describe the challenge, set budget & deadline, add required skills." },
  { n: "02", title: "Developers submit proposals", desc: "Qualified developers browse open problems and submit detailed proposals." },
  { n: "03", title: "Review & accept", desc: "Company reviews all proposals, accepts the best fit, and the work begins." },
];

// ── Animated counter component ───────────────────────────────────────────────
function CountUp({ num, suffix, active }: { num: number; suffix: string; active: boolean }) {
  const spanRef  = useRef<HTMLSpanElement>(null);
  const didRun   = useRef(false);

  useEffect(() => {
    if (!active || didRun.current || num === 0) return;
    didRun.current = true;
    const el = spanRef.current;
    if (!el) return;
    const dur   = 1400;
    const start = performance.now();
    const step  = (now: number) => {
      const t     = Math.min((now - start) / dur, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      el.textContent = Math.round(eased * num) + suffix;
      if (t < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [active, num, suffix]);

  return <span ref={spanRef}>{num === 0 ? `0${suffix}` : `0${suffix}`}</span>;
}

export default function About() {
  const sectionRef  = useRef<HTMLDivElement>(null);
  const stepsRef    = useRef<HTMLDivElement>(null);
  const statsRef    = useRef<HTMLDivElement>(null);
  const [statsActive, setStatsActive] = useState(false);

  useScrollReveal(sectionRef as React.RefObject<Element | null>);

  // Trigger number counters when stats come into view
  useEffect(() => {
    const el = statsRef.current;
    if (!el) return;
    const io = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setStatsActive(true); io.disconnect(); }
    }, { threshold: 0.3 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  // Animate the step connector lines
  useEffect(() => {
    const el = stepsRef.current;
    if (!el) return;
    const io = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        el.querySelectorAll(".step-connector").forEach((c) => c.classList.add("draw"));
        io.disconnect();
      }
    }, { threshold: 0.3 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <Section id="about" className="py-32 border-t border-white/5">
      <div ref={sectionRef}>
        {/* Header */}
        <div className="mb-20 text-center reveal" data-delay="0">
          <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-primary">How it works</p>
          <h2 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
            Simple. Transparent.{" "}
            <span className="gradient-text-animate">Effective.</span>
          </h2>
        </div>

        {/* Steps */}
        <div ref={stepsRef} className="mb-24 grid gap-6 sm:grid-cols-3">
          {steps.map((step, i) => (
            <div
              key={step.n}
              className={`relative ${i % 2 === 0 ? "reveal-left" : "reveal"}`}
              data-delay={`${i * 0.15}`}
            >
              {/* Animated connector line */}
              {i < steps.length - 1 && (
                <div className="absolute top-8 left-full z-10 w-full h-px hidden sm:block overflow-hidden">
                  <div
                    className="step-connector h-px w-full"
                    style={{ background: "linear-gradient(90deg, rgba(34,197,94,0.4), transparent)" }}
                  />
                </div>
              )}
              <div className="card-3d glass rounded-2xl p-8 h-full">
                <span
                  className="mb-4 block text-4xl font-black"
                  style={{ color: "rgba(34,197,94,0.3)" }}
                >
                  {step.n}
                </span>
                <h3 className="mb-2 font-bold text-white">{step.title}</h3>
                <p className="text-sm text-secondary leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div ref={statsRef} className="grid grid-cols-2 gap-5 sm:grid-cols-4">
          {stats.map((s, i) => (
            <div
              key={s.label}
              className="reveal-scale"
              data-delay={`${i * 0.1}`}
            >
              <div className="card-3d relative overflow-hidden rounded-2xl border border-white/8 bg-gradient-to-br from-primary/5 to-transparent p-8 text-center">
                <div className="absolute -top-4 -right-4 text-5xl opacity-10">{s.icon}</div>
                <p
                  className="text-4xl font-black"
                  style={{ color: "#22c55e", textShadow: "0 0 24px rgba(34,197,94,0.45)" }}
                >
                  <CountUp num={s.num} suffix={s.suffix} active={statsActive} />
                </p>
                <p className="mt-2 text-xs text-secondary uppercase tracking-wider">{s.label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}
