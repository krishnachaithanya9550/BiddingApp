﻿"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { signOut } from "@/lib/auth";
import { cn } from "@/lib/utils";
import Avatar from "@/components/ui/Avatar";
import type { UserRole, UserProfile } from "@/types";

const LAST_SEEN_KEY = "sync_last_seen";

const ROLE_CONFIG: Record<UserRole, { label: string; color: string; dot: string; nav: { label: string; href: string; icon: string }[] }> = {
  "0": {
    label: "Admin",
    color: "border-red-500/30 bg-red-500/10 text-red-400",
    dot: "bg-red-400",
    nav: [
      { label: "Overview",    href: "/admin",       icon: "🛡️" },
      { label: "Users",       href: "/admin",       icon: "👥" },
    ],
  },
  "user": {
    label: "Developer",
    color: "border-primary/30 bg-primary/10 text-primary",
    dot: "bg-primary",
    nav: [
      { label: "Dashboard",   href: "/developer-dashboard",                    icon: "⚡" },
      { label: "Browse Jobs", href: "/developer-dashboard",                    icon: "🔍" },
      { label: "Community",   href: "/developer-dashboard/community",          icon: "👥" },
      { label: "Messages",    href: "/developer-dashboard/messages",           icon: "💬" },
      { label: "Leaderboard", href: "/leaderboard",                             icon: "🏆" },
      { label: "Marketplace", href: "/marketplace",                            icon: "🛒" },
      { label: "My Listings", href: "/developer-dashboard/marketplace",        icon: "📦" },
    ],
  },
  "company": {
    label: "Company",
    color: "border-blue-500/30 bg-blue-500/10 text-blue-400",
    dot: "bg-blue-400",
    nav: [
      { label: "Dashboard",    href: "/company-dashboard",             icon: "🏢" },
      { label: "Post Problem", href: "/post-problem",                  icon: "➕" },
      { label: "Submissions",  href: "/submissions",                   icon: "📋" },
      { label: "Leaderboard",  href: "/leaderboard",                   icon: "🏆" },
      { label: "Marketplace",  href: "/marketplace",                   icon: "🛒" },
    ],
  },
};

interface DashboardShellProps {
  profile: UserProfile;
  children: React.ReactNode;
}

export default function DashboardShell({ profile, children }: DashboardShellProps) {
  const router = useRouter();
  const pathname = usePathname();
  const config = ROLE_CONFIG[profile.role];

  const [unreadSenders, setUnreadSenders] = useState<{ id: string; name: string; avatar_color: string; avatar_emoji?: string; count: number }[]>([]);
  const [newJobs, setNewJobs] = useState(0);
  const [newSubmissions, setNewSubmissions] = useState(0);
  const [bellOpen, setBellOpen] = useState(false);
  const bellRef = useRef<HTMLDivElement>(null);
  const sinceRef = useRef<string>(
    typeof window !== "undefined"
      ? (localStorage.getItem(LAST_SEEN_KEY) ?? new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString())
      : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
  );

  const unreadMsgs = unreadSenders.reduce((s, x) => s + x.count, 0);
  const totalBadge = unreadMsgs + newJobs + newSubmissions;

  // Close bell dropdown on outside click
  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (bellRef.current && !bellRef.current.contains(e.target as Node)) {
        setBellOpen(false);
      }
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  useEffect(() => {
    async function poll() {
      try {
        const since = sinceRef.current;
        const res = await fetch(`/api/notifications?since=${encodeURIComponent(since)}`);
        if (!res.ok) return;
        const data = await res.json();
        setUnreadSenders(data.unread_senders ?? []);
        setNewJobs(data.new_jobs ?? 0);
        setNewSubmissions(data.new_submissions ?? 0);
      } catch { /* ignore */ }
    }
    poll();
    const interval = setInterval(poll, 10_000);
    return () => clearInterval(interval);
  }, [profile.role]);

  // Clear message badge when on messages page
  useEffect(() => {
    if (pathname === "/developer-dashboard/messages") setUnreadSenders([]);
    // Clear job badge when on developer dashboard
    if (pathname === "/developer-dashboard") {
      setNewJobs(0);
      sinceRef.current = new Date().toISOString();
      localStorage.setItem(LAST_SEEN_KEY, sinceRef.current);
    }
    // Clear submissions badge when on submissions page
    if (pathname === "/submissions") {
      setNewSubmissions(0);
      sinceRef.current = new Date().toISOString();
      localStorage.setItem(LAST_SEEN_KEY, sinceRef.current);
    }
  }, [pathname]);

  function handleBellClick() {
    setBellOpen((v) => !v);
    // Mark as seen so job/submission "since" advances
    sinceRef.current = new Date().toISOString();
    localStorage.setItem(LAST_SEEN_KEY, sinceRef.current);
  }

  async function handleSignOut() {
    await signOut();
    router.push("/login");
  }

  // Notification items to show in dropdown
  const notifications: { id: string; icon: string; label: string; sub: string; href: string; count: number; color: string; dot?: string; emoji?: string }[] = [];
  // One entry per unread message sender (red) — deep-links directly into that conversation
  for (const sender of unreadSenders) {
    notifications.push({
      id: `msg-${sender.id}`,
      icon: "💬",
      label: sender.name,
      sub: `${sender.count} unread message${sender.count > 1 ? "s" : ""}`,
      href: `/developer-dashboard/messages?with=${sender.id}`,
      count: sender.count,
      color: "text-red-400",
      dot: sender.avatar_color || "#22c55e",
        emoji: sender.avatar_emoji || "",
    });
  }
  if (newJobs > 0) notifications.push({
    id: "jobs", icon: "🔔", label: "New Job Postings", sub: `${newJobs} new problem${newJobs > 1 ? "s" : ""} posted`,
    href: "/developer-dashboard", count: newJobs, color: "text-yellow-400",
  });
  if (newSubmissions > 0) notifications.push({
    id: "subs", icon: "📋", label: "New Submissions", sub: `${newSubmissions} new submission${newSubmissions > 1 ? "s" : ""}`,
    href: "/submissions", count: newSubmissions, color: "text-blue-400",
  });

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Sidebar for desktop */}
      <aside className="fixed left-0 top-0 bottom-0 w-64 hidden lg:flex flex-col border-r border-white/5 bg-black/60 z-40" style={{ backdropFilter: "blur(20px)" }}>
        {/* Logo + bell */}
        <div className="flex items-center gap-3 px-6 py-5 border-b border-white/5">
          <Link href="/" className="text-xl font-black tracking-widest text-primary neon-text">SYNC</Link>
          <span className={cn("rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider", config.color)}>
            {config.label}
          </span>
          <div ref={bellRef} className="relative ml-auto">
            <button
              onClick={handleBellClick}
              className="relative flex h-8 w-8 items-center justify-center rounded-full border border-white/10 text-secondary hover:border-white/20 hover:text-white transition-colors"
            >
              🔔
              {totalBadge > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-0.5 text-[9px] font-black text-white">
                  {totalBadge > 9 ? "9+" : totalBadge}
                </span>
              )}
            </button>
            {bellOpen && (
              <div className="absolute left-0 top-10 w-80 rounded-2xl border border-white/10 bg-black/95 shadow-2xl z-50 overflow-hidden" style={{ backdropFilter: "blur(20px)" }}>
                <div className="border-b border-white/5 px-4 py-3 flex items-center justify-between">
                  <p className="text-xs font-bold uppercase tracking-widest text-secondary/60">Notifications</p>
                  {totalBadge > 0 && <span className="rounded-full bg-red-500/20 px-2 py-0.5 text-[10px] font-bold text-red-400">{totalBadge} new</span>}
                </div>
                {notifications.length === 0 ? (
                  <div className="px-4 py-8 text-center">
                    <p className="text-3xl mb-2">✓</p>
                    <p className="text-sm font-semibold text-white">All caught up!</p>
                    <p className="text-xs text-secondary mt-1">No new notifications.</p>
                  </div>
                ) : (
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.map((n) => (
                      <Link key={n.id} href={n.href} onClick={() => setBellOpen(false)}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors border-b border-white/5 last:border-0">
                        {n.dot ? (
                          <Avatar name={n.label} avatar_color={n.dot} avatar_emoji={n.emoji} size="md"
                            className="h-9 w-9 text-sm shrink-0" />
                        ) : (
                          <span className="text-xl">{n.icon}</span>
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-white truncate">{n.label}</p>
                          <p className={cn("text-xs", n.color)}>{n.sub}</p>
                        </div>
                        <span className={cn(
                          "flex h-5 min-w-5 items-center justify-center rounded-full text-[10px] font-black text-white px-1",
                          n.color === "text-red-400" ? "bg-red-500" : n.color === "text-yellow-400" ? "bg-yellow-400 text-black" : "bg-blue-500"
                        )}>
                          {n.count}
                        </span>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-6 flex flex-col gap-1">
          {config.nav.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium transition-all duration-200",
                pathname === item.href
                  ? "bg-primary/10 text-primary border border-primary/20"
                  : "text-secondary hover:bg-white/5 hover:text-white"
              )}
            >
              <span className="text-base">{item.icon}</span>
              {item.label}
              {item.href === "/developer-dashboard/messages" && unreadMsgs > 0 && (
                <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-black text-white">
                  {unreadMsgs > 99 ? "99+" : unreadMsgs}
                </span>
              )}
              {item.href === "/developer-dashboard" && newJobs > 0 && (
                <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-yellow-400 px-1 text-[10px] font-black text-black">
                  {newJobs > 99 ? "99+" : newJobs}
                </span>
              )}
              {item.href === "/submissions" && newSubmissions > 0 && (
                <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-blue-400 px-1 text-[10px] font-black text-black">
                  {newSubmissions > 99 ? "99+" : newSubmissions}
                </span>
              )}
            </Link>
          ))}
        </nav>

        {/* User info */}
        <div className="border-t border-white/5 px-4 py-5">
          <Link
            href={profile.role === "user" ? "/developer-dashboard/profile" : "#"}
            className={cn(
              "flex items-center gap-3 mb-3 rounded-xl transition-colors",
              profile.role === "user" && "hover:bg-white/5 cursor-pointer -mx-1 px-1 py-1"
            )}
          >
            <div className="relative">
              <Avatar
                name={profile.name}
                avatar_color={profile.avatar_color}
                avatar_emoji={profile.avatar_emoji}
                size="md"
              />
              <span className={cn("absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full border border-black", config.dot)} />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-white truncate">{profile.name}</p>
              <p className="text-xs text-secondary truncate">{profile.email}</p>
            </div>
          </Link>
          <button
            onClick={handleSignOut}
            className="w-full rounded-xl border border-white/8 py-2 text-xs font-semibold text-secondary transition-all duration-200 hover:border-red-500/30 hover:bg-red-500/10 hover:text-red-400"
          >
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="lg:hidden sticky top-0 z-40 border-b border-white/5 px-4 py-3 flex items-center justify-between" style={{ background: "rgba(0,0,0,0.9)", backdropFilter: "blur(20px)" }}>
        <div className="flex items-center gap-2">
          <span className="text-lg font-black tracking-widest text-primary">SYNC</span>
          <span className={cn("rounded-full border px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider", config.color)}>
            {config.label}
          </span>
        </div>
        <div className="flex items-center gap-3">
          {/* Bell for mobile */}
          <div ref={bellRef} className="relative">
            <button onClick={handleBellClick}
              className="relative flex h-8 w-8 items-center justify-center rounded-full border border-white/10 text-base text-secondary hover:text-white transition-colors">
              🔔
              {totalBadge > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-0.5 text-[9px] font-black text-white">
                  {totalBadge > 9 ? "9+" : totalBadge}
                </span>
              )}
            </button>
            {bellOpen && (
              <div className="absolute right-0 top-10 w-80 rounded-2xl border border-white/10 bg-black/95 shadow-2xl z-50 overflow-hidden" style={{ backdropFilter: "blur(20px)" }}>
                <div className="border-b border-white/5 px-4 py-3 flex items-center justify-between">
                  <p className="text-xs font-bold uppercase tracking-widest text-secondary/60">Notifications</p>
                  {totalBadge > 0 && <span className="rounded-full bg-red-500/20 px-2 py-0.5 text-[10px] font-bold text-red-400">{totalBadge} new</span>}
                </div>
                {notifications.length === 0 ? (
                  <div className="px-4 py-8 text-center">
                    <p className="text-3xl mb-2">✓</p>
                    <p className="text-sm font-semibold text-white">All caught up!</p>
                    <p className="text-xs text-secondary mt-1">No new notifications.</p>
                  </div>
                ) : (
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.map((n) => (
                      <Link key={n.id} href={n.href} onClick={() => setBellOpen(false)}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors border-b border-white/5 last:border-0">
                        {n.dot ? (
                          <Avatar name={n.label} avatar_color={n.dot} avatar_emoji={n.emoji} size="md"
                            className="h-9 w-9 text-sm shrink-0" />
                        ) : (
                          <span className="text-xl">{n.icon}</span>
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-white truncate">{n.label}</p>
                          <p className={cn("text-xs", n.color)}>{n.sub}</p>
                        </div>
                        <span className={cn(
                          "flex h-5 min-w-5 items-center justify-center rounded-full text-[10px] font-black text-white px-1",
                          n.color === "text-red-400" ? "bg-red-500" : n.color === "text-yellow-400" ? "bg-yellow-400 text-black" : "bg-blue-500"
                        )}>
                          {n.count}
                        </span>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
          {/* Nav icons */}
          {config.nav.map((item) => (
            <Link key={item.label} href={item.href} className="relative text-lg">
              {item.icon}
              {item.href === "/developer-dashboard/messages" && unreadMsgs > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-0.5 text-[9px] font-black text-black">
                  {unreadMsgs > 9 ? "9+" : unreadMsgs}
                </span>
              )}
            </Link>
          ))}
          <button onClick={handleSignOut} className="text-xs text-secondary border border-white/10 rounded-lg px-3 py-1.5 hover:text-white transition-colors ml-1">
            Out
          </button>
        </div>
      </header>

      {/* Main content */}
      <main className="lg:pl-64">
        <div className="mx-auto max-w-6xl px-4 py-8 sm:px-8 sm:py-12">
          {children}
        </div>
      </main>
    </div>
  );
}
