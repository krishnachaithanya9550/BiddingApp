import { cn } from "@/lib/utils";

const SIZE_MAP = {
  sm:  "h-7 w-7 text-xs",
  md:  "h-8 w-8 text-sm",
  lg:  "h-10 w-10 text-base",
  xl:  "h-20 w-20 text-3xl",
};

interface AvatarProps {
  name: string;
  avatar_color?: string | null;
  avatar_emoji?: string | null;
  size?: keyof typeof SIZE_MAP;
  className?: string;
  style?: React.CSSProperties;
}

export default function Avatar({ name, avatar_color, avatar_emoji, size = "md", className, style }: AvatarProps) {
  const color = avatar_color || "#22c55e";
  return (
    <div
      className={cn("rounded-full flex items-center justify-center font-black shrink-0", SIZE_MAP[size], className)}
      style={{ background: color, ...style }}
    >
      {avatar_emoji ? (
        <span style={{ lineHeight: 1 }}>{avatar_emoji}</span>
      ) : (
        <span className="text-black">{(name || "?").charAt(0).toUpperCase()}</span>
      )}
    </div>
  );
}
