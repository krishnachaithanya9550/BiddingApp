import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";
import { randomUUID } from "crypto";

function getSession(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySession(token);
}

/** Ensure a wallet row exists for a user and return current balance */
function ensureWallet(userId: string): number {
  const db = getDb();
  const row = db
    .prepare("SELECT balance FROM wallets WHERE user_id = ?")
    .get(userId) as { balance: number } | undefined;
  if (!row) {
    db.prepare(
      "INSERT INTO wallets (user_id, balance) VALUES (?, 0)"
    ).run(userId);
    return 0;
  }
  return row.balance;
}

// GET /api/wallet — return balance + transaction history for the current user
export async function GET(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const balance = ensureWallet(session.sub);
  const db = getDb();

  const transactions = db
    .prepare(
      `SELECT id, type, amount, description, reference_id, created_at
       FROM wallet_transactions
       WHERE user_id = ?
       ORDER BY created_at DESC
       LIMIT 50`
    )
    .all(session.sub);

  return NextResponse.json({ balance, transactions });
}

// POST /api/wallet — top-up wallet via dummy payment gateway
// Body: { amount, card_number, expiry_month, expiry_year, cvv }
export async function POST(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const body = await req.json();
  const { amount, card_number, expiry_month, expiry_year, cvv } = body;

  // Input validation
  if (!amount || typeof amount !== "number" || amount <= 0) {
    return NextResponse.json({ error: "Amount must be greater than 0." }, { status: 400 });
  }
  if (amount > 10_000) {
    return NextResponse.json({ error: "Maximum single top-up is $10,000." }, { status: 400 });
  }
  if (!card_number || !expiry_month || !expiry_year || !cvv) {
    return NextResponse.json({ error: "All card details are required." }, { status: 400 });
  }

  // --- Dummy gateway validation ---
  const cardDigits = String(card_number).replace(/\s/g, "");
  if (!/^\d{13,19}$/.test(cardDigits)) {
    return NextResponse.json({ error: "Invalid card number." }, { status: 400 });
  }
  if (!/^\d{2}$/.test(String(expiry_month)) || !/^\d{2,4}$/.test(String(expiry_year))) {
    return NextResponse.json({ error: "Invalid expiry date." }, { status: 400 });
  }
  if (!/^\d{3,4}$/.test(String(cvv))) {
    return NextResponse.json({ error: "Invalid CVV." }, { status: 400 });
  }

  // Dummy decline rules: card ending in 0000 or starting with 4000
  if (cardDigits.endsWith("0000") || cardDigits.startsWith("4000")) {
    return NextResponse.json({
      error: "Card declined. Please try a different card.",
      gateway_code: "CARD_DECLINED",
    }, { status: 402 });
  }

  const gatewayTransactionId = `gw_${randomUUID().replace(/-/g, "").slice(0, 24)}`;

  // Credit wallet
  const db = getDb();
  ensureWallet(session.sub);

  db.prepare(
    `UPDATE wallets
     SET balance = balance + ?, updated_at = datetime('now')
     WHERE user_id = ?`
  ).run(amount, session.sub);

  const txId = randomUUID();
  db.prepare(
    `INSERT INTO wallet_transactions (id, user_id, type, amount, description, reference_id)
     VALUES (?, ?, 'topup', ?, ?, ?)`
  ).run(txId, session.sub, amount, `Top-up via card •••• ${cardDigits.slice(-4)}`, gatewayTransactionId);

  const { balance } = db
    .prepare("SELECT balance FROM wallets WHERE user_id = ?")
    .get(session.sub) as { balance: number };

  return NextResponse.json({
    success: true,
    balance,
    transaction_id: gatewayTransactionId,
    message: `$${amount.toFixed(2)} added to your wallet.`,
  });
}
