import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { randomUUID } from "crypto";

const VALID_CATEGORIES = ["general", "bug", "suggestion", "partnership", "other"] as const;

// Basic email regex — only validates format, not deliverability
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// POST /api/contact — public, no auth required
export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const { name, email, category, subject, message, area } = body as Record<string, string>;

  // ── Validation ─────────────────────────────────────────────────────────────
  if (!name?.trim() || name.trim().length < 2) {
    return NextResponse.json({ error: "Please enter your name (at least 2 characters)." }, { status: 400 });
  }
  if (!email?.trim() || !EMAIL_RE.test(email.trim())) {
    return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
  }
  if (!VALID_CATEGORIES.includes(category as typeof VALID_CATEGORIES[number])) {
    return NextResponse.json({ error: "Invalid category." }, { status: 400 });
  }
  if (!subject?.trim() || subject.trim().length < 3) {
    return NextResponse.json({ error: "Please enter a subject (at least 3 characters)." }, { status: 400 });
  }
  if (!message?.trim() || message.trim().length < 10) {
    return NextResponse.json({ error: "Please enter a message (at least 10 characters)." }, { status: 400 });
  }

  // Length caps to prevent abuse
  if (name.trim().length > 100)    return NextResponse.json({ error: "Name is too long." }, { status: 400 });
  if (subject.trim().length > 160) return NextResponse.json({ error: "Subject is too long." }, { status: 400 });
  if (message.trim().length > 4000) return NextResponse.json({ error: "Message is too long (max 4000 characters)." }, { status: 400 });

  const db = getDb();
  const id = randomUUID();

  db.prepare(`
    INSERT INTO contact_submissions (id, name, email, category, subject, message, area)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    name.trim(),
    email.trim().toLowerCase(),
    category,
    subject.trim(),
    message.trim(),
    (area ?? "").trim().slice(0, 200),
  );

  return NextResponse.json({ success: true, id });
}

// GET /api/contact — admin only: list all submissions
export async function GET(req: NextRequest) {
  // Simple admin check via cookie — matches your auth pattern
  const { verifySession, COOKIE_NAME } = await import("@/lib/session");
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session || session.role !== "0") {
    return NextResponse.json({ error: "Admin only." }, { status: 403 });
  }

  const db = getDb();
  const rows = db.prepare(
    "SELECT * FROM contact_submissions ORDER BY created_at DESC LIMIT 200"
  ).all();

  return NextResponse.json({ submissions: rows });
}
