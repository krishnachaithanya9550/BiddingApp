import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

// GET /api/notifications?since=ISO_DATE
// Returns: { unread_senders: [{id,name,avatar_color,avatar_emoji,count}], new_jobs, new_submissions }
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ unread_senders: [], new_jobs: 0, new_submissions: 0 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ unread_senders: [], new_jobs: 0, new_submissions: 0 });

  const db = getDb();

  // Unread DMs per sender (developers only)
  let unread_senders: { id: string; name: string; avatar_color: string; avatar_emoji: string; count: number }[] = [];
  if (session.role === "user") {
    try {
      unread_senders = db.prepare(`
        SELECT u.id, u.name, u.avatar_color, COALESCE(u.avatar_emoji,'') as avatar_emoji, COUNT(*) as count
        FROM messages m
        JOIN users u ON u.id = m.sender_id
        WHERE m.recipient_id = ? AND m.is_read = 0 AND m.group_id IS NULL
        GROUP BY u.id
        ORDER BY MAX(m.created_at) DESC
      `).all(session.sub) as { id: string; name: string; avatar_color: string; avatar_emoji: string; count: number }[];
    } catch { /* is_read column may not exist yet */ }
  }

  const since = req.nextUrl.searchParams.get("since");

  // New job postings since last-seen (developers only)
  let new_jobs = 0;
  if (session.role === "user" && since) {
    const row = db.prepare(
      "SELECT COUNT(*) as c FROM problems WHERE status = 'open' AND created_at > ?"
    ).get(since) as { c: number };
    new_jobs = row?.c ?? 0;
  }

  // New submissions for company users
  let new_submissions = 0;
  if (session.role === "company" && since) {
    const row = db.prepare(`
      SELECT COUNT(*) as c FROM submissions s
      JOIN problems p ON p.id = s.problem_id
      WHERE p.company_id = ? AND s.created_at > ?
    `).get(session.sub, since) as { c: number };
    new_submissions = row?.c ?? 0;
  }

  return NextResponse.json({ unread_senders, new_jobs, new_submissions });
}
