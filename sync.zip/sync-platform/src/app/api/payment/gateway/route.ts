/**
 * Dummy Payment Gateway — simulates a real payment processor.
 *
 * Test cards:
 *   4242 4242 4242 4242  → always succeeds
 *   4111 1111 1111 1111  → succeeds
 *   4000 0000 0000 0002  → declined (starts with 4000)
 *   Any card ending 0000 → declined
 *
 * Any other 13-19 digit card number is treated as approved.
 */

import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { randomUUID } from "crypto";

// POST /api/payment/gateway
// Body: { card_number, expiry_month, expiry_year, cvv, amount, currency? }
export async function POST(req: NextRequest) {
  // Require authentication to prevent abuse
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const body = await req.json();
  const { card_number, expiry_month, expiry_year, cvv, amount, currency = "USD" } = body;

  // ── Validation ────────────────────────────────────────────────────────────
  if (!card_number || !expiry_month || !expiry_year || !cvv) {
    return NextResponse.json(
      { success: false, message: "All card fields are required.", transaction_id: "", charged_amount: 0 },
      { status: 400 }
    );
  }

  const cardDigits = String(card_number).replace(/\s+/g, "");
  if (!/^\d{13,19}$/.test(cardDigits)) {
    return NextResponse.json(
      { success: false, message: "Invalid card number format.", transaction_id: "", charged_amount: 0 },
      { status: 400 }
    );
  }

  if (!/^\d{2}$/.test(String(expiry_month))) {
    return NextResponse.json(
      { success: false, message: "Invalid expiry month.", transaction_id: "", charged_amount: 0 },
      { status: 400 }
    );
  }

  if (!/^\d{2}(\d{2})?$/.test(String(expiry_year))) {
    return NextResponse.json(
      { success: false, message: "Invalid expiry year.", transaction_id: "", charged_amount: 0 },
      { status: 400 }
    );
  }

  if (!/^\d{3,4}$/.test(String(cvv))) {
    return NextResponse.json(
      { success: false, message: "Invalid CVV.", transaction_id: "", charged_amount: 0 },
      { status: 400 }
    );
  }

  if (typeof amount !== "number" || amount <= 0) {
    return NextResponse.json(
      { success: false, message: "Amount must be greater than 0.", transaction_id: "", charged_amount: 0 },
      { status: 400 }
    );
  }

  // ── Expiry check ──────────────────────────────────────────────────────────
  const now = new Date();
  const expMonth = parseInt(expiry_month, 10);
  const rawYear  = String(expiry_year);
  const expYear  = rawYear.length === 2
    ? 2000 + parseInt(rawYear, 10)
    : parseInt(rawYear, 10);

  if (
    expMonth < 1 || expMonth > 12 ||
    expYear < now.getFullYear() ||
    (expYear === now.getFullYear() && expMonth < now.getMonth() + 1)
  ) {
    return NextResponse.json(
      { success: false, message: "Card has expired.", transaction_id: "", charged_amount: 0 },
      { status: 402 }
    );
  }

  // ── Dummy decline rules ───────────────────────────────────────────────────
  if (cardDigits.endsWith("0000") || cardDigits.startsWith("4000")) {
    return NextResponse.json(
      {
        success: false,
        message: "Your card was declined. Please try a different card.",
        transaction_id: "",
        charged_amount: 0,
        gateway_code: "CARD_DECLINED",
      },
      { status: 402 }
    );
  }

  // ── Approve ───────────────────────────────────────────────────────────────
  const transactionId = `gw_${randomUUID().replace(/-/g, "").slice(0, 24)}`;

  return NextResponse.json({
    success: true,
    transaction_id: transactionId,
    message: `Payment of ${currency} ${amount.toFixed(2)} approved.`,
    charged_amount: amount,
    last4: cardDigits.slice(-4),
    currency,
  });
}
