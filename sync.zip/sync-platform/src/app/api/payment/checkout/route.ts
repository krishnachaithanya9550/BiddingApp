import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";
import { randomUUID } from "crypto";

function getSession(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySession(token);
}

/**
 * POST /api/payment/checkout
 *
 * Processes the current user's cart using their wallet balance.
 * All-or-nothing: if balance is insufficient the whole checkout is rejected.
 *
 * Response: { success, purchased, total, new_balance }
 */
export async function POST(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const db = getDb();

  // ── Load cart ──────────────────────────────────────────────────────────────
  const cartItems = db.prepare(`
    SELECT
      ci.id   AS cart_item_id,
      ci.listing_id,
      l.title,
      l.price,
      l.seller_id,
      l.status AS listing_status
    FROM cart_items ci
    JOIN marketplace_listings l ON l.id = ci.listing_id
    WHERE ci.user_id = ?
  `).all(session.sub) as Array<{
    cart_item_id: string;
    listing_id: string;
    title: string;
    price: number;
    seller_id: string;
    listing_status: string;
  }>;

  if (cartItems.length === 0) {
    return NextResponse.json({ error: "Your cart is empty." }, { status: 400 });
  }

  // Filter out unavailable listings
  const available = cartItems.filter((i) => i.listing_status === "active");
  const unavailable = cartItems.filter((i) => i.listing_status !== "active");

  if (available.length === 0) {
    return NextResponse.json({
      error: "All items in your cart are no longer available.",
    }, { status: 400 });
  }

  // Compute total (free items are $0 — still process them)
  const total = available.reduce((s, i) => s + i.price, 0);

  // ── Check / ensure wallet ─────────────────────────────────────────────────
  const walletRow = db
    .prepare("SELECT balance FROM wallets WHERE user_id = ?")
    .get(session.sub) as { balance: number } | undefined;

  const currentBalance = walletRow?.balance ?? 0;

  if (!walletRow) {
    db.prepare("INSERT INTO wallets (user_id, balance) VALUES (?, 0)").run(session.sub);
  }

  // Paid items need sufficient wallet balance
  const paidTotal = available.reduce((s, i) => s + (i.price > 0 ? i.price : 0), 0);
  if (paidTotal > 0 && currentBalance < paidTotal) {
    return NextResponse.json({
      error: `Insufficient wallet balance. You need $${paidTotal.toFixed(2)} but only have $${currentBalance.toFixed(2)}.`,
      required: paidTotal,
      balance: currentBalance,
    }, { status: 402 });
  }

  // ── Atomic transaction ────────────────────────────────────────────────────
  const checkout = db.transaction(() => {
    const purchased: string[] = [];

    for (const item of available) {
      // Skip if already purchased (shouldn't normally happen but guard it)
      const already = db
        .prepare("SELECT id FROM purchases WHERE buyer_id = ? AND listing_id = ?")
        .get(session.sub, item.listing_id);
      if (already) continue;

      // Record purchase
      const purchaseId = randomUUID();
      db.prepare(`
        INSERT INTO purchases (id, buyer_id, listing_id, price_paid)
        VALUES (?, ?, ?, ?)
      `).run(purchaseId, session.sub, item.listing_id, item.price);

      // Deduct from wallet (only for paid items)
      if (item.price > 0) {
        db.prepare(`
          UPDATE wallets
          SET balance = balance - ?, updated_at = datetime('now')
          WHERE user_id = ?
        `).run(item.price, session.sub);

        // Log wallet transaction
        db.prepare(`
          INSERT INTO wallet_transactions (id, user_id, type, amount, description, reference_id)
          VALUES (?, ?, 'purchase', ?, ?, ?)
        `).run(
          randomUUID(),
          session.sub,
          item.price,
          `Purchase: ${item.title}`,
          purchaseId
        );
      }

      // Remove from cart
      db.prepare("DELETE FROM cart_items WHERE id = ?").run(item.cart_item_id);

      purchased.push(item.listing_id);
    }

    // Remove unavailable items from cart too
    for (const item of unavailable) {
      db.prepare("DELETE FROM cart_items WHERE id = ?").run(item.cart_item_id);
    }

    return purchased;
  });

  const purchased = checkout();

  const { balance: newBalance } = db
    .prepare("SELECT balance FROM wallets WHERE user_id = ?")
    .get(session.sub) as { balance: number };

  return NextResponse.json({
    success: true,
    purchased: purchased.length,
    total,
    new_balance: newBalance,
    skipped: unavailable.length,
  });
}
