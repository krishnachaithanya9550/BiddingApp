import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

// ─── GET /api/community — list all developers with profile + rank ─────────────
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const db = getDb();

  // Get all developers ordered by contributions (leaderboard rank)
  const rows = db.prepare(`
    SELECT id, name, email, bio, skills, experience, github_url, linkedin_url,
           portfolio_url, location, hourly_rate, working_status, avatar_color, avatar_emoji,
           contributions, created_at
    FROM users
    WHERE role = 'user'
    ORDER BY contributions DESC, created_at ASC
  `).all() as Record<string, unknown>[];

  // Build leaderboard rank + hydrate JSON fields + add friendship_status for caller
  const friendships = db.prepare(`
    SELECT id, requester_id, addressee_id, status
    FROM friendships
    WHERE requester_id = ? OR addressee_id = ?
  `).all(session.sub, session.sub) as { id: string; requester_id: string; addressee_id: string; status: string }[];

  const developers = rows.map((u, idx) => {
    const fs = friendships.find(
      (f) => f.requester_id === u.id || f.addressee_id === u.id
    );
    let friendship_status: string = "none";
    let friendship_id: string | null = null;
    if (fs) {
      friendship_id = fs.id;
      if (fs.status === "accepted") friendship_status = "accepted";
      else if (fs.requester_id === session.sub) friendship_status = "pending_sent";
      else friendship_status = "pending_received";
    }

    return {
      ...u,
      skills:     safeParseJson(u.skills as string, []),
      experience: safeParseJson(u.experience as string, []),
      rank: idx + 1,
      friendship_status,
      friendship_id,
    };
  });

  return NextResponse.json({ developers });
}

function safeParseJson(val: string, fallback: unknown) {
  try { return JSON.parse(val); } catch { return fallback; }
}
