import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Hero from "@/components/sections/Hero";
import Features from "@/components/sections/Features";
import About from "@/components/sections/About";
import CTA from "@/components/sections/CTA";
import ContactButton from "@/components/ContactButton";

const TICKER_ITEMS = [
  "⚡ Ship Faster",
  "🔒 Secure by Design",
  "🌍 Real-Time Tracking",
  "🧠 AI-Powered Matching",
  "💼 Zero Middlemen",
  "🚀 24h First Proposals",
  "✔️ No Hidden Fees",
  "🤝 Trusted by Teams",
];

function TickerBand() {
  const items = [...TICKER_ITEMS, ...TICKER_ITEMS]; // duplicate for seamless loop
  return (
    <div
      aria-hidden="true"
      className="relative overflow-hidden border-y border-white/5 py-4 select-none"
      style={{ background: "rgba(34,197,94,0.03)" }}
    >
      {/* Fade masks left/right */}
      <div className="pointer-events-none absolute inset-y-0 left-0 w-32 z-10"
        style={{ background: "linear-gradient(to right, #000, transparent)" }} />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-32 z-10"
        style={{ background: "linear-gradient(to left, #000, transparent)" }} />

      <div className="ticker-track gap-12">
        {items.map((item, i) => (
          <span key={i} className="shrink-0 text-xs font-semibold uppercase tracking-widest text-secondary/60 whitespace-nowrap">
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function HomePage() {
  return (
    <>
      <Navbar />
      <Hero />
      <TickerBand />
      <Features />
      <About />
      <CTA />
      <Footer />
      <ContactButton />
    </>
  );
}

