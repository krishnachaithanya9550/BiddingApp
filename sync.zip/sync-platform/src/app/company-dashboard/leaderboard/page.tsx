"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import Avatar from "@/components/ui/Avatar";
import { cn } from "@/lib/utils";
import type { DeveloperPublicProfile } from "@/types";

const SCORING_RULES = [
  { icon: "✅", label: "Accepted Submission",  pts: "+50 pts",  color: "text-primary" },
  { icon: "📬", label: "Submit a Proposal",     pts: "+10 pts",  color: "text-blue-400" },
  { icon: "👥", label: "Connect with a Dev",    pts: "+5 pts",   color: "text-purple-400" },
  { icon: "📦", label: "List on Marketplace",   pts: "+15 pts",  color: "text-yellow-400" },
  { icon: "🛒", label: "Marketplace Sale",      pts: "+25 pts",  color: "text-orange-400" },
  { icon: "📝", label: "Complete Profile",      pts: "+20 pts",  color: "text-cyan-400" },
];

const MEDAL: Record<number, { emoji: string; glow: string; ring: string; badge: string }> = {
  1: { emoji: "🥇", glow: "shadow-yellow-400/20",  ring: "border-yellow-400/50",  badge: "bg-yellow-400 text-black" },
  2: { emoji: "🥈", glow: "shadow-gray-300/20",    ring: "border-gray-300/40",    badge: "bg-gray-300 text-black" },
  3: { emoji: "🥉", glow: "shadow-amber-600/20",   ring: "border-amber-600/40",   badge: "bg-amber-600 text-white" },
};

export default function LeaderboardPage() {
  const { profile, loading } = useAuth(["0", "company", "user"]);
  const [developers, setDevelopers] = useState<DeveloperPublicProfile[]>([]);
  const [dataLoading, setDataLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    fetch("/api/community")
      .then((r) => r.ok ? r.json() : { developers: [] })
      .then((d: { developers?: DeveloperPublicProfile[] }) => {
        setDevelopers(d.developers ?? []);
        setDataLoading(false);
      })
      .catch(() => setDataLoading(false));
  }, [profile]);

  if (loading || !profile) return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
    </div>
  );

  const myEntry = profile.role === "user" ? developers.find((d) => d.id === profile.id) : null;
  const top3    = developers.slice(0, 3);
  const rest    = developers.slice(3);

  return (
    <DashboardShell profile={profile}>
      {/* ── Header ── */}
      <div className="mb-8 flex items-end justify-between flex-wrap gap-4">
        <div>
          <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-yellow-400">Rankings</p>
          <h1 className="text-3xl font-extrabold text-white">Developer Leaderboard</h1>
          <p className="mt-1 text-secondary text-sm">Earn points by contributing — climb the ranks.</p>
        </div>
        {myEntry && (
          <div className="flex items-center gap-3 rounded-2xl border border-primary/20 bg-primary/5 px-4 py-2.5">
            <Avatar name={myEntry.name} avatar_color={myEntry.avatar_color} avatar_emoji={myEntry.avatar_emoji} size="sm" />
            <div>
              <p className="text-xs text-secondary">Your rank</p>
              <p className="text-lg font-black text-primary">#{myEntry.rank}</p>
            </div>
            <div className="border-l border-white/10 pl-3">
              <p className="text-xs text-secondary">Points</p>
              <p className="text-lg font-black text-white">{myEntry.contributions ?? 0}</p>
            </div>
          </div>
        )}
      </div>

      {/* ── How to earn points ── */}
      <div className="mb-8 rounded-2xl border border-white/8 bg-white/3 p-5">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-base">💡</span>
          <p className="text-sm font-bold text-white">How to earn points</p>
          <span className="ml-auto rounded-full border border-white/10 px-2.5 py-0.5 text-[10px] text-secondary">Scoring Guide</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {SCORING_RULES.map((rule) => (
            <div key={rule.label} className="flex items-center gap-2.5 rounded-xl border border-white/5 bg-black/30 px-3 py-2.5">
              <span className="text-base shrink-0">{rule.icon}</span>
              <div className="min-w-0 flex-1">
                <p className="text-xs text-white truncate">{rule.label}</p>
              </div>
              <span className={cn("shrink-0 text-xs font-black", rule.color)}>{rule.pts}</span>
            </div>
          ))}
        </div>
        <p className="mt-3 text-[11px] text-secondary/60 leading-relaxed">
          Points are updated in real-time. Accepted solutions carry the most weight — focus on quality submissions to rise quickly.
        </p>
      </div>

      {/* ── Top 3 Podium ── */}
      {!dataLoading && top3.length >= 3 && (
        <div className="mb-8">
          <p className="mb-4 text-[10px] font-bold uppercase tracking-widest text-secondary/60">Top Contributors</p>
          {/* Podium order: 2nd · 1st · 3rd */}
          <div className="grid grid-cols-3 gap-3">
            {([top3[1], top3[0], top3[2]] as DeveloperPublicProfile[]).map((dev, podiumIdx) => {
              const actualRank = podiumIdx === 0 ? 2 : podiumIdx === 1 ? 1 : 3;
              const m = MEDAL[actualRank];
              const isMe = dev.id === profile.id;
              return (
                <div
                  key={dev.id}
                  className={cn(
                    "relative flex flex-col items-center rounded-2xl border p-5 text-center transition-all",
                    actualRank === 1 ? "mt-0 shadow-xl " + m.glow : "mt-6",
                    m.ring,
                    isMe && "ring-2 ring-primary/50"
                  )}
                  style={{ background: actualRank === 1 ? "rgba(250,204,21,0.04)" : "rgba(255,255,255,0.02)" }}
                >
                  {isMe && (
                    <span className="absolute -top-2 left-1/2 -translate-x-1/2 rounded-full bg-primary px-2 py-0.5 text-[9px] font-black text-black">YOU</span>
                  )}
                  <span className="mb-2 text-2xl">{m.emoji}</span>
                  <Avatar name={dev.name} avatar_color={dev.avatar_color} avatar_emoji={dev.avatar_emoji}
                    className={cn("h-14 w-14 text-xl mb-2", actualRank === 1 ? "ring-2 ring-yellow-400/40" : "")} />
                  <p className="font-bold text-white text-sm truncate w-full">{dev.name}</p>
                  <p className="mt-2 text-2xl font-black text-primary">{dev.contributions ?? 0}</p>
                  <p className="text-[10px] text-secondary tracking-wider">pts</p>
                  <span className={cn("mt-2 rounded-full px-2.5 py-0.5 text-[10px] font-bold", m.badge)}>
                    #{actualRank}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Full ranking list ── */}
      <div>
        <p className="mb-3 text-[10px] font-bold uppercase tracking-widest text-secondary/60">All Rankings</p>
        {dataLoading ? (
          <div className="space-y-2">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-14 rounded-2xl border border-white/5 bg-white/3 animate-pulse" />
            ))}
          </div>
        ) : developers.length === 0 ? (
          <div className="rounded-2xl border border-white/8 bg-white/3 p-12 text-center">
            <p className="text-4xl mb-3">🏆</p>
            <p className="text-white font-semibold">No developers yet</p>
            <p className="text-xs text-secondary mt-1">Be the first to join and earn points!</p>
          </div>
        ) : (
          <div className="space-y-1.5">
            {developers.map((dev) => {
              const isMe = dev.id === profile.id;
              const m = MEDAL[dev.rank];
              return (
                <div
                  key={dev.id}
                  className={cn(
                    "flex items-center gap-4 rounded-2xl border px-4 py-3 transition-all",
                    isMe
                      ? "border-primary/30 bg-primary/5 ring-1 ring-primary/20"
                      : "border-white/5 bg-white/[0.02] hover:border-white/10 hover:bg-white/3"
                  )}
                >
                  {/* Rank */}
                  <div className={cn(
                    "shrink-0 flex h-8 w-8 items-center justify-center rounded-full text-xs font-black",
                    m ? m.badge : "bg-white/5 text-secondary"
                  )}>
                    {m ? m.emoji : `#${dev.rank}`}
                  </div>

                  {/* Avatar */}
                  <Avatar name={dev.name} avatar_color={dev.avatar_color} avatar_emoji={dev.avatar_emoji} size="md" className="shrink-0" />

                  {/* Name */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className={cn("font-semibold truncate", isMe ? "text-primary" : "text-white")}>
                        {dev.name}
                      </p>
                      {isMe && <span className="shrink-0 rounded-full bg-primary/20 px-1.5 py-0 text-[9px] font-black text-primary">YOU</span>}
                    </div>
                    <p className="text-[11px] text-secondary">Rank #{dev.rank}</p>
                  </div>

                  {/* Points bar */}
                  <div className="hidden sm:flex flex-col items-end gap-1 shrink-0 w-32">
                    <p className="text-sm font-black text-white">{dev.contributions ?? 0}<span className="text-[10px] font-normal text-secondary ml-1">pts</span></p>
                    <div className="h-1 w-full rounded-full bg-white/10">
                      <div
                        className={cn("h-1 rounded-full transition-all", isMe ? "bg-primary" : "bg-white/30")}
                        style={{ width: `${Math.min(100, Math.round(((dev.contributions ?? 0) / (developers[0]?.contributions || 1)) * 100))}%` }}
                      />
                    </div>
                  </div>

                  {/* Mobile pts */}
                  <p className="sm:hidden shrink-0 font-black text-white text-sm">{dev.contributions ?? 0}<span className="text-[10px] font-normal text-secondary ml-0.5">pts</span></p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </DashboardShell>
  );
}


