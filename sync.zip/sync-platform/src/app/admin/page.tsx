﻿"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import { cn } from "@/lib/utils";
import ContributionHeatmap from "@/components/ui/ContributionHeatmap";

// ---- Types ------------------------------------------------------------------

interface UserRow {
  id: string;
  name: string;
  email: string;
  role: string;
  created_at: string;
  contributions: number;
  working_status: string;
}

interface ProblemRow {
  id: string;
  title: string;
  description: string;
  budget: number;
  deadline: string;
  skills: string;
  status: string;
  created_at: string;
  company_id: string;
  company_name: string;
  company_email: string;
  submission_count: number;
}

interface PlatformStats {
  problems: number;
  open_problems: number;
  submissions: number;
  accepted_submissions: number;
  pending_submissions: number;
  messages: number;
  friendships: number;
  groups: number;
}

interface TrendPoint { day: string; count: number; }
interface TopDev     { name: string; contributions: number; avatar_color: string; }

interface ChartData {
  signupTrend: TrendPoint[];
  submissionTrend: TrendPoint[];
  topDevs: TopDev[];
}

// ---- Constants --------------------------------------------------------------

const ROLE_LABEL: Record<string, string> = { "0": "Admin", user: "Developer", company: "Company" };
const ROLE_COLOR: Record<string, string> = {
  "0":     "border-red-500/30 bg-red-500/10 text-red-400",
  user:    "border-primary/30 bg-primary/10 text-primary",
  company: "border-blue-500/30 bg-blue-500/10 text-blue-400",
};
const ROLE_OPTIONS = [
  { value: "user",    label: "Developer" },
  { value: "company", label: "Company"   },
  { value: "0",       label: "Admin"     },
];
const PROBLEM_STATUS_OPTIONS = ["open", "closed", "in_review"];
const PROBLEM_STATUS_COLOR: Record<string, string> = {
  open:      "border-primary/30 bg-primary/10 text-primary",
  closed:    "border-white/10 bg-white/5 text-secondary",
  in_review: "border-yellow-500/30 bg-yellow-500/10 text-yellow-400",
};
const HEALTH_CHECKS = [
  { label: "Auth System",  desc: "JWT sessions active"    },
  { label: "SQLite DB",    desc: "Read/write healthy"      },
  { label: "API Routes",   desc: "All endpoints OK"        },
  { label: "Submissions",  desc: "Processing normally"     },
  { label: "Messaging",    desc: "Delivery working"        },
  { label: "Job Board",    desc: "Browse & post active"    },
];

// ---- SVG Charts -------------------------------------------------------------

function BarChart({ data, color = "#22c55e" }: { data: TrendPoint[]; color?: string }) {
  if (!data.length) return <div className="flex h-20 items-center justify-center text-xs text-secondary">No data yet</div>;
  const maxVal = Math.max(...data.map((d) => d.count), 1);
  const W = 320; const H = 80; const gap = 3;
  const barW = (W - gap * (data.length - 1)) / data.length;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-20" preserveAspectRatio="none">
      {data.map((d, i) => {
        const h = Math.max(2, (d.count / maxVal) * (H - 10));
        const x = i * (barW + gap);
        return (
          <g key={i}>
            <rect x={x} y={H - h} width={barW} height={h} rx="2" fill={color} opacity="0.75" />
            {d.count > 0 && (
              <text x={x + barW / 2} y={H - h - 2} textAnchor="middle" fontSize="6.5" fill="white" opacity="0.8">{d.count}</text>
            )}
          </g>
        );
      })}
    </svg>
  );
}

function DonutChart({ segments }: { segments: { value: number; color: string }[] }) {
  const total = segments.reduce((s, seg) => s + seg.value, 0);
  if (total === 0) return <div className="flex h-24 items-center justify-center text-xs text-secondary">No data</div>;
  const R = 36; const cx = 50; const cy = 50; const ir = 22;
  let angle = -Math.PI / 2;
  const paths = segments.filter((s) => s.value > 0).map((seg) => {
    const sweep = (seg.value / total) * 2 * Math.PI;
    const x1 = cx + R * Math.cos(angle); const y1 = cy + R * Math.sin(angle);
    angle += sweep;
    const x2 = cx + R * Math.cos(angle); const y2 = cy + R * Math.sin(angle);
    const ix1 = cx + ir * Math.cos(angle - sweep); const iy1 = cy + ir * Math.sin(angle - sweep);
    const ix2 = cx + ir * Math.cos(angle); const iy2 = cy + ir * Math.sin(angle);
    const large = sweep > Math.PI ? 1 : 0;
    return { d: `M${x1} ${y1} A${R} ${R} 0 ${large} 1 ${x2} ${y2} L${ix2} ${iy2} A${ir} ${ir} 0 ${large} 0 ${ix1} ${iy1} Z`, color: seg.color };
  });
  return (
    <svg viewBox="0 0 100 100" className="w-24 h-24">
      {paths.map((p, i) => <path key={i} d={p.d} fill={p.color} opacity="0.85" />)}
      <text x={cx} y={cy - 3} textAnchor="middle" fontSize="10" fontWeight="bold" fill="white">{total}</text>
      <text x={cx} y={cy + 8} textAnchor="middle" fontSize="5.5" fill="#9ca3af">total</text>
    </svg>
  );
}

function AcceptanceRing({ accepted, pending, rejected }: { accepted: number; pending: number; rejected: number }) {
  const total = accepted + pending + rejected || 1;
  const pct   = Math.round((accepted / total) * 100);
  const R = 38; const cx = 50; const cy = 50;
  const sweep = (accepted / total) * 2 * Math.PI;
  const ex = cx + R * Math.cos(-Math.PI / 2 + sweep);
  const ey = cy + R * Math.sin(-Math.PI / 2 + sweep);
  const large = sweep > Math.PI ? 1 : 0;
  return (
    <svg viewBox="0 0 100 100" className="w-24 h-24">
      <circle cx={cx} cy={cy} r={R} fill="none" stroke="#ffffff10" strokeWidth="10" />
      {accepted > 0 && (
        <path d={`M${cx} ${cy - R} A${R} ${R} 0 ${large} 1 ${ex} ${ey}`} fill="none" stroke="#22c55e" strokeWidth="10" strokeLinecap="round" />
      )}
      <text x={cx} y={cy - 4} textAnchor="middle" fontSize="13" fontWeight="bold" fill="white">{pct}%</text>
      <text x={cx} y={cy + 9} textAnchor="middle" fontSize="5.5" fill="#9ca3af">accepted</text>
    </svg>
  );
}

// ---- Modals -----------------------------------------------------------------

function UserEditModal({
  user,
  onClose,
  onSaved,
}: {
  user: UserRow;
  onClose: () => void;
  onSaved: (updated: Partial<UserRow>) => void;
}) {
  const [name, setName]         = useState(user.name);
  const [email, setEmail]       = useState(user.email);
  const [role, setRole]         = useState(user.role);
  const [password, setPassword] = useState("");
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");

  async function save() {
    setError(""); setLoading(true);
    try {
      const body: Record<string, string> = { id: user.id };
      if (name  !== user.name)  body.name  = name;
      if (email !== user.email) body.email = email;
      if (role  !== user.role)  body.role  = role;
      if (password)             body.password = password;

      const res  = await fetch("/api/admin/users", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) { setError(data.error ?? "Failed."); return; }
      onSaved({ name, email, role });
      onClose();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="relative w-full max-w-md rounded-3xl border border-white/10 bg-black/95 p-7 shadow-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-white">Edit User</h2>
          <button onClick={onClose} className="rounded-full p-1.5 text-secondary hover:text-white transition-colors">
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        {error && <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-sm text-red-400">{error}</div>}

        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Full Name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Email</label>
            <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Role</label>
            <select value={role} onChange={(e) => setRole(e.target.value)} className="w-full rounded-2xl border border-white/10 bg-black px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors">
              {ROLE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">New Password <span className="normal-case font-normal">(leave blank to keep current)</span></label>
            <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="Min 6 characters" className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors placeholder:text-secondary/40" />
          </div>
          {/* Contribution heatmap for developer accounts */}
          {user.role === "user" && (
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Contribution History</label>
              <ContributionHeatmap devId={user.id} compact />
            </div>
          )}
        </div>

        <div className="mt-7 flex gap-3">
          <button onClick={onClose} className="flex-1 rounded-2xl border border-white/10 py-2.5 text-sm font-semibold text-secondary hover:text-white transition-colors">Cancel</button>
          <button onClick={save} disabled={loading} className="flex-1 rounded-2xl bg-primary py-2.5 text-sm font-bold text-black hover:opacity-90 transition-opacity disabled:opacity-40">
            {loading ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

function CreateUserModal({ onClose, onCreated }: { onClose: () => void; onCreated: (u: UserRow) => void }) {
  const [name, setName]         = useState("");
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole]         = useState("user");
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");

  async function create() {
    setError(""); setLoading(true);
    try {
      const res  = await fetch("/api/admin/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, email, password, role }) });
      const data = await res.json();
      if (!res.ok) { setError(data.error ?? "Failed."); return; }
      onCreated({ id: data.id, name, email, role, created_at: new Date().toISOString(), contributions: 0, working_status: "available" });
      onClose();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="relative w-full max-w-md rounded-3xl border border-white/10 bg-black/95 p-7 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-white">Create User</h2>
          <button onClick={onClose} className="rounded-full p-1.5 text-secondary hover:text-white transition-colors">
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        {error && <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-sm text-red-400">{error}</div>}

        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Full Name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors" placeholder="Jane Smith" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Email</label>
            <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors" placeholder="jane@example.com" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Password</label>
            <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors" placeholder="Min 6 characters" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Role</label>
            <select value={role} onChange={(e) => setRole(e.target.value)} className="w-full rounded-2xl border border-white/10 bg-black px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors">
              {ROLE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
        </div>

        <div className="mt-7 flex gap-3">
          <button onClick={onClose} className="flex-1 rounded-2xl border border-white/10 py-2.5 text-sm font-semibold text-secondary hover:text-white transition-colors">Cancel</button>
          <button onClick={create} disabled={loading} className="flex-1 rounded-2xl bg-primary py-2.5 text-sm font-bold text-black hover:opacity-90 transition-opacity disabled:opacity-40">
            {loading ? "Creating..." : "Create User"}
          </button>
        </div>
      </div>
    </div>
  );
}

function ProblemEditModal({
  problem,
  onClose,
  onSaved,
}: {
  problem: ProblemRow;
  onClose: () => void;
  onSaved: (updated: Partial<ProblemRow>) => void;
}) {
  const [title, setTitle]             = useState(problem.title);
  const [description, setDescription] = useState(problem.description);
  const [budget, setBudget]           = useState(String(problem.budget));
  const [deadline, setDeadline]       = useState(problem.deadline);
  const [skills, setSkills]           = useState(() => {
    try { return (JSON.parse(problem.skills) as string[]).join(", "); } catch { return problem.skills; }
  });
  const [status, setStatus]           = useState(problem.status);
  const [loading, setLoading]         = useState(false);
  const [error, setError]             = useState("");

  async function save() {
    setError(""); setLoading(true);
    try {
      const skillsArr = skills.split(",").map((s) => s.trim()).filter(Boolean);
      const body = { id: problem.id, title, description, budget: Number(budget), deadline, skills: skillsArr, status };
      const res  = await fetch("/api/admin/problems", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) { setError(data.error ?? "Failed."); return; }
      onSaved({ title, description, budget: Number(budget), deadline, skills: JSON.stringify(skillsArr), status });
      onClose();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="relative w-full max-w-lg rounded-3xl border border-white/10 bg-black/95 p-7 shadow-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-white">Edit Job Posting</h2>
          <button onClick={onClose} className="rounded-full p-1.5 text-secondary hover:text-white transition-colors">
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        {error && <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-sm text-red-400">{error}</div>}

        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Title</label>
            <input value={title} onChange={(e) => setTitle(e.target.value)} className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Description</label>
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors resize-none" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Budget ($)</label>
              <input value={budget} onChange={(e) => setBudget(e.target.value)} type="number" min="0" className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors" />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Deadline</label>
              <input value={deadline} onChange={(e) => setDeadline(e.target.value)} type="date" className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors" />
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Skills <span className="normal-case font-normal">(comma separated)</span></label>
            <input value={skills} onChange={(e) => setSkills(e.target.value)} className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors" placeholder="React, TypeScript, Node.js" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-secondary uppercase tracking-wider">Status</label>
            <select value={status} onChange={(e) => setStatus(e.target.value)} className="w-full rounded-2xl border border-white/10 bg-black px-4 py-2.5 text-sm text-white outline-none focus:border-primary/40 transition-colors">
              {PROBLEM_STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="mt-7 flex gap-3">
          <button onClick={onClose} className="flex-1 rounded-2xl border border-white/10 py-2.5 text-sm font-semibold text-secondary hover:text-white transition-colors">Cancel</button>
          <button onClick={save} disabled={loading} className="flex-1 rounded-2xl bg-primary py-2.5 text-sm font-bold text-black hover:opacity-90 transition-opacity disabled:opacity-40">
            {loading ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ---- Main Component ---------------------------------------------------------

export default function AdminDashboard() {
  const { profile, loading } = useAuth("0");

  const [users, setUsers]                       = useState<UserRow[]>([]);
  const [problems, setProblems]                 = useState<ProblemRow[]>([]);
  const [stats, setStats]                       = useState<PlatformStats | null>(null);
  const [charts, setCharts]                     = useState<ChartData | null>(null);
  const [dataLoading, setDataLoading]           = useState(true);
  const [problemsLoading, setProblemsLoading]   = useState(false);
  const [activeTab, setActiveTab]               = useState<"overview" | "users" | "postings">("overview");

  // users tab state
  const [userSearch, setUserSearch]             = useState("");
  const [roleFilter, setRoleFilter]             = useState("all");
  const [actionLoading, setActionLoading]       = useState<Record<string, boolean>>({});
  const [userError, setUserError]               = useState("");
  const [confirmDelete, setConfirmDelete]       = useState<UserRow | null>(null);
  const [editingUser, setEditingUser]           = useState<UserRow | null>(null);
  const [showCreateUser, setShowCreateUser]     = useState(false);

  // postings tab state
  const [postingSearch, setPostingSearch]       = useState("");
  const [statusFilter, setStatusFilter]         = useState("all");
  const [postingError, setPostingError]         = useState("");
  const [confirmDeleteProblem, setConfirmDeleteProblem] = useState<ProblemRow | null>(null);
  const [editingProblem, setEditingProblem]     = useState<ProblemRow | null>(null);
  const [problemActionLoading, setProblemActionLoading] = useState<Record<string, boolean>>({});

  async function loadUsers() {
    try {
      const res = await fetch("/api/admin/users");
      if (!res.ok) return;
      const d = await res.json();
      setUsers(d.users ?? []);
      setStats(d.stats ?? null);
      setCharts(d.charts ?? null);
    } finally {
      setDataLoading(false);
    }
  }

  async function loadProblems() {
    setProblemsLoading(true);
    try {
      const res = await fetch("/api/admin/problems");
      if (!res.ok) return;
      const d = await res.json();
      setProblems(d.problems ?? []);
    } finally {
      setProblemsLoading(false);
    }
  }

  useEffect(() => { if (profile) { loadUsers(); loadProblems(); } }, [profile]);

  // ---- User actions ----

  async function deleteUser(user: UserRow) {
    setUserError("");
    setActionLoading((p) => ({ ...p, [user.id]: true }));
    try {
      const res  = await fetch("/api/admin/users", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: user.id }) });
      const data = await res.json();
      if (!res.ok) { setUserError(data.error ?? "Failed."); return; }
      setUsers((prev) => prev.filter((u) => u.id !== user.id));
      setConfirmDelete(null);
    } finally {
      setActionLoading((p) => ({ ...p, [user.id]: false }));
    }
  }

  // ---- Problem actions ----

  async function deleteProblem(problem: ProblemRow) {
    setPostingError("");
    setProblemActionLoading((p) => ({ ...p, [problem.id]: true }));
    try {
      const res  = await fetch("/api/admin/problems", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: problem.id }) });
      const data = await res.json();
      if (!res.ok) { setPostingError(data.error ?? "Failed."); return; }
      setProblems((prev) => prev.filter((p) => p.id !== problem.id));
      setConfirmDeleteProblem(null);
    } finally {
      setProblemActionLoading((p) => ({ ...p, [problem.id]: false }));
    }
  }

  if (loading || !profile) return <LoadingSkeleton />;

  const devCount     = users.filter((u) => u.role === "user").length;
  const companyCount = users.filter((u) => u.role === "company").length;
  const adminCount   = users.filter((u) => u.role === "0").length;
  const acceptedCount = stats?.accepted_submissions ?? 0;
  const pendingCount  = stats?.pending_submissions ?? 0;
  const rejectedCount = Math.max(0, (stats?.submissions ?? 0) - acceptedCount - pendingCount);

  const filteredUsers = users.filter((u) => {
    const matchRole   = roleFilter === "all" || u.role === roleFilter;
    const matchSearch = !userSearch || u.name.toLowerCase().includes(userSearch.toLowerCase()) || u.email.toLowerCase().includes(userSearch.toLowerCase());
    return matchRole && matchSearch;
  });

  const filteredProblems = problems.filter((p) => {
    const matchStatus = statusFilter === "all" || p.status === statusFilter;
    const matchSearch = !postingSearch || p.title.toLowerCase().includes(postingSearch.toLowerCase()) || p.company_name.toLowerCase().includes(postingSearch.toLowerCase());
    return matchStatus && matchSearch;
  });

  return (
    <DashboardShell profile={profile}>

      {/* Header */}
      <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="mb-1 text-[10px] font-semibold uppercase tracking-widest text-red-400">Admin Control Panel</p>
          <h1 className="text-3xl font-extrabold text-white">
            Welcome, <span className="text-red-400">{profile.name}</span>
          </h1>
          <p className="mt-1 text-secondary text-sm">Full platform access. Handle with care.</p>
        </div>
        <div className="flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-2">
          <span className="inline-flex h-2 w-2 rounded-full bg-primary animate-pulse" />
          <span className="text-xs text-primary font-semibold">All systems operational</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-7 flex gap-1 rounded-2xl border border-white/8 bg-white/3 p-1 w-fit">
        {(["overview", "users", "postings"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              "rounded-xl px-5 py-2 text-sm font-semibold capitalize transition-all",
              activeTab === tab ? "bg-red-500/15 text-red-400 border border-red-500/20" : "text-secondary hover:text-white"
            )}
          >
            {tab === "overview" ? "Platform Overview" : tab === "users" ? `Users (${users.length})` : `Postings (${problems.length})`}
          </button>
        ))}
      </div>

      {/* ======= OVERVIEW TAB ======= */}
      {activeTab === "overview" && (
        <div className="space-y-7">
          {/* 8-stat grid */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
            {[
              { label: "Total Users",  value: users.length,                 clr: "text-white"      },
              { label: "Developers",   value: devCount,                      clr: "text-primary"    },
              { label: "Companies",    value: companyCount,                  clr: "text-blue-400"   },
              { label: "Admins",       value: adminCount,                    clr: "text-red-400"    },
              { label: "Problems",     value: stats?.problems ?? "—",        clr: "text-yellow-400" },
              { label: "Open Jobs",    value: stats?.open_problems ?? "—",   clr: "text-primary"    },
              { label: "Submissions",  value: stats?.submissions ?? "—",     clr: "text-purple-400" },
              { label: "Messages",     value: stats?.messages ?? "—",        clr: "text-cyan-400"   },
            ].map((s) => (
              <div key={s.label} className="rounded-2xl border border-white/8 bg-white/3 p-4">
                <p className={cn("mt-1 text-xl font-black", s.clr)}>{dataLoading ? "..." : s.value}</p>
                <p className="mt-0.5 text-[9px] text-secondary uppercase tracking-wider leading-tight">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Trend charts */}
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
            <div className="rounded-2xl border border-white/8 bg-white/3 p-6">
              <p className="mb-0.5 text-[10px] font-bold uppercase tracking-widest text-secondary">Growth</p>
              <p className="mb-4 text-lg font-extrabold text-white">User Signups — Last 14 Days</p>
              {dataLoading ? <Spinner color="primary" /> : (
                <>
                  <BarChart data={charts?.signupTrend ?? []} color="#22c55e" />
                  <div className="mt-2 flex justify-between text-[10px] text-secondary">
                    <span>{charts?.signupTrend?.[0]?.day ?? ""}</span>
                    <span>{charts?.signupTrend?.at(-1)?.day ?? ""}</span>
                  </div>
                </>
              )}
            </div>
            <div className="rounded-2xl border border-white/8 bg-white/3 p-6">
              <p className="mb-0.5 text-[10px] font-bold uppercase tracking-widest text-secondary">Activity</p>
              <p className="mb-4 text-lg font-extrabold text-white">Submissions — Last 14 Days</p>
              {dataLoading ? <Spinner color="purple" /> : (
                <>
                  <BarChart data={charts?.submissionTrend ?? []} color="#a855f7" />
                  <div className="mt-2 flex justify-between text-[10px] text-secondary">
                    <span>{charts?.submissionTrend?.[0]?.day ?? ""}</span>
                    <span>{charts?.submissionTrend?.at(-1)?.day ?? ""}</span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Acceptance ring + Role donut + Top devs */}
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
            <div className="rounded-2xl border border-white/8 bg-white/3 p-6">
              <p className="mb-0.5 text-[10px] font-bold uppercase tracking-widest text-secondary">Quality</p>
              <p className="mb-5 text-lg font-extrabold text-white">Submission Outcomes</p>
              <div className="flex items-center gap-6">
                <AcceptanceRing accepted={acceptedCount} pending={pendingCount} rejected={rejectedCount} />
                <div className="space-y-2.5">
                  {[
                    { l: "Accepted", v: acceptedCount, d: "bg-primary"    },
                    { l: "Pending",  v: pendingCount,  d: "bg-yellow-400" },
                    { l: "Rejected", v: rejectedCount, d: "bg-red-400"    },
                  ].map((r) => (
                    <div key={r.l} className="flex items-center gap-2">
                      <span className={cn("h-2 w-2 rounded-full", r.d)} />
                      <span className="text-secondary text-xs w-16">{r.l}</span>
                      <span className="font-bold text-white text-xs">{r.v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-white/8 bg-white/3 p-6">
              <p className="mb-0.5 text-[10px] font-bold uppercase tracking-widest text-secondary">Community</p>
              <p className="mb-5 text-lg font-extrabold text-white">User Distribution</p>
              <div className="flex items-center gap-6">
                <DonutChart segments={[
                  { value: devCount,     color: "#22c55e" },
                  { value: companyCount, color: "#3b82f6" },
                  { value: adminCount,   color: "#ef4444" },
                ]} />
                <div className="space-y-2.5">
                  {[
                    { l: "Developers", v: devCount,     d: "bg-primary"  },
                    { l: "Companies",  v: companyCount, d: "bg-blue-400" },
                    { l: "Admins",     v: adminCount,   d: "bg-red-400"  },
                  ].map((r) => (
                    <div key={r.l} className="flex items-center gap-2">
                      <span className={cn("h-2 w-2 rounded-full", r.d)} />
                      <span className="text-secondary text-xs w-16">{r.l}</span>
                      <span className="font-bold text-white text-xs">{r.v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-white/8 bg-white/3 p-6">
              <p className="mb-0.5 text-[10px] font-bold uppercase tracking-widest text-secondary">Leaderboard</p>
              <p className="mb-5 text-lg font-extrabold text-white">Top Contributors</p>
              {dataLoading ? (
                <div className="space-y-3">{[...Array(4)].map((_, i) => <div key={i} className="h-8 animate-pulse rounded-xl bg-white/5" />)}</div>
              ) : (charts?.topDevs?.length ?? 0) === 0 ? (
                <p className="text-xs text-secondary">No developers yet.</p>
              ) : (
                <div className="space-y-3">
                  {charts!.topDevs.map((dev, i) => {
                    const pct = Math.round((dev.contributions / (charts!.topDevs[0].contributions || 1)) * 100);
                    const medalColor = ["#f59e0b", "#9ca3af", "#cd7f32"][i] ?? null;
                    return (
                      <div key={i} className="flex items-center gap-3">
                        <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-black" style={{ backgroundColor: medalColor ? medalColor + "30" : "#ffffff10", color: medalColor ?? "#9ca3af" }}>{i + 1}</div>
                        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold overflow-hidden" style={{ backgroundColor: dev.avatar_color || "#22c55e" }}>
                          <span className="text-black">{dev.name.charAt(0).toUpperCase()}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="truncate text-xs font-semibold text-white">{dev.name}</p>
                          <div className="mt-1 h-1 w-full rounded-full bg-white/10"><div className="h-1 rounded-full bg-primary" style={{ width: `${pct}%` }} /></div>
                        </div>
                        <span className="text-xs font-bold text-primary shrink-0">{dev.contributions}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* System Health */}
          <div className="rounded-2xl border border-white/8 bg-white/3 p-6">
            <p className="mb-0.5 text-[10px] font-bold uppercase tracking-widest text-secondary">Infrastructure</p>
            <p className="mb-5 text-lg font-extrabold text-white">System Health</p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {HEALTH_CHECKS.map((check) => (
                <div key={check.label} className="rounded-xl border border-primary/10 bg-primary/5 p-4 flex flex-col gap-2.5">
                  <div className="flex items-center justify-between">
                    <span className="h-2.5 w-2.5 rounded-full bg-primary animate-pulse" />
                    <span className="text-[9px] font-bold text-primary uppercase tracking-wider">Live</span>
                  </div>
                  <p className="text-xs font-bold text-white leading-tight">{check.label}</p>
                  <p className="text-[10px] text-secondary leading-snug">{check.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Extra metrics */}
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {[
              { label: "Friendships",    value: stats?.friendships ?? "—",         clr: "text-cyan-400",   sub: "Accepted connections" },
              { label: "Group Chats",    value: stats?.groups ?? "—",              clr: "text-indigo-400", sub: "Active rooms" },
              { label: "Open Problems",  value: stats?.open_problems ?? "—",       clr: "text-yellow-400", sub: "Awaiting developer" },
              { label: "Pending Review", value: stats?.pending_submissions ?? "—", clr: "text-orange-400", sub: "Awaiting company" },
            ].map((s) => (
              <div key={s.label} className="rounded-2xl border border-white/8 bg-white/3 p-5">
                <p className={cn("text-2xl font-black", s.clr)}>{dataLoading ? "..." : s.value}</p>
                <p className="mt-1 text-xs font-bold text-white">{s.label}</p>
                <p className="text-[10px] text-secondary mt-0.5">{s.sub}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ======= USERS TAB ======= */}
      {activeTab === "users" && (
        <div>
          {userError && <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">{userError}</div>}

          {/* Filters + Create button */}
          <div className="mb-5 flex flex-col gap-3 sm:flex-row">
            <input
              className="flex-1 rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/50 outline-none focus:border-red-500/30 transition-colors"
              value={userSearch}
              onChange={(e) => setUserSearch(e.target.value)}
              placeholder="Search by name or email..."
            />
            <div className="flex flex-wrap gap-2 items-center">
              {["all", "user", "company", "0"].map((r) => (
                <button
                  key={r}
                  onClick={() => setRoleFilter(r)}
                  className={cn(
                    "rounded-full border px-3 py-1.5 text-xs font-semibold transition-all",
                    roleFilter === r ? "border-red-500/30 bg-red-500/10 text-red-400" : "border-white/10 text-secondary hover:border-white/20 hover:text-white"
                  )}
                >
                  {r === "all" ? "All" : ROLE_LABEL[r]}
                </button>
              ))}
              <button
                onClick={() => setShowCreateUser(true)}
                className="ml-auto rounded-2xl border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-bold text-primary hover:bg-primary/20 transition-colors"
              >
                + Create User
              </button>
            </div>
          </div>

          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">All Users</h2>
            <span className="text-xs text-secondary">{filteredUsers.length} of {users.length}</span>
          </div>

          <div className="rounded-2xl border border-white/8 overflow-hidden">
            {dataLoading ? (
              <div className="p-12 text-center"><div className="mx-auto h-8 w-8 rounded-full border-2 border-red-400/20 border-t-red-400 animate-spin" /></div>
            ) : filteredUsers.length === 0 ? (
              <div className="p-12 text-center text-secondary">No users found.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/5 bg-white/3">
                      {["User", "Email", "Role", "Contributions", "Status", "Joined", "Actions"].map((h) => (
                        <th key={h} className="px-5 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-secondary">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((u, i) => {
                      const isSelf    = u.id === profile.id;
                      const isLoading = !!actionLoading[u.id];
                      return (
                        <tr key={u.id} className={cn("border-b border-white/5 transition-colors hover:bg-white/3", i % 2 !== 0 && "bg-white/[0.015]")}>
                          <td className="px-5 py-3.5">
                            <div className="flex items-center gap-2.5">
                              <div className={cn("h-8 w-8 shrink-0 rounded-full flex items-center justify-center text-xs font-bold",
                                u.role === "0" ? "bg-red-500/20 text-red-400" : u.role === "company" ? "bg-blue-500/20 text-blue-400" : "bg-primary/20 text-primary"
                              )}>
                                {u.name.charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <p className="font-medium text-white">{u.name}</p>
                                {isSelf && <p className="text-[10px] text-red-400 font-bold">YOU</p>}
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-3.5 text-secondary text-xs">{u.email}</td>
                          <td className="px-5 py-3.5">
                            <span className={cn("inline-flex rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider", ROLE_COLOR[u.role] ?? "border-white/10 text-secondary")}>
                              {ROLE_LABEL[u.role] ?? u.role}
                            </span>
                          </td>
                          <td className="px-5 py-3.5">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-primary">{u.contributions ?? 0}</span>
                              {(u.contributions ?? 0) > 0 && (
                                <div className="h-1 w-16 rounded-full bg-white/10">
                                  <div className="h-1 rounded-full bg-primary" style={{ width: `${Math.min(100, (u.contributions / 20) * 100)}%` }} />
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="px-5 py-3.5">
                            {u.working_status ? (
                              <span className={cn("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                                u.working_status === "available" ? "border-primary/20 bg-primary/10 text-primary" :
                                u.working_status === "busy"      ? "border-yellow-500/20 bg-yellow-500/10 text-yellow-400" :
                                                                   "border-white/10 text-secondary"
                              )}>
                                <span className={cn("h-1.5 w-1.5 rounded-full",
                                  u.working_status === "available" ? "bg-primary" : u.working_status === "busy" ? "bg-yellow-400" : "bg-secondary"
                                )} />
                                {u.working_status}
                              </span>
                            ) : <span className="text-xs text-secondary/40">-</span>}
                          </td>
                          <td className="px-5 py-3.5 text-secondary text-xs">{new Date(u.created_at).toLocaleDateString()}</td>
                          <td className="px-5 py-3.5">
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setEditingUser(u)}
                                className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-white hover:bg-white/10 transition-colors"
                              >
                                Edit
                              </button>
                              {!isSelf && (
                                <button
                                  onClick={() => setConfirmDelete(u)}
                                  disabled={isLoading}
                                  className="rounded-lg border border-red-500/20 bg-red-500/5 px-2.5 py-1 text-xs text-red-400 hover:bg-red-500/15 transition-colors disabled:opacity-40"
                                >
                                  {isLoading ? "..." : "Delete"}
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======= POSTINGS TAB ======= */}
      {activeTab === "postings" && (
        <div>
          {postingError && <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">{postingError}</div>}

          {/* Filters */}
          <div className="mb-5 flex flex-col gap-3 sm:flex-row">
            <input
              className="flex-1 rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/50 outline-none focus:border-red-500/30 transition-colors"
              value={postingSearch}
              onChange={(e) => setPostingSearch(e.target.value)}
              placeholder="Search by title or company name..."
            />
            <div className="flex flex-wrap gap-2">
              {["all", ...PROBLEM_STATUS_OPTIONS].map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={cn(
                    "rounded-full border px-3 py-1.5 text-xs font-semibold capitalize transition-all",
                    statusFilter === s ? "border-red-500/30 bg-red-500/10 text-red-400" : "border-white/10 text-secondary hover:border-white/20 hover:text-white"
                  )}
                >
                  {s === "all" ? "All" : s.replace("_", " ")}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">All Job Postings</h2>
            <span className="text-xs text-secondary">{filteredProblems.length} of {problems.length}</span>
          </div>

          {problemsLoading ? (
            <div className="p-12 text-center"><div className="mx-auto h-8 w-8 rounded-full border-2 border-red-400/20 border-t-red-400 animate-spin" /></div>
          ) : filteredProblems.length === 0 ? (
            <div className="rounded-2xl border border-white/8 p-12 text-center text-secondary">No postings found.</div>
          ) : (
            <div className="space-y-3">
              {filteredProblems.map((p) => {
                const isLoading = !!problemActionLoading[p.id];
                let skillsList: string[] = [];
                try { skillsList = JSON.parse(p.skills); } catch { skillsList = p.skills ? [p.skills] : []; }
                return (
                  <div key={p.id} className="rounded-2xl border border-white/8 bg-white/3 p-5 hover:bg-white/[0.05] transition-colors">
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <h3 className="font-bold text-white truncate">{p.title}</h3>
                          <span className={cn("inline-flex rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider", PROBLEM_STATUS_COLOR[p.status] ?? "border-white/10 text-secondary")}>
                            {p.status.replace("_", " ")}
                          </span>
                        </div>
                        <p className="text-xs text-secondary mb-2 line-clamp-2">{p.description}</p>
                        <div className="flex flex-wrap items-center gap-3 text-xs text-secondary">
                          <span className="flex items-center gap-1">
                            <span className="font-semibold text-white">{p.company_name}</span>
                            <span className="text-secondary/60">·</span>
                            <span>{p.company_email}</span>
                          </span>
                          <span className="text-primary font-semibold">${p.budget.toLocaleString()}</span>
                          <span>Due {new Date(p.deadline).toLocaleDateString()}</span>
                          <span className="rounded-full border border-white/10 px-2 py-0.5">{p.submission_count} submission{p.submission_count !== 1 ? "s" : ""}</span>
                        </div>
                        {skillsList.length > 0 && (
                          <div className="mt-2 flex flex-wrap gap-1">
                            {skillsList.slice(0, 5).map((sk) => (
                              <span key={sk} className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] text-secondary">{sk}</span>
                            ))}
                            {skillsList.length > 5 && <span className="text-[10px] text-secondary">+{skillsList.length - 5} more</span>}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => setEditingProblem(p)}
                          className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/10 transition-colors"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => setConfirmDeleteProblem(p)}
                          disabled={isLoading}
                          className="rounded-lg border border-red-500/20 bg-red-500/5 px-3 py-1.5 text-xs font-semibold text-red-400 hover:bg-red-500/15 transition-colors disabled:opacity-40"
                        >
                          {isLoading ? "..." : "Delete"}
                        </button>
                      </div>
                    </div>
                    <div className="mt-2 text-[10px] text-secondary/60">
                      Posted {new Date(p.created_at).toLocaleDateString()} · ID: {p.id.slice(0, 8)}…
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ======= MODALS ======= */}

      {editingUser && (
        <UserEditModal
          user={editingUser}
          onClose={() => setEditingUser(null)}
          onSaved={(updated) => {
            setUsers((prev) => prev.map((u) => u.id === editingUser.id ? { ...u, ...updated } : u));
          }}
        />
      )}

      {showCreateUser && (
        <CreateUserModal
          onClose={() => setShowCreateUser(false)}
          onCreated={(u) => setUsers((prev) => [u, ...prev])}
        />
      )}

      {editingProblem && (
        <ProblemEditModal
          problem={editingProblem}
          onClose={() => setEditingProblem(null)}
          onSaved={(updated) => {
            setProblems((prev) => prev.map((p) => p.id === editingProblem.id ? { ...p, ...updated } : p));
          }}
        />
      )}

      {/* Delete user confirmation */}
      {confirmDelete && (
        <ConfirmModal
          title="Delete User?"
          body={<>This will permanently delete <span className="text-white font-semibold">{confirmDelete.name}</span> and all their data. This cannot be undone.</>}
          confirmLabel={actionLoading[confirmDelete.id] ? "Deleting..." : "Yes, Delete"}
          disabled={!!actionLoading[confirmDelete.id]}
          onCancel={() => setConfirmDelete(null)}
          onConfirm={() => deleteUser(confirmDelete)}
        />
      )}

      {/* Delete problem confirmation */}
      {confirmDeleteProblem && (
        <ConfirmModal
          title="Delete Posting?"
          body={<>This will permanently delete <span className="text-white font-semibold">{confirmDeleteProblem.title}</span> and all its submissions. This cannot be undone.</>}
          confirmLabel={problemActionLoading[confirmDeleteProblem.id] ? "Deleting..." : "Yes, Delete"}
          disabled={!!problemActionLoading[confirmDeleteProblem.id]}
          onCancel={() => setConfirmDeleteProblem(null)}
          onConfirm={() => deleteProblem(confirmDeleteProblem)}
        />
      )}

    </DashboardShell>
  );
}

// ---- Shared helpers ---------------------------------------------------------

function Spinner({ color }: { color: "primary" | "purple" }) {
  return (
    <div className="h-20 flex items-center justify-center">
      <div className={cn("h-6 w-6 animate-spin rounded-full border-2", color === "primary" ? "border-primary/20 border-t-primary" : "border-purple-400/20 border-t-purple-400")} />
    </div>
  );
}

function ConfirmModal({
  title,
  body,
  confirmLabel,
  disabled,
  onCancel,
  onConfirm,
}: {
  title: string;
  body: React.ReactNode;
  confirmLabel: string;
  disabled: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onCancel}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="relative w-full max-w-sm rounded-3xl border border-red-500/20 bg-black/90 p-7 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-lg font-extrabold text-white text-center mb-3">{title}</h3>
        <p className="text-sm text-secondary text-center mb-6">{body}</p>
        <div className="flex gap-3">
          <button onClick={onCancel} className="flex-1 rounded-2xl border border-white/10 py-2.5 text-sm font-semibold text-secondary hover:text-white transition-colors">Cancel</button>
          <button onClick={onConfirm} disabled={disabled} className="flex-1 rounded-2xl bg-red-500 py-2.5 text-sm font-bold text-white hover:bg-red-600 transition-colors disabled:opacity-40">{confirmLabel}</button>
        </div>
      </div>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-red-400 border-t-transparent" />
    </div>
  );
}
