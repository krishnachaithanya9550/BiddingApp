import { useEffect, type RefObject } from "react";

/**
 * Observes all .reveal, .reveal-left, .reveal-right, .reveal-scale elements
 * inside `containerRef` (defaults to `document`) and adds `.in-view` when
 * they enter the viewport, optionally delaying via `data-delay="0.2"` (seconds).
 */
export function useScrollReveal(containerRef?: RefObject<Element | null>) {
  useEffect(() => {
    const root = containerRef?.current ?? document;
    const els = root.querySelectorAll(
      ".reveal, .reveal-left, .reveal-right, .reveal-scale"
    );

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const el = entry.target as HTMLElement;
          const ms = parseFloat(el.dataset.delay ?? "0") * 1000;
          if (ms > 0) {
            setTimeout(() => el.classList.add("in-view"), ms);
          } else {
            el.classList.add("in-view");
          }
          io.unobserve(el);
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" }
    );

    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
}
