/**
 * db.ts — SQLite database layer for the SYNC platform.
 *
 * Single `users` table: role is stored as TEXT.
 *   "0"       → admin (set manually in the DB, never via signup)
 *   "user"    → regular developer/user
 *   "company" → business/company
 */

import Database from "better-sqlite3";
import path from "path";

const DB_PATH = path.join(process.cwd(), "sync.db");

let _db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (!_db) {
    _db = new Database(DB_PATH);
    _db.pragma("journal_mode = WAL");
    _db.pragma("foreign_keys = ON");
    initSchema(_db);
  }
  return _db;
}

function initSchema(db: Database.Database) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id            TEXT PRIMARY KEY,
      name          TEXT NOT NULL,
      email         TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role          TEXT NOT NULL DEFAULT 'user',
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS problems (
      id          TEXT PRIMARY KEY,
      company_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title       TEXT NOT NULL,
      description TEXT NOT NULL,
      budget      REAL NOT NULL,
      deadline    TEXT NOT NULL,
      skills      TEXT NOT NULL DEFAULT '[]',
      status      TEXT NOT NULL DEFAULT 'open'
                  CHECK (status IN ('open', 'closed', 'in_review')),
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS submissions (
      id                TEXT PRIMARY KEY,
      problem_id        TEXT NOT NULL REFERENCES problems(id) ON DELETE CASCADE,
      developer_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      proposal          TEXT NOT NULL,
      solution_notes    TEXT DEFAULT '',
      tech_stack        TEXT DEFAULT '[]',
      repo_url          TEXT DEFAULT '',
      demo_url          TEXT DEFAULT '',
      estimated_hours   INTEGER DEFAULT 0,
      status            TEXT NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending', 'accepted', 'rejected')),
      created_at        TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (problem_id, developer_id)
    );

    -- Friend requests between developers
    CREATE TABLE IF NOT EXISTS friendships (
      id           TEXT PRIMARY KEY,
      requester_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      addressee_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      status       TEXT NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending', 'accepted', 'declined')),
      created_at   TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (requester_id, addressee_id)
    );

    -- Direct messages
    CREATE TABLE IF NOT EXISTS messages (
      id           TEXT PRIMARY KEY,
      sender_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      recipient_id TEXT REFERENCES users(id) ON DELETE CASCADE,
      group_id     TEXT REFERENCES group_chats(id) ON DELETE CASCADE,
      content      TEXT NOT NULL,
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Group chats (optionally tied to a problem / project)
    CREATE TABLE IF NOT EXISTS group_chats (
      id         TEXT PRIMARY KEY,
      name       TEXT NOT NULL,
      created_by TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      problem_id TEXT REFERENCES problems(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Members of a group chat
    CREATE TABLE IF NOT EXISTS group_members (
      group_id  TEXT NOT NULL REFERENCES group_chats(id) ON DELETE CASCADE,
      user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      joined_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (group_id, user_id)
    );

    -- AI Agent / Automation Marketplace listings
    CREATE TABLE IF NOT EXISTS marketplace_listings (
      id          TEXT PRIMARY KEY,
      seller_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title       TEXT NOT NULL,
      description TEXT NOT NULL,
      category    TEXT NOT NULL DEFAULT 'automation',
      tags        TEXT NOT NULL DEFAULT '[]',
      price       REAL NOT NULL DEFAULT 0,
      demo_url    TEXT DEFAULT '',
      repo_url    TEXT DEFAULT '',
      thumbnail   TEXT DEFAULT '',
      status      TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active', 'draft', 'paused')),
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Cart items
    CREATE TABLE IF NOT EXISTS cart_items (
      id          TEXT PRIMARY KEY,
      user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      listing_id  TEXT NOT NULL REFERENCES marketplace_listings(id) ON DELETE CASCADE,
      added_at    TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (user_id, listing_id)
    );

    -- Purchases
    CREATE TABLE IF NOT EXISTS purchases (
      id          TEXT PRIMARY KEY,
      buyer_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      listing_id  TEXT NOT NULL REFERENCES marketplace_listings(id) ON DELETE CASCADE,
      price_paid  REAL NOT NULL,
      purchased_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (buyer_id, listing_id)
    );

    -- Wallets: one row per user, balance in USD
    CREATE TABLE IF NOT EXISTS wallets (
      user_id    TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      balance    REAL NOT NULL DEFAULT 0 CHECK (balance >= 0),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Wallet transaction ledger
    CREATE TABLE IF NOT EXISTS wallet_transactions (
      id           TEXT PRIMARY KEY,
      user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      type         TEXT NOT NULL CHECK (type IN ('topup', 'purchase', 'refund')),
      amount       REAL NOT NULL,
      description  TEXT NOT NULL DEFAULT '',
      reference_id TEXT DEFAULT NULL,
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Contact / feedback submissions (no auth required)
    CREATE TABLE IF NOT EXISTS contact_submissions (
      id         TEXT PRIMARY KEY,
      name       TEXT NOT NULL,
      email      TEXT NOT NULL,
      category   TEXT NOT NULL DEFAULT 'general',
      subject    TEXT NOT NULL,
      message    TEXT NOT NULL,
      area       TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Run ALTER TABLE statements idempotently (SQLite doesn't support IF NOT EXISTS on ALTER)
  const alterCols = [
    "ALTER TABLE submissions ADD COLUMN solution_notes  TEXT    DEFAULT ''",
    "ALTER TABLE submissions ADD COLUMN tech_stack      TEXT    DEFAULT '[]'",
    "ALTER TABLE submissions ADD COLUMN repo_url        TEXT    DEFAULT ''",
    "ALTER TABLE submissions ADD COLUMN demo_url        TEXT    DEFAULT ''",
    "ALTER TABLE submissions ADD COLUMN estimated_hours INTEGER DEFAULT 0",
    "ALTER TABLE users ADD COLUMN bio           TEXT    DEFAULT ''",
    "ALTER TABLE users ADD COLUMN skills        TEXT    DEFAULT '[]'",
    "ALTER TABLE users ADD COLUMN experience    TEXT    DEFAULT '[]'",
    "ALTER TABLE users ADD COLUMN github_url    TEXT    DEFAULT ''",
    "ALTER TABLE users ADD COLUMN linkedin_url  TEXT    DEFAULT ''",
    "ALTER TABLE users ADD COLUMN portfolio_url TEXT    DEFAULT ''",
    "ALTER TABLE users ADD COLUMN location      TEXT    DEFAULT ''",
    "ALTER TABLE users ADD COLUMN hourly_rate   INTEGER DEFAULT 0",
    "ALTER TABLE users ADD COLUMN working_status TEXT   DEFAULT 'available'",
    "ALTER TABLE users ADD COLUMN avatar_color  TEXT    DEFAULT '#22c55e'",
    "ALTER TABLE users ADD COLUMN avatar_emoji  TEXT    DEFAULT ''",
    "ALTER TABLE users ADD COLUMN contributions INTEGER DEFAULT 0",
    "ALTER TABLE messages ADD COLUMN is_read    INTEGER DEFAULT 0",
  ];
  for (const sql of alterCols) {
    try { db.exec(sql); } catch { /* column already exists */ }
  }
}
