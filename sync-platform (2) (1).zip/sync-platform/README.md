﻿# SYNC — Developer Talent Platform

> **By devs. For devs. Always.**

SYNC is a full-stack web platform that connects companies with developers. Companies post engineering problems, developers submit solutions, and the community grows through social features, real-time messaging, and an AI/Automation marketplace.

---

## Table of Contents

1. [Tech Stack](#tech-stack)
2. [Project Structure](#project-structure)
3. [Database Schema](#database-schema)
4. [Features](#features)
5. [API Reference](#api-reference)
6. [Role System](#role-system)
7. [Design System](#design-system)
8. [Local Setup](#local-setup)
9. [Recreate This Project — Prompts](#recreate-this-project--prompts)

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 16.1.7 (App Router) |
| Language | TypeScript 5 (strict mode) |
| Styling | TailwindCSS v4 |
| Database | SQLite via `better-sqlite3` |
| Auth | JWT (jose) + bcryptjs, HttpOnly cookie |
| Font | Geist (next/font) |
| Runtime | Node.js 20 |

**Zero external UI libraries.** All charts, modals, cards, and animations are hand-coded with Tailwind CSS.

---

## Project Structure

```
sync-platform/
├── next.config.ts               # serverExternalPackages: ["better-sqlite3"]
├── tsconfig.json                # strict, @/ path alias -> src/
├── sync.db                      # SQLite database (auto-created on first run)
└── src/
    ├── middleware.ts             # JWT auth + RBAC route guard
    ├── app/
    │   ├── globals.css           # Design tokens, glow effects, scrollbar, animations
    │   ├── layout.tsx            # Root layout with Geist font
    │   ├── page.tsx              # Landing page (Hero, Features, About, CTA)
    │   ├── (auth)/
    │   │   ├── layout.tsx
    │   │   ├── login/page.tsx
    │   │   └── signup/page.tsx
    │   ├── admin/page.tsx        # Admin panel (analytics, user mgmt, job mgmt)
    │   ├── company-dashboard/
    │   │   ├── page.tsx
    │   │   └── leaderboard/page.tsx
    │   ├── developer-dashboard/
    │   │   ├── page.tsx          # Dev dashboard + job browse + heatmap
    │   │   ├── community/page.tsx
    │   │   ├── marketplace/page.tsx  # Manage own listings + purchases
    │   │   ├── messages/page.tsx     # DMs + group chats + unread highlighting
    │   │   ├── profile/page.tsx
    │   │   └── problems/[id]/page.tsx
    │   ├── marketplace/page.tsx  # Public marketplace browse page
    │   ├── post-problem/page.tsx
    │   ├── submissions/page.tsx
    │   └── api/
    │       ├── auth/login/  logout/  signup/  me/
    │       ├── admin/problems/  users/
    │       ├── cart/
    │       ├── community/
    │       ├── friendships/  [id]/
    │       ├── groups/  [id]/messages/
    │       ├── marketplace/  [id]/  mine/  purchased/
    │       ├── messages/  unread/
    │       ├── notifications/
    │       ├── problems/  [id]/  company/
    │       ├── profile/  heatmap/
    │       └── submissions/  [id]/
    ├── components/
    │   ├── Footer.tsx
    │   ├── Navbar.tsx
    │   ├── sections/  Hero.tsx  Features.tsx  About.tsx  CTA.tsx
    │   └── ui/
    │       ├── Button.tsx
    │       ├── DashboardShell.tsx  # Sidebar, bell notifications, mobile bar
    │       └── Section.tsx
    ├── config/
    │   └── site.ts               # siteConfig constants
    ├── lib/
    │   ├── api.ts   auth.ts   db.ts   rbac.ts   session.ts
    │   ├── useAuth.ts            # Client auth hook with role redirect
    │   └── utils.ts              # cn() class merger
    └── types/
        └── index.ts              # All shared TypeScript types
```

---

## Database Schema

SQLite database auto-created at `sync.db` on first server request.

```sql
users (id, name, email UNIQUE, password_hash, role DEFAULT 'user', created_at,
       bio, skills TEXT '[]', experience TEXT '[]', github_url, linkedin_url,
       portfolio_url, location, hourly_rate INT, working_status,
       avatar_color DEFAULT '#22c55e', contributions INT DEFAULT 0)

problems (id, company_id->users, title, description, budget REAL,
          deadline, skills '[]', status CHECK(open|closed|in_review), created_at)

submissions (id, problem_id->problems, developer_id->users, proposal,
             solution_notes, tech_stack '[]', repo_url, demo_url,
             estimated_hours, status CHECK(pending|accepted|rejected), created_at,
             UNIQUE(problem_id, developer_id))

friendships (id, requester_id->users, addressee_id->users,
             status CHECK(pending|accepted|declined), created_at,
             UNIQUE(requester_id, addressee_id))

messages (id, sender_id->users, recipient_id->users,
          group_id->group_chats, content, created_at, is_read INT DEFAULT 0)

group_chats (id, name, created_by->users, problem_id->problems, created_at)
group_members (group_id->group_chats, user_id->users, joined_at, PRIMARY KEY(group_id,user_id))

marketplace_listings (id, seller_id->users, title, description,
                      category DEFAULT 'automation', tags '[]', price REAL DEFAULT 0,
                      demo_url, repo_url, thumbnail,
                      status CHECK(active|draft|paused), created_at)

cart_items (id, user_id->users, listing_id->marketplace_listings, added_at,
            UNIQUE(user_id, listing_id))

purchases (id, buyer_id->users, listing_id->marketplace_listings,
           price_paid REAL, purchased_at, UNIQUE(buyer_id, listing_id))
```

---

## Features

### Authentication
- Email + password signup with bcrypt (12 rounds)
- JWT stored in `sync-session` HttpOnly SameSite=Lax cookie (7-day expiry)
- Middleware enforces RBAC on every protected route before the page renders
- Role chosen at signup: Developer or Company (Admin set manually in DB only)

### Landing Page
- Animated Hero with neon glow orbs and floating code element
- Features, About, CTA sections
- Fully responsive — CSS-only animations, no JS libraries

### Developer Dashboard
- Browse open job postings with search
- Submit proposals with tech stack, repo URL, demo URL, estimated hours
- Contribution heatmap (52-week GitHub-style SVG grid, hand-coded, no library)
- View all own submissions with status badges

### Developer Profile
- Bio, skills, work experience (dynamic entries)
- GitHub, LinkedIn, Portfolio URLs
- Hourly rate, location, working status (available / busy / open to offers)
- Public profile visible to companies on submission cards

### Community
- Discover all developers — search by name or skill
- Friend request system (send / accept / decline / remove)
- Working status badge on each developer card

### Real-Time Messaging
- Direct messages between accepted friends (polling every 3s)
- Group chats with named members
- Unread highlights: red-tinted row, bold name, red dot on avatar, "New messages" label
- Notification bell deep-links to `/messages?with=SENDER_ID` — opens that chat automatically
- Messages marked read server-side when conversation is opened

### Company Dashboard
- Post engineering problems / job listings
- Review developer submissions with full profile card
- Accept or reject submissions (accepted = +1 contribution to developer)
- Developer leaderboard sorted by contributions

### Admin Panel
- Platform analytics: users, problems, submissions counts
- SVG bar chart (submissions per month) and SVG donut chart (role distribution) — no chart library
- User management: view all, change role, delete
- Job management: view all, change status, delete

### AI/Automation Marketplace
- Developers list: AI agents, automations, scripts, tools, templates, APIs
- Category filters + full-text search
- Listing detail modal with YouTube demo embed (auto-detected from URL)
- Cart: add/remove items, badge count, slide-in drawer with total
- Checkout: SQLite transaction — entire cart becomes purchases atomically
- Repo/download URL revealed to buyer only after purchase
- Seller stats: per-listing sales count and estimated revenue

---

## API Reference

### Auth
| Method | Route | Description |
|---|---|---|
| POST | `/api/auth/signup` | Register — name, email, password, role |
| POST | `/api/auth/login` | Login → sets sync-session cookie |
| POST | `/api/auth/logout` | Clears cookie |
| GET | `/api/auth/me` | Current user profile |

### Problems
| Method | Route | Description |
|---|---|---|
| GET | `/api/problems` | All open problems (public, supports `?q=`) |
| POST | `/api/problems` | Create problem (company) |
| GET | `/api/problems/company` | Company's own problems |
| GET | `/api/problems/[id]` | Single problem |
| PATCH | `/api/problems/[id]` | Update (owner or admin) |
| DELETE | `/api/problems/[id]` | Delete (owner or admin) |

### Submissions
| Method | Route | Description |
|---|---|---|
| GET | `/api/submissions` | Company: own submissions. Dev: own submissions |
| POST | `/api/submissions` | Submit proposal (developer) |
| PATCH | `/api/submissions/[id]` | Accept / reject (company or admin) |
| DELETE | `/api/submissions/[id]` | Delete |

### Profile
| Method | Route | Description |
|---|---|---|
| GET | `/api/profile` | Own full profile |
| PATCH | `/api/profile` | Update bio, skills, experience, URLs, etc. |
| GET | `/api/profile/heatmap` | 365-day contribution data |

### Community & Social
| Method | Route | Description |
|---|---|---|
| GET | `/api/community` | All developers + friendship status |
| GET | `/api/friendships` | Own friendships |
| POST | `/api/friendships` | Send friend request |
| PATCH | `/api/friendships/[id]` | Accept / decline |
| DELETE | `/api/friendships/[id]` | Remove friendship |

### Messaging
| Method | Route | Description |
|---|---|---|
| GET | `/api/messages?with=userId` | DMs with user (marks as read) |
| POST | `/api/messages` | Send DM |
| GET | `/api/messages/unread` | Total unread DM count |
| GET | `/api/notifications?since=ISO` | Bell data (unread senders, new jobs, new subs) |
| GET | `/api/groups` | User's group chats |
| POST | `/api/groups` | Create group chat |
| GET | `/api/groups/[id]/messages` | Group messages |
| POST | `/api/groups/[id]/messages` | Send group message |

### Marketplace
| Method | Route | Description |
|---|---|---|
| GET | `/api/marketplace` | Browse active listings |
| POST | `/api/marketplace` | Create listing (developer only) |
| PATCH | `/api/marketplace/[id]` | Edit listing (owner or admin) |
| DELETE | `/api/marketplace/[id]` | Delete listing (owner or admin) |
| GET | `/api/marketplace/mine` | Own listings with purchase counts |
| GET | `/api/marketplace/purchased` | Purchased items (includes repo_url) |
| GET | `/api/cart` | Cart items + total |
| POST | `/api/cart` | Add to cart |
| DELETE | `/api/cart` | Remove from cart |
| PATCH | `/api/cart` | Checkout (cart -> purchases transaction) |

### Admin
| Method | Route | Description |
|---|---|---|
| GET | `/api/admin/users` | All users |
| POST | `/api/admin/users` | Create user |
| PATCH | `/api/admin/users` | Change role |
| DELETE | `/api/admin/users` | Delete user |
| GET | `/api/admin/problems` | All problems |
| PATCH | `/api/admin/problems` | Change status |
| DELETE | `/api/admin/problems` | Delete problem |

---

## Role System

```
"0"       -> Admin     — /admin, full access to all dashboards
"user"    -> Developer — /developer-dashboard, marketplace, messages, community
"company" -> Company   — /company-dashboard, /post-problem, /submissions
```

**Setting admin role** (run once after signup):

```bash
node -e "
const db = require('better-sqlite3')('sync.db');
db.prepare('UPDATE users SET role = ? WHERE email = ?').run('0', 'your@email.com');
console.log('Done');
"
```

---

## Design System

| Token | Value | Tailwind class |
|---|---|---|
| Primary | `#22c55e` (green) | `text-primary` / `bg-primary` |
| Background | `#000000` | `bg-black` |
| Foreground | `#ffffff` | `text-white` |
| Secondary | `#9ca3af` | `text-secondary` |

Defined in `src/app/globals.css` as CSS custom properties, mapped into Tailwind v4 via `@theme inline`.

Custom CSS utilities:
- `.card-3d` — CSS 3D hover tilt (perspective + rotateX/Y)
- `.btn-glow` — shimmer overflow animation on hover
- `.neon-text` — green text-shadow glow
- `.input-glow` — green focus border glow
- `animate-float` — continuous vertical float keyframes

---

## Local Setup

### Prerequisites

| Requirement | Version |
|---|---|
| [Node.js](https://nodejs.org) | 18+ (20 LTS recommended) |
| npm | 9+ (bundled with Node.js) |

---

### What was removed before sending

The following files/folders were intentionally excluded to save space — they are all auto-generated:

| Removed | How it's restored |
|---|---|
| `node_modules/` | `npm install` |
| `.next/` | `npm run dev` or `npm run build` |
| `tsconfig.tsbuildinfo` | auto-generated by TypeScript on first build |
| `sync.db`, `sync.db-shm`, `sync.db-wal` | auto-created on first API request |
| `.env.local` | you create it manually — see step 3 below |

---

### Steps

**1. Enter the project folder**

```bash
cd sync-platform
```

**2. Install all dependencies**

```bash
npm install
```

> This restores `node_modules/` from `package.json` + `package-lock.json`. Takes ~1–2 minutes on first run.

**3. Create your environment file**

Copy the example file and fill in your values:

```bash
# Windows (PowerShell)
Copy-Item .env.example .env.local

# macOS / Linux
cp .env.example .env.local
```

Then open `.env.local` and set at minimum:

```env
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_APP_NAME=SYNC
```

If you are behind a **corporate proxy (e.g. Zscaler)** that intercepts TLS, also add:

```env
NODE_TLS_REJECT_UNAUTHORIZED=0
```

> ⚠ Never set `NODE_TLS_REJECT_UNAUTHORIZED=0` in production.

**4. Start the development server**

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

> `sync.db` is created automatically at the project root the first time any API route is hit. No migration or seeding step is needed.

---

### Available Scripts

| Command | Description |
|---|---|
| `npm run dev` | Start dev server with hot reload on port 3000 |
| `npm run build` | Create an optimised production build (outputs to `.next/`) |
| `npm run start` | Serve the production build (run `npm run build` first) |
| `npm run lint` | Run ESLint across the source |

---

### Setting an Admin account

After signing up normally, promote your user to admin by running this once:

```bash
node -e "
const db = require('better-sqlite3')('sync.db');
db.prepare('UPDATE users SET role = ? WHERE email = ?').run('0', 'your@email.com');
console.log('Done — you are now admin');
"
```

Then log out and back in. You will be redirected to `/admin`.

---

## Recreate This Project — Prompts

Use these prompts in order with any AI coding assistant (GitHub Copilot, Claude, ChatGPT) to rebuild the entire SYNC platform from scratch on a new machine.

---

### PROMPT 1 — Project Scaffold

```
Create a new Next.js project called "sync-platform" with:
- Next.js 16 (App Router), TypeScript strict mode, TailwindCSS v4
- src/ directory layout, path alias @/ -> src/
- Dependencies: better-sqlite3, bcryptjs, jose, geist
- Dev deps: @types/better-sqlite3, @types/bcryptjs, @tailwindcss/postcss
- In next.config.ts: serverExternalPackages: ["better-sqlite3"]
- postcss.config.mjs: use @tailwindcss/postcss plugin
- tsconfig.json: "strict": true, paths: {"@/*": ["./src/*"]}
- .env.local: NEXT_PUBLIC_APP_URL=http://localhost:3000 and JWT_SECRET=change-me
```

---

### PROMPT 2 — Design Tokens & Global CSS

```
In src/app/globals.css, set up the SYNC design system:
- @import "tailwindcss"
- CSS :root variables: --background: #000000, --foreground: #ffffff,
  --color-primary: #22c55e, --color-secondary: #9ca3af,
  --glow-primary: rgba(34,197,94,0.3)
- @theme inline block mapping to Tailwind color tokens:
  --color-primary: #22c55e, --color-secondary: #9ca3af,
  --color-background, --color-foreground, --font-sans, --font-mono
- body: background black, color white, antialiased
- Custom green thin scrollbar (5px, #22c55e44 thumb, hover #22c55e88)
- ::selection: green tint background
- .card-3d: perspective 800px hover rotate X-4 Y4 translateY-6 scale 1.02, green box-shadow
- .btn-glow: overflow hidden, ::after shimmer slide animation on hover
- .neon-text: text-shadow 0 0 20px rgba(34,197,94,0.5)
- .input-glow: styled input with dark bg, border focus glows green
- @keyframes float: translateY 0 -> -8px -> 0, 3s infinite ease-in-out
- @keyframes pulse-glow and fadeIn utilities
```

---

### PROMPT 3 — Shared TypeScript Types

```
Create src/types/index.ts with all shared types for the SYNC platform:

- UserRole = "0" | "user" | "company"
- UserProfile: id, name, email, role: UserRole, created_at,
  optional: bio, skills (string[]), experience (WorkExperience[]),
  github_url, linkedin_url, portfolio_url, location, hourly_rate,
  working_status ("available"|"busy"|"open_to_offers"), avatar_color, contributions
- WorkExperience: company, role, duration, description?
- SignUpPayload: name, email, password, role ("user"|"company")
- LoginPayload: email, password
- Problem: id, company_id, title, description, budget, deadline, skills (string[]),
  status ("open"|"closed"|"in_review"), created_at
- PostProblemPayload: title, description, budget, deadline, skills[]
- Submission: id, problem_id, developer_id, proposal, solution_notes?, tech_stack?,
  repo_url?, demo_url?, estimated_hours?, status ("pending"|"accepted"|"rejected"),
  created_at, plus optional joined fields: developer_name, developer_email, developer_bio,
  developer_skills, developer_github, developer_linkedin, developer_portfolio,
  developer_working_status, developer_contributions, developer_rank, problem_title
- Friendship: id, requester_id, addressee_id, status, created_at,
  optional: other_name, other_email, other_role
- Message: id, sender_id, recipient_id?, group_id?, content, created_at, sender_name?
- GroupChat: id, name, created_by, problem_id?, created_at, member_count?, last_message?
- DeveloperPublicProfile with all public fields
- ApiResponse<T>, PaginatedResponse<T>, DbResult<T> generics
- NavLink: label, href, external?
```

---

### PROMPT 4 — SQLite Database Layer

```
Create src/lib/db.ts — singleton SQLite database layer.

Use better-sqlite3. DB_PATH = path.join(process.cwd(), "sync.db").
Export getDb() as singleton — creates DB once, sets pragma journal_mode=WAL and
foreign_keys=ON, calls initSchema().

initSchema() runs db.exec() with CREATE TABLE IF NOT EXISTS for:

1. users (id TEXT PK, name, email UNIQUE, password_hash, role DEFAULT 'user', created_at DEFAULT datetime('now'))
2. problems (id PK, company_id REFERENCES users ON DELETE CASCADE, title, description, budget REAL, deadline, skills DEFAULT '[]', status CHECK('open','closed','in_review') DEFAULT 'open', created_at)
3. submissions (id PK, problem_id->problems CASCADE, developer_id->users CASCADE, proposal, solution_notes DEFAULT '', tech_stack DEFAULT '[]', repo_url DEFAULT '', demo_url DEFAULT '', estimated_hours INT DEFAULT 0, status CHECK('pending','accepted','rejected') DEFAULT 'pending', created_at, UNIQUE(problem_id,developer_id))
4. friendships (id PK, requester_id->users CASCADE, addressee_id->users CASCADE, status CHECK('pending','accepted','declined') DEFAULT 'pending', created_at, UNIQUE(requester_id,addressee_id))
5. messages (id PK, sender_id->users CASCADE, recipient_id->users, group_id->group_chats, content, created_at)
6. group_chats (id PK, name, created_by->users CASCADE, problem_id->problems SET NULL, created_at)
7. group_members (group_id->group_chats CASCADE, user_id->users CASCADE, joined_at, PRIMARY KEY(group_id,user_id))
8. marketplace_listings (id PK, seller_id->users CASCADE, title, description, category DEFAULT 'automation', tags DEFAULT '[]', price REAL DEFAULT 0, demo_url DEFAULT '', repo_url DEFAULT '', thumbnail DEFAULT '', status CHECK('active','draft','paused') DEFAULT 'active', created_at)
9. cart_items (id PK, user_id->users CASCADE, listing_id->marketplace_listings CASCADE, added_at, UNIQUE(user_id,listing_id))
10. purchases (id PK, buyer_id->users CASCADE, listing_id->marketplace_listings CASCADE, price_paid REAL, purchased_at, UNIQUE(buyer_id,listing_id))

After exec(), run ALTER TABLE statements in a try/catch loop (idempotent):
- submissions: solution_notes, tech_stack, repo_url, demo_url, estimated_hours
- users: bio, skills, experience, github_url, linkedin_url, portfolio_url, location,
  hourly_rate INT, working_status DEFAULT 'available', avatar_color DEFAULT '#22c55e',
  contributions INT DEFAULT 0
- messages: is_read INT DEFAULT 0
```

---

### PROMPT 5 — Auth System (JWT + bcrypt)

```
Build the SYNC authentication system:

1. src/lib/session.ts:
   - COOKIE_NAME = "sync-session"
   - signSession({sub, role, name}) -> signs HS256 JWT with 7d expiry using process.env.JWT_SECRET
   - verifySession(token) -> returns {sub, role, name} payload or null (never throws)

2. src/app/api/auth/signup/route.ts — POST {name, email, password, role}:
   - Validate all fields. Reject role "0".
   - Check email uniqueness. Hash password bcryptjs rounds=12.
   - Insert user with randomUUID(), random avatar_color from 8 preset hex values.
   - signSession, set HttpOnly Secure SameSite=Lax cookie max-age=604800
   - Return {profile}

3. src/app/api/auth/login/route.ts — POST {email, password}:
   - Fetch user by email, bcrypt.compare hash. Set cookie. Return {profile}.

4. src/app/api/auth/logout/route.ts — POST:
   - Set cookie to empty string with maxAge=0

5. src/app/api/auth/me/route.ts — GET:
   - Read COOKIE_NAME cookie, verifySession. Fetch user from DB.
   - JSON.parse skills, experience (with try/catch fallback to []).
   - Return full profile.

6. src/lib/auth.ts — client helpers:
   signUp(payload), signIn(payload), signOut() — fetch wrappers returning {profile, error}

7. src/lib/useAuth.ts — React hook "use client":
   - useAuth(allowedRoles?: string[]) fetches /api/auth/me
   - If 401 -> router.push("/login")
   - If role not in allowedRoles -> router.push(getRoleHome(role))
   - Returns {profile: UserProfile | null, loading: boolean}
```

---

### PROMPT 6 — Middleware & RBAC

```
Create role-based route protection for SYNC:

1. src/lib/rbac.ts:
   ROLE_HOME = {"0": "/admin", "user": "/developer-dashboard", "company": "/company-dashboard"}
   PROTECTED_ROUTES = [
     {prefix: "/admin", allowedRoles: ["0"]},
     {prefix: "/developer-dashboard", allowedRoles: ["0","user"]},
     {prefix: "/company-dashboard", allowedRoles: ["0","company"]},
     {prefix: "/post-problem", allowedRoles: ["0","company"]},
     {prefix: "/submissions", allowedRoles: ["0","company"]},
   ]
   PUBLIC_ROUTES = ["/", "/login", "/signup", "/api/auth", "/api/problems"]
   Export: isPublicRoute(), getProtectedRoute(), canAccess(), getRoleHome()

2. src/middleware.ts:
   - Runs on all routes (matcher excludes _next/static, _next/image, favicon)
   - Step 1: isPublicRoute -> NextResponse.next()
   - Step 2: not in PROTECTED_ROUTES -> NextResponse.next()
   - Step 3: read COOKIE_NAME cookie, verifySession -> if null, redirect /login?next=pathname
   - Step 4: canAccess(pathname, role) -> if false, redirect to getRoleHome(role)
   - Step 5: allow through
```

---

### PROMPT 7 — Config, Utils & Site

```
Create supporting config and utility files:

1. src/config/site.ts:
   export const siteConfig = {
     name: "SYNC",
     tagline: "For the vibe coders, To the vibecoders, From a vibe coder",
     description: "SYNC is the platform built by vibe coders, for vibe coders. Ship fast. Stay in flow.",
     url: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",
     version: "1.0.0",
   }

2. src/lib/utils.ts:
   export function cn(...classes: (string | undefined | null | false)[]) {
     return classes.filter(Boolean).join(" ");
   }

3. src/lib/api.ts — typed fetch helpers:
   - get<T>(url: string): Promise<T>
   - post<T>(url: string, body: unknown): Promise<T>
   - patch<T>(url: string, body: unknown): Promise<T>
   - del<T>(url: string, body?: unknown): Promise<T>
   All use "Content-Type: application/json", throw on non-ok responses.

4. src/app/layout.tsx:
   - Import Geist Sans and Geist Mono from "geist/font"
   - Apply font CSS variables to html element
   - Metadata from siteConfig

5. src/components/ui/Button.tsx:
   - Props: variant ("primary"|"outline"|"ghost"), size ("sm"|"md"|"lg"), plus all button attrs
   - primary: bg-primary text-black btn-glow
   - outline: border border-primary text-primary
   - ghost: text-secondary hover:text-white

6. src/components/ui/Section.tsx:
   Wrapper with id, className, maxWidth, padding props. Semantic <section> element.
```

---

### PROMPT 8 — Landing Page

```
Build the SYNC public landing page:

1. src/components/Navbar.tsx:
   - Sticky top, black glassmorphism background (backdrop-blur)
   - SYNC logo (text-primary, font-black, neon-text) on left
   - Nav links: Features, About, Community (scroll anchors)
   - Right: "Log In" ghost link, "Sign Up" primary Button
   - Hides/shows borders based on scroll position (useEffect + scroll listener)

2. src/components/Footer.tsx:
   - Minimal footer, tagline: "By devs. For devs. Always."
   - Copyright line with current year

3. src/components/sections/Hero.tsx — Full viewport:
   - Background: two large blurred green glow orbs (absolute positioned divs)
   - Headline: large bold text with "SYNC" in green gradient
   - Sub-headline with tagline from siteConfig
   - CTA buttons: "Start Building" -> /signup (primary, btn-glow), "Browse Jobs" (outline)
   - Decorative: animated floating code block element (.animate-float class)
   - Bottom fade gradient into next section

4. src/components/sections/Features.tsx:
   - 3-column grid (1-col mobile), section title
   - Feature cards with .card-3d class: emoji icon, title, description
   - Features: Job Matching, Real-time Chat, Leaderboard, Developer Profiles, Marketplace, Community

5. src/components/sections/About.tsx:
   - Split layout: left text, right stats
   - Stats counters: Developers, Companies, Problems Solved, Connections

6. src/components/sections/CTA.tsx:
   - Centered CTA with gradient background
   - "Join SYNC Today" with Sign Up button and login link

7. src/app/page.tsx: compose Navbar + Hero + Features + About + CTA + Footer
```

---

### PROMPT 9 — Auth Pages

```
Create the authentication pages for SYNC:

1. src/app/(auth)/layout.tsx:
   - Full screen centered layout, black background
   - SYNC logo (neon-text) with link to /
   - Card wrapper with border border-white/10 rounded-3xl bg-white/3

2. src/app/(auth)/login/page.tsx:
   - Email + password inputs (input-glow styling)
   - Show/hide password toggle button
   - Calls signIn() from @/lib/auth
   - On success: fetch /api/auth/me and redirect to getRoleHome(role)
   - Show inline error message in red border box
   - "Don't have an account? Sign up" link

3. src/app/(auth)/signup/page.tsx:
   - Name, email, password inputs
   - Role selection: two large toggle cards "Developer" (icon 👨‍💻) and "Company" (icon 🏢)
     with selected state highlighted in green (developer) or blue (company)
   - Password show/hide toggle
   - Calls signUp() then redirects to role home
   - Inline error display
   - "Already have an account? Log in" link
```

---

### PROMPT 10 — DashboardShell Navigation

```
Create src/components/ui/DashboardShell.tsx — shared authenticated layout shell.

Props: {profile: UserProfile, children: React.ReactNode}

ROLE_CONFIG (object keyed by UserRole):
  "0" Admin: label "Admin", red badge, nav: Overview /admin, Users /admin
  "user" Developer: label "Developer", green badge, nav:
    Dashboard /developer-dashboard, Browse Jobs /developer-dashboard,
    Community /developer-dashboard/community, Messages /developer-dashboard/messages,
    Marketplace /marketplace, My Listings /developer-dashboard/marketplace,
    Profile /developer-dashboard/profile
  "company" Company: label "Company", blue badge, nav:
    Dashboard /company-dashboard, Post Problem /post-problem,
    Submissions /submissions, Leaderboard /company-dashboard/leaderboard,
    Marketplace /marketplace

Features:
- Fixed left sidebar 256px (hidden below lg breakpoint):
  - Logo row: SYNC text (neon-text) + role badge + notification bell (right side)
  - Bell button shows red badge with totalBadge count
  - Bell dropdown (280px wide, glassmorphism):
    - "Notifications" header + count chip
    - Empty state: checkmark + "All caught up!"
    - Per-sender DM notification: avatar, name, "N unread messages" in red,
      href="/developer-dashboard/messages?with=SENDER_ID" (deep link!)
    - New jobs notification: yellow, href=/developer-dashboard
    - New submissions notification: blue, href=/submissions
  - Nav links: emoji icon + label, active = bg-primary/10 border-primary/20 text-primary
  - Unread badge on Messages nav item (red), Dashboard (yellow), Submissions (blue)
  - Bottom: user avatar circle (first letter, colored), name, email, Sign Out button

- Mobile top bar (visible below lg):
  - Same bell dropdown
  - Icon-only nav links with badges
  - Compact "Out" sign out button

- Polling: fetch /api/notifications?since=lastSeen every 10 seconds
- On navigate to messages page: clear unreadSenders state
- On navigate to dashboard: clear newJobs, advance sinceRef timestamp
- On navigate to submissions: clear newSubmissions, advance sinceRef timestamp
- LAST_SEEN_KEY stored in localStorage for persistence across refreshes

- Main content: ml-[256px] on desktop, max-w-6xl, px-4 sm:px-8, py-8 sm:py-12
```

---

### PROMPT 11 — Problems API & Developer Job Board

```
Build the job board for SYNC:

1. src/app/api/problems/route.ts (GET public + POST company):
   - GET: SELECT all active problems joined with company name. Optional ?q= text search on title/description. Return {problems}.
   - POST role=company: insert problem with {title, description, budget, deadline, skills (JSON.stringify array)}. Return {problem}.

2. src/app/api/problems/[id]/route.ts (GET + PATCH + DELETE):
   - GET: single problem with company name + submission_count subquery
   - PATCH: update fields (owner or admin only). Fields: title, description, budget, deadline, skills, status.
   - DELETE: delete (owner or admin only)

3. src/app/api/problems/company/route.ts (GET company):
   - Own problems with (SELECT COUNT(*) FROM submissions WHERE problem_id=l.id) AS submission_count

4. src/app/developer-dashboard/page.tsx:
   - useAuth(["0","user"]), DashboardShell
   - Fetch /api/problems (open ones) and /api/submissions (own)
   - Two tabs "Browse Jobs" and "My Submissions" (styled tab buttons)
   - Browse Jobs: search input at top, scrollable card grid
     Each card: company name, problem title, budget (green), deadline, skills chips, "Apply" button
     Click card -> expandable drawer/panel with full description + submission form:
       proposal (textarea), tech_stack (comma input -> chips), repo_url, demo_url, estimated_hours
       POST /api/submissions on submit
   - My Submissions tab: list of own submissions, status badge (pending=yellow, accepted=green, rejected=red), problem title link
   - Contribution heatmap component (52 weeks x 7 days SVG):
     Fetch /api/profile/heatmap, render each day as a rect with opacity based on count, green color
     Tooltip on hover showing date + count
```

---

### PROMPT 12 — Submissions API & Company Review

```
Build the submissions system for SYNC:

1. src/app/api/submissions/route.ts (GET + POST):
   - GET for company: SELECT submissions joined with developer profile fields,
     filtered to their problems. Also return problem_title.
   - GET for developer: own submissions with problem_title.
   - POST for developer: {problem_id, proposal, tech_stack[], repo_url, demo_url, estimated_hours}
     Check UNIQUE constraint (one per dev per problem). Problem must be status='open'.

2. src/app/api/submissions/[id]/route.ts (PATCH + DELETE):
   - PATCH role=company or "0": update status to "accepted" or "rejected"
     On "accepted": UPDATE users SET contributions = contributions + 1 WHERE id = developer_id
   - DELETE: developer (own) or admin

3. src/app/submissions/page.tsx:
   - useAuth(["0","company"]), DashboardShell
   - Fetch submissions from /api/submissions
   - Group by problem_title
   - Each submission card: developer avatar, name, bio snippet, skills chips,
     working_status badge, contributions count, proposal text (expandable),
     tech_stack chips, repo/demo links (if provided), estimated hours
   - Accept (green) / Reject (red) buttons with confirmation state
   - Status badge shows current state, buttons hidden if already decided

4. src/app/developer-dashboard/problems/[id]/page.tsx:
   - Fetch problem detail
   - If already submitted: show own submission status card
   - If not: submission form (same fields as above)
```

---

### PROMPT 13 — Developer Profile & Heatmap

```
Build the developer profile system for SYNC:

1. src/app/api/profile/route.ts (GET + PATCH authenticated):
   - GET: full own profile from users table, JSON.parse skills and experience (fallback [])
   - PATCH: accept {bio, skills[], experience[], github_url, linkedin_url, portfolio_url,
     location, hourly_rate, working_status}. JSON.stringify arrays before saving.

2. src/app/api/profile/heatmap/route.ts (GET):
   - SELECT DATE(created_at) as date, COUNT(*) as count FROM submissions
     WHERE developer_id = ? AND created_at >= DATE('now', '-365 days')
     GROUP BY DATE(created_at)
   - Return {heatmap: [{date, count}]}

3. src/app/developer-dashboard/profile/page.tsx:
   - useAuth(["0","user"]), DashboardShell
   - Two columns on desktop: Edit form (left) + Live Preview (right)
   - Edit form fields:
     - Bio: textarea
     - Skills: comma input that renders live tag chips below
     - Work Experience: dynamic list of entries (Company, Role, Duration, Description)
       with Add Entry button and remove per entry
     - GitHub URL, LinkedIn URL, Portfolio URL (text inputs with icon prefix)
     - Location (text input)
     - Hourly Rate (number input with $ prefix)
     - Working Status: three styled option buttons (Available green, Open to offers yellow, Busy grey)
   - Preview panel: avatar circle (letter + avatar_color), name, badge chips, stats
   - Save button calls PATCH /api/profile, shows success/error inline message
```

---

### PROMPT 14 — Community & Friend System

```
Build the community and social system for SYNC:

1. src/app/api/community/route.ts (GET authenticated):
   - SELECT all users with role='user'. For each, include a friendship_status column:
     CASE WHEN friendship exists and status='accepted' THEN 'accepted'
          WHEN requester_id=me and status='pending' THEN 'pending_sent'
          WHEN addressee_id=me and status='pending' THEN 'pending_received'
          ELSE 'none' END
   - Also include friendship id for action buttons
   - Support ?q= search on name, bio (JSON skills contain check)

2. src/app/api/friendships/route.ts (GET + POST):
   - GET: own friendships with other user's name, email, avatar_color, status
   - POST {addressee_id}: insert friendship. Reject self-request and duplicates.

3. src/app/api/friendships/[id]/route.ts (PATCH + DELETE):
   - PATCH {status: "accepted"|"declined"}: only addressee can act
   - DELETE: either party

4. src/app/developer-dashboard/community/page.tsx:
   - useAuth(["0","user"]), DashboardShell
   - Heading + search bar
   - Section: "Friend Requests" (pending_received) with Accept/Decline buttons — shown only if any exist
   - Developer grid (2-3 columns):
     Each card: avatar circle (letter, avatar_color), name, bio (2 lines), skills chips (first 4),
     location text, hourly rate, working status badge, contribution count
     Friend button: states "Connect" / "Request Sent" / "Accept" / "Friends ✓"
     Each state calls appropriate API (POST /friendships, PATCH /friendships/[id])
   - Optimistic UI update after each action (update local state immediately)
```

---

### PROMPT 15 — Real-Time Messaging

```
Build the messaging system for SYNC:

1. src/app/api/messages/route.ts (GET + POST):
   - GET ?with=userId: SELECT messages between current user and other, joined with sender name + avatar_color.
     Also run: UPDATE messages SET is_read=1 WHERE sender_id=otherId AND recipient_id=me AND is_read=0
   - POST {recipient_id, content}: verify accepted friendship, insert message with is_read=0.

2. src/app/api/messages/unread/route.ts (GET): COUNT unread incoming DMs.

3. src/app/api/groups/route.ts (GET + POST):
   - GET: groups where current user is a member, with member_count
   - POST {name, member_ids[]}: create group_chats row, insert creator + all member_ids into group_members

4. src/app/api/groups/[id]/messages/route.ts (GET + POST):
   - GET: messages for group joined with sender info. Verify user is a member.
   - POST {content}: insert group message. Verify member.

5. src/app/api/notifications/route.ts (GET ?since=ISO):
   - For any role: unread_senders = SELECT sender_id, sender name, avatar_color, COUNT(*) as count
     FROM messages WHERE recipient_id=me AND is_read=0 AND group_id IS NULL
     GROUP BY sender_id (wrap in try/catch for missing column)
   - For developer: new_jobs = COUNT problems created_at > since
   - For company: new_submissions = COUNT submissions created_at > since
   - Return {unread_senders, new_jobs, new_submissions}

6. src/app/developer-dashboard/messages/page.tsx:
   - useAuth(["0","user"]), DashboardShell
   - Layout: fixed left sidebar 288px + flex-1 chat area, height 70vh
   - Left sidebar:
     "Direct Messages" section: friend list as buttons.
     Each DM button when has unread (ID in unreadIds Set):
       red-tinted bg (bg-red-500/8 border-red-500/20), bold white name,
       red dot overlay on avatar (absolute -top -right, h-3 w-3 bg-red-500),
       "New messages" subtitle in red, red "!" badge on right
     When active: bg-primary/10 border-primary/20 (overrides unread style)
     "Group Chats" section with "+ New" button, group list with member count
   - Right chat area:
     Header: avatar + name + DM/Group label
     Message list: own messages right (bg-primary text-black rounded-tr-sm),
       others left (bg-white/8 text-white rounded-tl-sm), avatar + sender name above theirs
     Send input with Enter-to-send, optimistic update (show immediately, replace on success)
     Auto-scroll to bottom on message change
   - Polling setInterval 3000ms to reload messages in active chat
   - On mount: read searchParams.get("with"), once friends load, auto-open that conversation
     (track with autoOpenedRef = useRef(false) to prevent double-open)
   - openChat(): fetches messages, calls setUnreadIds(prev => prev without this id)
   - New Group modal: group name input + friend checkbox list
   - loadFriendsAndGroups() + fetchUnread() called on profile load
   - fetchUnread(): GET /api/notifications?since=1970-01-01... extract unread_senders IDs into Set
```

---

### PROMPT 16 — Company Dashboard & Leaderboard

```
Build company-facing pages for SYNC:

1. src/app/company-dashboard/page.tsx:
   - useAuth(["0","company"]), DashboardShell
   - Stats row: total problems posted, open problems, closed problems, total submissions, pending submissions
   - "Your Job Postings" section: cards from /api/problems/company
     Each card: title, status badge (green=open, grey=closed, yellow=in_review),
     submission count chip, deadline, budget, skill tags, Edit/Close/Delete actions
   - "Recent Submissions" section: 3 latest from /api/submissions (link to /submissions for all)
   - Quick action buttons: "Post New Problem" -> /post-problem, "All Submissions" -> /submissions

2. src/app/post-problem/page.tsx:
   - useAuth(["0","company"]), DashboardShell
   - Form with DashboardShell:
     Title (text), Description (textarea), Budget (number with $ prefix),
     Deadline (date input), Skills (comma input -> live chips display)
   - As user types comma-separated skills, render pill chips below input
   - POST /api/problems on submit
   - On success: redirect to /company-dashboard with success message

3. src/app/company-dashboard/leaderboard/page.tsx:
   - useAuth(["0","company"]), DashboardShell
   - Fetch /api/community (all developers)
   - Sort by contributions descending
   - Numbered leaderboard: rank number, avatar circle, name, location, working status badge,
     contribution count with a visual bar (width % based on max), skill chips
   - Top 3 rows: gold (#FFD700), silver (#C0C0C0), bronze (#CD7F32) left border accent
   - Search/filter input
```

---

### PROMPT 17 — Admin Panel

```
Build the admin panel for SYNC (role "0" only):

1. src/app/api/admin/users/route.ts (GET + POST + PATCH + DELETE):
   - GET: all users with submission_count and problem_count subqueries
   - POST {name, email, password, role}: create any user including role "0"
   - PATCH {id, role}: change user role
   - DELETE {id}: delete user (cascades)

2. src/app/api/admin/problems/route.ts (GET + PATCH + DELETE):
   - GET: all problems with company name and submission_count
   - PATCH {id, status}: change problem status
   - DELETE {id}: delete problem

3. src/app/admin/page.tsx:
   - useAuth(["0"]), DashboardShell
   - Stats row: users total, developers, companies, problems, submissions, marketplace listings
     All as simple DB COUNT queries
   - SVG bar chart (hand-coded, no library):
     Data: submissions grouped by month for last 6 months
     SVG with viewBox, rect elements for bars, text labels for months and counts
     Green fill with glow
   - SVG donut chart (hand-coded):
     Data: user role counts. Each slice = (count/total)*2*PI arc using SVG path d attribute
     Green for developer, blue for company, red for admin
   - "Users" tab: table with columns: avatar, name, email, role badge, joined date, submission count
     Per row: role change (select dropdown) + Delete button with confirmation modal
   - "Problems" tab: table with title, company name, status badge, submission count, created date
     Per row: status change + Delete button
   - "+ Create User" button opens modal with same fields as signup + role selector including "0"
```

---

### PROMPT 18 — AI/Automation Marketplace

```
Build the full AI/Automation Marketplace for SYNC.

The marketplace lets developers sell AI agents, automations, scripts, tools, templates, and APIs.
SQLite tables marketplace_listings, cart_items, purchases already exist from the DB schema.

CATEGORIES: automation(🤖), agent(🧠), tool(🛠️), template(📋), script(📜), api(🔌), other(📦)
CATEGORY_COLORS: each category gets a unique border/bg/text color combo.

1. src/app/api/marketplace/route.ts (GET + POST):
   - GET: SELECT active listings with seller name + avatar_color
     For current user add: in_cart (bool from cart_items), purchased (bool from purchases),
     purchase_count (COUNT from purchases). Supports ?category= and ?q= filters.
     JSON.parse tags with try/catch fallback. Return {listings}.
   - POST role="user": create listing with randomUUID id.
     Body: title, description, category, tags (array -> JSON.stringify), price, demo_url, repo_url, status.

2. src/app/api/marketplace/[id]/route.ts (PATCH + DELETE):
   - Verify seller_id === session.sub OR session.role === "0". Else 403.
   - PATCH: update any provided fields. If tags provided, JSON.stringify.
   - DELETE: delete listing.

3. src/app/api/marketplace/mine/route.ts (GET role="user"):
   - Own listings with purchase_count per listing.

4. src/app/api/marketplace/purchased/route.ts (GET any role):
   - JOIN purchases -> marketplace_listings -> seller user
   - Return title, description, category, tags, demo_url, repo_url (revealed!), seller_name, price_paid, purchased_at

5. src/app/api/cart/route.ts (GET + POST + DELETE + PATCH):
   - GET: cart_items JOIN marketplace_listings JOIN seller user. Return {cart: items[], total: number, count}
   - POST {listing_id}: Guard: listing must be active, not your own (seller_id != you), not already purchased.
     INSERT OR IGNORE -> if 0 changes, listing already in cart -> 409.
   - DELETE {listing_id}: DELETE WHERE user_id=me AND listing_id=?
   - PATCH checkout: SQLite transaction ->
     SELECT all cart items, INSERT OR IGNORE INTO purchases for each, DELETE FROM cart_items WHERE user_id=me
     Return {purchased: count}

6. src/app/marketplace/page.tsx (useAuth all roles):
   - Header: title "Marketplace", description. Right: cart button with badge + "Sell Your Product" link (dev only)
   - Category filter buttons row (All + each category, active = purple highlight)
   - Search input
   - Listing count text
   - CSS grid (1 col mobile, 2 col sm, 3 col lg) of listing cards:
     Seller avatar (colored circle + initial) + name, category badge (color-coded), title (bold),
     description (3-line clamp), tags (first 3 as chips + overflow count), price (green bold),
     sold count, bottom action: "Add to Cart" quick button or status badge (In Cart/Owned/Your listing)
   - Click card -> ListingDetailModal:
     Seller info, category + sold count, full description in a panel,
     all tags, demo section (if YouTube URL -> iframe embed, else link button),
     price + CTA (Add to Cart / Remove from Cart / Owned badge / Your listing)
   - Cart icon opens CartDrawer (slides in from right):
     List of cart items (avatar, title, seller, price, remove button)
     Total price, "Checkout" button -> PATCH /api/cart
     Success message shown in header area
   - handleCartChange(id, inCart): updates listings state + refreshes cart data

7. src/app/developer-dashboard/marketplace/page.tsx (useAuth ["user"]):
   - Stats row: listings count, active count, total sales, estimated revenue ($)
   - Tab bar: "My Listings" | "My Purchases"
   - My Listings tab:
     Empty state with "Create Listing" CTA
     List rows: title, status badge, category badge, tags, price/sales/revenue columns,
     Demo link, Edit button, Delete button
   - My Purchases tab:
     Empty state with "Browse Marketplace" link
     Cards: seller name, title, description, tags, price paid, Demo link, Repo/Download link
   - "+ New Listing" header button -> CreateEditModal
   - CreateEditModal (create and edit via same modal, initial prop):
     Fields: Title*, Description* (textarea), Category select, Status select,
     Price ($ prefix, 0=Free), Tags (comma-separated), Demo URL (hint: YouTube auto-embeds),
     Repo URL (hint: shared with buyers only)
     POST /api/marketplace (create) or PATCH /api/marketplace/[id] (edit)
   - DeleteConfirmModal with listing title, Cancel/Delete buttons
   - State: modalOpen bool + editListing (MyListing | null) -- separate from each other to avoid type issues
```

---

### FINAL PROMPT — Wiring, Robustness & Build Check

```
Final integration and hardening for the SYNC platform:

1. Verify every page that uses data starts with a loading spinner:
   if (loading || !profile) return <div className="flex min-h-screen items-center justify-center bg-black"><div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>

2. In db.ts: NEVER place ALTER TABLE statements inside db.exec() — they fail on subsequent starts (duplicate column).
   Always put ALTER TABLE statements in the separate idempotent try/catch loop after exec().

3. In next.config.ts confirm: serverExternalPackages: ["better-sqlite3"]
   Without this, better-sqlite3 native module fails to load in Next.js API routes.

4. All JSON stored in SQLite (tags, skills, experience) must use JSON.stringify on write.
   On read, always use a safeJson helper:
   function safeJson(v: unknown, fallback: unknown) { try { return JSON.parse(v as string); } catch { return fallback; } }

5. COOKIE_NAME must be the same constant ("sync-session") used in every API route, middleware, and session.ts.
   Import it from @/lib/session everywhere, never hardcode the string.

6. For better-sqlite3 in Next.js: use a module-level singleton _db with let _db: Database | null = null.
   Never create a new Database() on every request — it causes SQLITE_BUSY in concurrent scenarios.

7. All marketplace listing/cart API routes must verify the session before any DB operation.
   Use a shared getSession(req) helper that reads the cookie and calls verifySession.

8. Run npm run build to verify zero TypeScript compilation errors.
   Fix any "no overlap" type comparison errors (common when state is typed as union with string literal).

9. For the messages page auto-open: use useRef(false) as a guard (autoOpenedRef).
   Only trigger auto-open once after friends finish loading, not on every re-render.

10. The notification bell href for DM notifications must be /developer-dashboard/messages?with=SENDER_ID
    The messages page reads this with useSearchParams() and auto-opens the right chat.
    Import useSearchParams from next/navigation. Wrap usage in Suspense if needed for build.
```

---

*Built with love by a developer, for developers.*

