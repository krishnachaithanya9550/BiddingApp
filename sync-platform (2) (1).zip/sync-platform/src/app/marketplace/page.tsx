"use client";

import { useEffect, useState, useCallback } from "react";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import { cn } from "@/lib/utils";

// ---- Types ------------------------------------------------------------------

interface Listing {
  id: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  price: number;
  demo_url: string;
  status: string;
  created_at: string;
  seller_name: string;
  seller_avatar_color: string;
  purchase_count: number;
  in_cart: boolean;
  purchased: boolean;
  seller_id?: string;
}

interface CartItem {
  cart_item_id: string;
  id: string;
  title: string;
  description: string;
  price: number;
  demo_url: string;
  seller_name: string;
  seller_avatar_color: string;
  tags: string[];
}

// ---- Constants --------------------------------------------------------------

const CATEGORIES = [
  { value: "all",        label: "All",             icon: "⚡" },
  { value: "automation", label: "Automation",       icon: "🤖" },
  { value: "agent",      label: "AI Agents",        icon: "🧠" },
  { value: "tool",       label: "Dev Tools",        icon: "🛠️" },
  { value: "template",   label: "Templates",        icon: "📋" },
  { value: "script",     label: "Scripts",          icon: "📜" },
  { value: "api",        label: "APIs / Wrappers",  icon: "🔌" },
  { value: "other",      label: "Other",            icon: "📦" },
];

const CATEGORY_COLORS: Record<string, string> = {
  automation: "border-cyan-500/30 bg-cyan-500/10 text-cyan-400",
  agent:      "border-purple-500/30 bg-purple-500/10 text-purple-400",
  tool:       "border-yellow-500/30 bg-yellow-500/10 text-yellow-400",
  template:   "border-blue-500/30 bg-blue-500/10 text-blue-400",
  script:     "border-orange-500/30 bg-orange-500/10 text-orange-400",
  api:        "border-pink-500/30 bg-pink-500/10 text-pink-400",
  other:      "border-white/20 bg-white/5 text-secondary",
};

// ---- ListingDetailModal -----------------------------------------------

function ListingDetailModal({
  listing,
  onClose,
  onCartChange,
  isSelf,
}: {
  listing: Listing;
  onClose: () => void;
  onCartChange: (id: string, inCart: boolean) => void;
  isSelf: boolean;
}) {
  const [cartLoading, setCartLoading] = useState(false);
  const [cartMsg, setCartMsg]         = useState("");

  async function toggleCart() {
    setCartLoading(true); setCartMsg("");
    const method = listing.in_cart ? "DELETE" : "POST";
    const res = await fetch("/api/cart", {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ listing_id: listing.id }),
    });
    const d = await res.json();
    if (res.ok) {
      onCartChange(listing.id, !listing.in_cart);
    } else {
      setCartMsg(d.error ?? "Failed.");
    }
    setCartLoading(false);
  }

  const catStyle = CATEGORY_COLORS[listing.category] ?? CATEGORY_COLORS.other;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/75 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-2xl rounded-3xl border border-white/10 bg-black/95 shadow-2xl overflow-y-auto max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/8 bg-black/95 px-7 py-5" style={{ backdropFilter: "blur(20px)" }}>
          <div className="flex items-center gap-3 min-w-0">
            <div
              className="h-10 w-10 shrink-0 rounded-xl flex items-center justify-center text-base font-black text-black"
              style={{ background: listing.seller_avatar_color || "#22c55e" }}
            >
              {listing.seller_name.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0">
              <p className="font-extrabold text-white truncate">{listing.title}</p>
              <p className="text-xs text-secondary">by {listing.seller_name}</p>
            </div>
          </div>
          <button onClick={onClose} className="ml-4 shrink-0 rounded-full p-1.5 text-secondary hover:text-white transition-colors">
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="p-7">
          {/* Meta */}
          <div className="flex flex-wrap items-center gap-2 mb-5">
            <span className={cn("rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider", catStyle)}>
              {CATEGORIES.find((c) => c.value === listing.category)?.icon} {listing.category}
            </span>
            <span className="rounded-full border border-white/10 px-2.5 py-0.5 text-[10px] text-secondary">
              🛒 {listing.purchase_count} sold
            </span>
            <span className="text-[10px] text-secondary">
              {new Date(listing.created_at).toLocaleDateString()}
            </span>
          </div>

          {/* Description */}
          <div className="mb-6 rounded-2xl border border-white/8 bg-white/3 p-5">
            <p className="text-sm text-white/90 leading-relaxed whitespace-pre-wrap">{listing.description}</p>
          </div>

          {/* Tags */}
          {listing.tags.length > 0 && (
            <div className="mb-6 flex flex-wrap gap-1.5">
              {listing.tags.map((t) => (
                <span key={t} className="rounded-full border border-primary/20 bg-primary/5 px-2.5 py-0.5 text-xs text-primary">{t}</span>
              ))}
            </div>
          )}

          {/* Demo */}
          {listing.demo_url && (
            <div className="mb-6">
              <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-secondary">Live Demo</p>
              {listing.demo_url.includes("youtube.com") || listing.demo_url.includes("youtu.be") ? (
                <div className="relative w-full rounded-2xl overflow-hidden border border-white/8" style={{ paddingBottom: "56.25%" }}>
                  <iframe
                    src={listing.demo_url.replace("watch?v=", "embed/").replace("youtu.be/", "www.youtube.com/embed/")}
                    className="absolute inset-0 h-full w-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
              ) : (
                <a
                  href={listing.demo_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-5 py-3 text-sm font-semibold text-white hover:bg-white/10 transition-colors"
                >
                  View Demo ↗
                </a>
              )}
            </div>
          )}

          {/* Purchase area */}
          <div className="flex items-center justify-between rounded-2xl border border-white/8 bg-white/3 p-5">
            <div>
              <p className="text-3xl font-black text-primary">
                {listing.price === 0 ? "Free" : `$${listing.price.toFixed(2)}`}
              </p>
              {listing.price > 0 && <p className="text-xs text-secondary mt-0.5">One-time payment</p>}
            </div>
            {listing.purchased ? (
              <div className="rounded-2xl border border-primary/30 bg-primary/10 px-5 py-2.5 text-sm font-bold text-primary">
                ✓ Purchased
              </div>
            ) : isSelf ? (
              <div className="rounded-2xl border border-white/10 px-5 py-2.5 text-sm font-semibold text-secondary">
                Your listing
              </div>
            ) : (
              <div className="flex flex-col items-end gap-2">
                {cartMsg && <p className="text-xs text-red-400">{cartMsg}</p>}
                <button
                  onClick={toggleCart}
                  disabled={cartLoading}
                  className={cn(
                    "rounded-2xl px-6 py-2.5 text-sm font-bold transition-all disabled:opacity-40",
                    listing.in_cart
                      ? "border border-red-500/30 bg-red-500/10 text-red-400 hover:bg-red-500/20"
                      : "bg-primary text-black hover:opacity-90"
                  )}
                >
                  {cartLoading ? "…" : listing.in_cart ? "Remove from Cart" : "Add to Cart"}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ---- CartDrawer ------------------------------------------------------------

function CartDrawer({
  cart,
  total,
  onClose,
  onRemove,
  onCheckout,
  checkingOut,
}: {
  cart: CartItem[];
  total: number;
  onClose: () => void;
  onRemove: (listing_id: string) => void;
  onCheckout: () => void;
  checkingOut: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 flex justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative flex h-full w-full max-w-sm flex-col border-l border-white/10 bg-black/95 shadow-2xl"
        style={{ backdropFilter: "blur(20px)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-white/8 px-6 py-5">
          <h2 className="text-lg font-extrabold text-white">Cart ({cart.length})</h2>
          <button onClick={onClose} className="rounded-full p-1.5 text-secondary hover:text-white transition-colors">
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
          {cart.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center py-12">
              <p className="text-4xl mb-3">🛒</p>
              <p className="font-semibold text-white">Your cart is empty</p>
              <p className="text-xs text-secondary mt-1">Browse the marketplace to add items</p>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.cart_item_id} className="flex items-start gap-3 rounded-2xl border border-white/8 bg-white/3 p-4">
                <div
                  className="h-10 w-10 shrink-0 rounded-xl flex items-center justify-center text-base font-black text-black"
                  style={{ background: item.seller_avatar_color || "#22c55e" }}
                >
                  {item.seller_name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-white text-sm truncate">{item.title}</p>
                  <p className="text-xs text-secondary truncate">by {item.seller_name}</p>
                  <p className="mt-1 font-black text-primary text-sm">
                    {item.price === 0 ? "Free" : `$${item.price.toFixed(2)}`}
                  </p>
                </div>
                <button
                  onClick={() => onRemove(item.id)}
                  className="shrink-0 rounded-lg border border-red-500/20 bg-red-500/5 p-1.5 text-red-400 hover:bg-red-500/15 transition-colors"
                >
                  <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div className="border-t border-white/8 px-6 py-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-secondary">Total</span>
              <span className="text-2xl font-black text-primary">
                {total === 0 ? "Free" : `$${total.toFixed(2)}`}
              </span>
            </div>
            <button
              onClick={onCheckout}
              disabled={checkingOut}
              className="w-full rounded-2xl bg-primary py-3 text-sm font-bold text-black hover:opacity-90 transition-opacity disabled:opacity-40"
            >
              {checkingOut ? "Processing…" : `Checkout (${cart.length} item${cart.length > 1 ? "s" : ""})`}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ---- Main Page -------------------------------------------------------------

export default function MarketplacePage() {
  const { profile, loading } = useAuth();

  const [listings, setListings]         = useState<Listing[]>([]);
  const [dataLoading, setDataLoading]   = useState(true);
  const [search, setSearch]             = useState("");
  const [category, setCategory]         = useState("all");
  const [selected, setSelected]         = useState<Listing | null>(null);
  const [cart, setCart]                 = useState<CartItem[]>([]);
  const [cartTotal, setCartTotal]       = useState(0);
  const [cartOpen, setCartOpen]         = useState(false);
  const [cartLoading, setCartLoading]   = useState(false);
  const [checkingOut, setCheckingOut]   = useState(false);
  const [checkoutMsg, setCheckoutMsg]   = useState("");

  const loadListings = useCallback(async () => {
    setDataLoading(true);
    try {
      const params = new URLSearchParams();
      if (category !== "all") params.set("category", category);
      if (search)             params.set("q", search);
      const res = await fetch(`/api/marketplace?${params}`);
      if (!res.ok) return;
      const d = await res.json();
      setListings(d.listings ?? []);
    } finally {
      setDataLoading(false);
    }
  }, [category, search]);

  async function loadCart() {
    const res = await fetch("/api/cart");
    if (!res.ok) return;
    const d = await res.json();
    setCart(d.cart ?? []);
    setCartTotal(d.total ?? 0);
  }

  useEffect(() => { if (profile) { loadListings(); loadCart(); } }, [profile, loadListings]);

  function handleCartChange(listingId: string, inCart: boolean) {
    setListings((prev) => prev.map((l) => l.id === listingId ? { ...l, in_cart: inCart } : l));
    if (selected?.id === listingId) setSelected((s) => s ? { ...s, in_cart: inCart } : s);
    loadCart();
  }

  async function removeFromCart(listingId: string) {
    setCartLoading(true);
    await fetch("/api/cart", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ listing_id: listingId }),
    });
    handleCartChange(listingId, false);
    setCartLoading(false);
  }

  async function checkout() {
    setCheckingOut(true); setCheckoutMsg("");
    const res = await fetch("/api/cart", { method: "PATCH" });
    const d = await res.json();
    if (res.ok) {
      setCheckoutMsg(`✓ Successfully purchased ${d.purchased} item${d.purchased > 1 ? "s" : ""}!`);
      setCartOpen(false);
      loadCart();
      loadListings();
      setTimeout(() => setCheckoutMsg(""), 4000);
    } else {
      setCheckoutMsg(d.error ?? "Checkout failed.");
    }
    setCheckingOut(false);
  }

  if (loading || !profile) return <LoadingSkeleton />;

  const cartCount = cart.length;

  return (
    <DashboardShell profile={profile}>

      {/* Header */}
      <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="mb-1 text-[10px] font-semibold uppercase tracking-widest text-purple-400">AI & Automation</p>
          <h1 className="text-3xl font-extrabold text-white">Marketplace</h1>
          <p className="mt-1 text-secondary text-sm">Discover AI agents, automations, and dev tools built by the community.</p>
        </div>
        <div className="flex items-center gap-3">
          {checkoutMsg && (
            <span className={cn("text-xs font-semibold", checkoutMsg.startsWith("✓") ? "text-primary" : "text-red-400")}>
              {checkoutMsg}
            </span>
          )}
          {/* Cart button */}
          <button
            onClick={() => setCartOpen(true)}
            className="relative flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10 transition-colors"
          >
            🛒 Cart
            {cartCount > 0 && (
              <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-black text-black">
                {cartCount}
              </span>
            )}
          </button>
          {/* List your product (developer only) */}
          {profile.role === "user" && (
            <a
              href="/developer-dashboard/marketplace"
              className="rounded-2xl border border-primary/30 bg-primary/10 px-4 py-2 text-sm font-bold text-primary hover:bg-primary/20 transition-colors"
            >
              + Sell Your Product
            </a>
          )}
        </div>
      </div>

      {/* Search + categories */}
      <div className="mb-6 space-y-3">
        <input
          className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-secondary/50 outline-none focus:border-purple-500/40 transition-colors"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search agents, automations, tools…"
        />
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c.value}
              onClick={() => setCategory(c.value)}
              className={cn(
                "flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition-all",
                category === c.value
                  ? "border-purple-500/40 bg-purple-500/15 text-purple-300"
                  : "border-white/10 text-secondary hover:border-white/20 hover:text-white"
              )}
            >
              <span>{c.icon}</span> {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Listing count */}
      <p className="mb-5 text-xs text-secondary">
        <span className="font-bold text-white">{listings.length}</span> product{listings.length !== 1 ? "s" : ""} found
      </p>

      {/* Grid */}
      {dataLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => <div key={i} className="h-64 animate-pulse rounded-2xl border border-white/5 bg-white/3" />)}
        </div>
      ) : listings.length === 0 ? (
        <div className="rounded-2xl border border-white/8 bg-white/3 p-16 text-center">
          <p className="text-5xl mb-4">🤖</p>
          <p className="text-lg font-bold text-white mb-1">Nothing here yet</p>
          <p className="text-sm text-secondary">Be the first to list an automation or agent!</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {listings.map((listing) => {
            const catStyle = CATEGORY_COLORS[listing.category] ?? CATEGORY_COLORS.other;
            const isSelf = listing.seller_id === profile.id;
            return (
              <div
                key={listing.id}
                onClick={() => setSelected(listing)}
                className="group relative flex flex-col rounded-2xl border border-white/8 bg-gradient-to-br from-white/3 to-transparent p-5 cursor-pointer transition-all duration-300 hover:border-purple-500/30 hover:shadow-lg"
              >
                {/* Seller + category */}
                <div className="mb-3 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div
                      className="h-8 w-8 shrink-0 rounded-full flex items-center justify-center text-xs font-black text-black"
                      style={{ background: listing.seller_avatar_color || "#22c55e" }}
                    >
                      {listing.seller_name.charAt(0).toUpperCase()}
                    </div>
                    <span className="text-xs text-secondary truncate">{listing.seller_name}</span>
                  </div>
                  <span className={cn("shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider", catStyle)}>
                    {listing.category}
                  </span>
                </div>

                {/* Title + description */}
                <h3 className="mb-1.5 font-extrabold text-white group-hover:text-purple-300 transition-colors">{listing.title}</h3>
                <p className="flex-1 text-xs text-secondary leading-relaxed line-clamp-3">{listing.description}</p>

                {/* Tags */}
                {listing.tags.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1">
                    {listing.tags.slice(0, 3).map((t) => (
                      <span key={t} className="rounded-full border border-primary/20 bg-primary/5 px-2 py-0.5 text-[10px] text-primary">{t}</span>
                    ))}
                    {listing.tags.length > 3 && <span className="text-[10px] text-secondary">+{listing.tags.length - 3}</span>}
                  </div>
                )}

                {/* Footer */}
                <div className="mt-4 flex items-center justify-between border-t border-white/5 pt-3">
                  <span className="font-black text-primary">
                    {listing.price === 0 ? "Free" : `$${listing.price.toFixed(2)}`}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-secondary">{listing.purchase_count} sold</span>
                    {listing.purchased ? (
                      <span className="rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-[10px] font-bold text-primary">✓ Owned</span>
                    ) : isSelf ? (
                      <span className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] text-secondary">Your listing</span>
                    ) : listing.in_cart ? (
                      <span className="rounded-full border border-yellow-500/30 bg-yellow-500/10 px-2 py-0.5 text-[10px] font-bold text-yellow-400">In Cart</span>
                    ) : (
                      <button
                        onClick={async (e) => {
                          e.stopPropagation();
                          const res = await fetch("/api/cart", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ listing_id: listing.id }),
                          });
                          if (res.ok) handleCartChange(listing.id, true);
                        }}
                        className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] font-semibold text-secondary hover:border-primary/30 hover:text-primary transition-all"
                      >
                        + Add to Cart
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {selected && (
        <ListingDetailModal
          listing={selected}
          onClose={() => setSelected(null)}
          onCartChange={handleCartChange}
          isSelf={selected.seller_id === profile.id}
        />
      )}

      {cartOpen && (
        <CartDrawer
          cart={cart}
          total={cartTotal}
          onClose={() => setCartOpen(false)}
          onRemove={removeFromCart}
          onCheckout={checkout}
          checkingOut={checkingOut}
        />
      )}

    </DashboardShell>
  );
}

function LoadingSkeleton() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-purple-400 border-t-transparent" />
    </div>
  );
}
