"use client";

import { useEffect, useState, useMemo } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import {
  getCompanyProblems,
  getCompanySubmissions,
  updateSubmissionStatus,
} from "@/lib/problems";
import { cn } from "@/lib/utils";
import type { Problem, Submission } from "@/types";

// ─── Constants ────────────────────────────────────────────────────────────────

const SUB_STATUS: Record<
  Submission["status"],
  { label: string; color: string; dot: string }
> = {
  pending:  { label: "Pending",  color: "border-yellow-500/30 bg-yellow-500/10 text-yellow-400",  dot: "bg-yellow-400"  },
  accepted: { label: "Accepted", color: "border-primary/30 bg-primary/10 text-primary",           dot: "bg-primary"     },
  rejected: { label: "Rejected", color: "border-red-500/30 bg-red-500/10 text-red-400",           dot: "bg-red-400"     },
};

const DEV_STATUS_STYLE: Record<string, { label: string; color: string; dot: string }> = {
  available:      { label: "Available",      color: "text-primary",    dot: "bg-primary" },
  open_to_offers: { label: "Open to Offers", color: "text-yellow-400", dot: "bg-yellow-400" },
  busy:           { label: "Unavailable",    color: "text-red-400",    dot: "bg-red-400" },
};

type FilterStatus = "all" | Submission["status"];

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function SubmissionsPage() {
  const { profile, loading } = useAuth(["0", "company"]);
  const searchParams = useSearchParams();

  const [problems,     setProblems]     = useState<Problem[]>([]);
  const [submissions,  setSubmissions]  = useState<Submission[]>([]);
  const [dataLoading,  setDataLoading]  = useState(true);
  const [error,        setError]        = useState<string | null>(null);

  // Filters — initialise selectedProblem from ?problem= query param
  const [selectedProblem, setSelectedProblem] = useState<string>(
    searchParams.get("problem") ?? "all"
  );
  const [statusFilter, setStatusFilter] = useState<FilterStatus>("all");
  const [search,          setSearch]          = useState("");

  // Submission action state: submissionId → loading|null
  const [actionLoading, setActionLoading] = useState<Record<string, boolean>>({});
  const [actionError,   setActionError]   = useState<string | null>(null);

  // Expanded submission detail modal
  const [expanded, setExpanded] = useState<Submission | null>(null);
  // Dev profile overlay (opened from inside submission modal)
  const [devProfile, setDevProfile] = useState<Submission | null>(null);

  // ── Fetch data ──────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!profile) return;

    Promise.all([
      getCompanyProblems(profile.id),
      getCompanySubmissions(profile.id),
    ]).then(([p, s]) => {
      if (p.error) setError(p.error);
      else if (s.error) setError(s.error);
      setProblems(p.problems);
      setSubmissions(s.submissions);
      setDataLoading(false);
    });
  }, [profile]);

  // ── Filtered view ───────────────────────────────────────────────────────────
  const filtered = useMemo(() => {
    return submissions.filter((s) => {
      if (selectedProblem !== "all" && s.problem_id !== selectedProblem) return false;
      if (statusFilter    !== "all" && s.status      !== statusFilter)    return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          s.developer_name?.toLowerCase().includes(q) ||
          s.developer_email?.toLowerCase().includes(q) ||
          s.problem_title?.toLowerCase().includes(q) ||
          s.proposal.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [submissions, selectedProblem, statusFilter, search]);

  // ── Stats ───────────────────────────────────────────────────────────────────
  const stats = useMemo(() => ({
    total:    submissions.length,
    pending:  submissions.filter((s) => s.status === "pending").length,
    accepted: submissions.filter((s) => s.status === "accepted").length,
    rejected: submissions.filter((s) => s.status === "rejected").length,
  }), [submissions]);

  // ── Action: accept / reject ─────────────────────────────────────────────────
  async function handleAction(
    submission: Submission,
    newStatus: "accepted" | "rejected"
  ) {
    setActionError(null);
    setActionLoading((prev) => ({ ...prev, [submission.id]: true }));

    const { error: err } = await updateSubmissionStatus(submission.id, newStatus);

    if (err) {
      setActionError(err);
    } else {
      setSubmissions((prev) =>
        prev.map((s) => (s.id === submission.id ? { ...s, status: newStatus } : s))
      );
      // Keep expanded in sync
      if (expanded?.id === submission.id) {
        setExpanded((prev) => prev ? { ...prev, status: newStatus } : null);
      }
    }

    setActionLoading((prev) => ({ ...prev, [submission.id]: false }));
  }

  // ─────────────────────────────────────────────────────────────────────────────

  if (loading || !profile) return <LoadingSkeleton />;

  return (
    <DashboardShell profile={profile}>

      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="mb-8 flex items-center gap-2 text-sm text-secondary">
        <Link href="/company-dashboard" className="hover:text-white transition-colors">Dashboard</Link>
        <span aria-hidden>/</span>
        <span className="text-white">Submissions</span>
      </nav>

      {/* Header */}
      <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-blue-400">
            Inbox
          </p>
          <h1 className="text-4xl font-extrabold text-white">Developer Submissions</h1>
          <p className="mt-2 text-secondary text-sm">
            Review proposals, accept or reject developers for your problems.
          </p>
        </div>
        <Link
          href="/post-problem"
          className="shrink-0 self-start rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-black transition-opacity hover:opacity-80"
        >
          + Post Problem
        </Link>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 mb-10">
        {[
          { label: "Total",    value: stats.total,    color: "text-white",         icon: "📥" },
          { label: "Pending",  value: stats.pending,  color: "text-yellow-400",    icon: "⏳" },
          { label: "Accepted", value: stats.accepted, color: "text-primary",       icon: "✅" },
          { label: "Rejected", value: stats.rejected, color: "text-red-400",       icon: "❌" },
        ].map((s) => (
          <button
            key={s.label}
            onClick={() => setStatusFilter(s.label.toLowerCase() as FilterStatus)}
            className={cn(
              "rounded-2xl border border-white/10 bg-white/5 p-5 text-left transition hover:border-white/20",
              statusFilter === s.label.toLowerCase() && "border-blue-500/40 bg-blue-500/5"
            )}
          >
            <p className={cn("text-3xl font-black", s.color)}>
              {dataLoading ? "…" : s.value}
            </p>
            <p className="mt-1 text-xs text-secondary uppercase tracking-wider flex items-center gap-1.5">
              <span>{s.icon}</span>{s.label}
            </p>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">

        {/* Search */}
        <div className="relative flex-1">
          <svg
            className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-secondary pointer-events-none"
            fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}
          >
            <path strokeLinecap="round" strokeLinejoin="round"
              d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z" />
          </svg>
          <input
            type="search"
            placeholder="Search by developer, problem or proposal…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-white/5 py-2.5 pl-10 pr-4 text-sm text-white placeholder-white/25 outline-none transition focus:border-primary focus:ring-1 focus:ring-primary"
          />
        </div>

        {/* Problem filter */}
        <select
          value={selectedProblem}
          onChange={(e) => setSelectedProblem(e.target.value)}
          className="rounded-xl border border-white/10 bg-[#111] px-4 py-2.5 text-sm text-white outline-none transition focus:border-primary"
        >
          <option value="all">All Problems</option>
          {problems.map((p) => (
            <option key={p.id} value={p.id}>{p.title}</option>
          ))}
        </select>

        {/* Status filter */}
        <div className="flex items-center gap-1 rounded-xl border border-white/10 bg-white/5 p-1">
          {(["all", "pending", "accepted", "rejected"] as FilterStatus[]).map((f) => (
            <button
              key={f}
              onClick={() => setStatusFilter(f)}
              className={cn(
                "rounded-lg px-3 py-1.5 text-xs font-semibold capitalize transition",
                statusFilter === f
                  ? "bg-white/10 text-white"
                  : "text-secondary hover:text-white"
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Error banner */}
      {(error || actionError) && (
        <div role="alert" className="mb-5 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">
          {error ?? actionError}
        </div>
      )}

      {/* Submissions list */}
      {dataLoading ? (
        <SkeletonList />
      ) : filtered.length === 0 ? (
        <EmptyState
          hasProblems={problems.length > 0}
          hasSubmissions={submissions.length > 0}
          onClearFilters={() => {
            setStatusFilter("all");
            setSelectedProblem("all");
            setSearch("");
          }}
        />
      ) : (
        <div className="flex flex-col gap-3">
          {filtered.map((sub) => (
            <SubmissionCard
              key={sub.id}
              submission={sub}
              isLoading={!!actionLoading[sub.id]}
              onExpand={() => setExpanded(sub)}
              onAccept={() => handleAction(sub, "accepted")}
              onReject={() => handleAction(sub, "rejected")}
            />
          ))}
          <p className="mt-2 text-center text-xs text-white/25">
            Showing {filtered.length} of {submissions.length} submission{submissions.length !== 1 ? "s" : ""}
          </p>
        </div>
      )}

      {/* Detail Modal */}
      {expanded && (
        <SubmissionModal
          submission={expanded}
          isLoading={!!actionLoading[expanded.id]}
          onClose={() => setExpanded(null)}
          onAccept={() => handleAction(expanded, "accepted")}
          onReject={() => handleAction(expanded, "rejected")}
          onViewProfile={() => { setDevProfile(expanded); setExpanded(null); }}
        />
      )}

      {/* Dev profile overlay */}
      {devProfile && (
        <DevProfileOverlay submission={devProfile} onClose={() => setDevProfile(null)} />
      )}

    </DashboardShell>
  );
}

// ─── Submission Card ──────────────────────────────────────────────────────────

interface CardProps {
  submission: Submission;
  isLoading: boolean;
  onExpand: () => void;
  onAccept: () => void;
  onReject: () => void;
}

function SubmissionCard({ submission: s, isLoading, onExpand, onAccept, onReject }: CardProps) {
  const badge = SUB_STATUS[s.status];

  return (
    <article className="rounded-2xl border border-white/10 bg-white/5 px-6 py-5 transition hover:border-white/20">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">

        {/* Left: developer + problem info */}
        <div className="flex items-start gap-4 flex-1 min-w-0">
          {/* Avatar */}
          <div className="shrink-0 h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-sm font-bold text-white uppercase select-none">
            {s.developer_name?.charAt(0) ?? "?"}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <span className="font-semibold text-white">
                {s.developer_name ?? "Unknown Developer"}
              </span>
              <span className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold",
                badge.color
              )}>
                <span className={cn("h-1.5 w-1.5 rounded-full", badge.dot)} />
                {badge.label}
              </span>
            </div>
            {s.developer_email && (
              <p className="text-xs text-secondary truncate mb-2">{s.developer_email}</p>
            )}
            {s.problem_title && (
              <p className="text-xs text-blue-400 mb-2">
                📋 {s.problem_title}
              </p>
            )}
            {/* Proposal preview */}
            <p className="text-sm text-secondary line-clamp-2 leading-relaxed">
              {s.proposal}
            </p>
            <p className="mt-2 text-xs text-white/25">
              Submitted {new Date(s.created_at).toLocaleDateString("en-US", {
                day: "numeric", month: "short", year: "numeric"
              })}
            </p>
          </div>
        </div>

        {/* Right: actions */}
        <div className="flex shrink-0 items-center gap-2 sm:flex-col sm:items-end">
          <button
            onClick={onExpand}
            className="rounded-lg border border-white/10 px-3 py-1.5 text-xs font-semibold text-secondary transition hover:border-white/30 hover:text-white"
          >
            View Full
          </button>

          {s.status === "pending" && (
            <div className="flex items-center gap-2">
              <button
                onClick={onAccept}
                disabled={isLoading}
                className="rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-black transition-opacity hover:opacity-80 disabled:opacity-40"
              >
                {isLoading ? "…" : "Accept"}
              </button>
              <button
                onClick={onReject}
                disabled={isLoading}
                className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-xs font-bold text-red-400 transition hover:bg-red-500/20 disabled:opacity-40"
              >
                {isLoading ? "…" : "Reject"}
              </button>
            </div>
          )}

          {s.status === "accepted" && (
            <button
              onClick={onReject}
              disabled={isLoading}
              className="rounded-lg border border-white/10 px-3 py-1.5 text-xs font-semibold text-secondary transition hover:border-red-500/30 hover:text-red-400 disabled:opacity-40"
            >
              Revoke
            </button>
          )}

          {s.status === "rejected" && (
            <button
              onClick={onAccept}
              disabled={isLoading}
              className="rounded-lg border border-white/10 px-3 py-1.5 text-xs font-semibold text-secondary transition hover:border-primary/30 hover:text-primary disabled:opacity-40"
            >
              Reconsider
            </button>
          )}
        </div>
      </div>
    </article>
  );
}

// ─── Detail Modal ─────────────────────────────────────────────────────────────

interface ModalProps {
  submission: Submission;
  isLoading: boolean;
  onClose: () => void;
  onAccept: () => void;
  onReject: () => void;
  onViewProfile: () => void;
}

function SubmissionModal({ submission: s, isLoading, onClose, onAccept, onReject, onViewProfile }: ModalProps) {
  const badge = SUB_STATUS[s.status];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Submission detail"
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Panel */}
      <div className="relative z-10 w-full max-w-xl rounded-3xl border border-white/10 bg-[#0a0a0a] p-8 shadow-2xl">

        {/* Close */}
        <button
          onClick={onClose}
          className="absolute right-5 top-5 rounded-full p-1.5 text-secondary transition hover:bg-white/10 hover:text-white"
          aria-label="Close"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Developer header */}
        <div className="flex items-center gap-4 mb-6">
          <div
            className="h-14 w-14 rounded-full flex items-center justify-center text-xl font-bold text-black uppercase select-none shrink-0"
            style={{ background: (s as Submission & { developer_avatar_color?: string }).developer_avatar_color || "#22c55e" }}
          >
            {s.developer_name?.charAt(0) ?? "?"}
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-xl font-extrabold text-white">
              {s.developer_name ?? "Unknown Developer"}
            </h2>
            {s.developer_email && (
              <p className="text-sm text-secondary">{s.developer_email}</p>
            )}
            {s.developer_working_status && (
              <span className={cn("text-xs font-semibold",
                s.developer_working_status === "available" ? "text-primary" :
                s.developer_working_status === "open_to_offers" ? "text-yellow-400" : "text-red-400"
              )}>
                ● {s.developer_working_status === "available" ? "Available" : s.developer_working_status === "open_to_offers" ? "Open to Offers" : "Unavailable"}
              </span>
            )}
          </div>
          <span className={cn(
            "ml-auto inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold shrink-0",
            badge.color
          )}>
            <span className={cn("h-1.5 w-1.5 rounded-full", badge.dot)} />
            {badge.label}
          </span>
        </div>

        {/* Developer stats */}
        {(s.developer_contributions !== undefined || s.developer_rank !== undefined) && (
          <div className="mb-5 grid grid-cols-3 gap-2">
            {[
              { label: "Rank",          value: s.developer_rank ? `#${s.developer_rank}` : "—" },
              { label: "Contributions", value: String(s.developer_contributions ?? 0) },
              { label: "Hours Est.",    value: s.estimated_hours ? `${s.estimated_hours}h` : "—" },
            ].map((stat) => (
              <div key={stat.label} className="rounded-xl border border-white/8 bg-white/3 p-3 text-center">
                <p className="text-lg font-black text-primary">{stat.value}</p>
                <p className="text-[10px] text-secondary uppercase tracking-wider">{stat.label}</p>
              </div>
            ))}
          </div>
        )}

        {/* Bio */}
        {s.developer_bio && (
          <div className="mb-4 rounded-xl border border-white/8 bg-white/3 px-4 py-3">
            <p className="text-xs font-semibold uppercase tracking-wider text-secondary mb-1">About</p>
            <p className="text-sm text-white/80">{s.developer_bio}</p>
          </div>
        )}

        {/* Skills */}
        {Array.isArray(s.developer_skills) && s.developer_skills.length > 0 && (
          <div className="mb-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-secondary mb-2">Skills</p>
            <div className="flex flex-wrap gap-1.5">
              {s.developer_skills.map((sk: string) => (
                <span key={sk} className="rounded-full border border-primary/20 bg-primary/5 px-2.5 py-0.5 text-xs text-primary">{sk}</span>
              ))}
            </div>
          </div>
        )}

        {/* External links */}
        {(s.developer_github || s.developer_linkedin || s.developer_portfolio) && (
          <div className="mb-5 flex flex-wrap gap-2">
            {s.developer_github && (
              <a href={s.developer_github} target="_blank" rel="noopener noreferrer"
                className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-secondary hover:text-white transition-colors">
                GitHub ↗
              </a>
            )}
            {s.developer_linkedin && (
              <a href={s.developer_linkedin} target="_blank" rel="noopener noreferrer"
                className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-secondary hover:text-white transition-colors">
                LinkedIn ↗
              </a>
            )}
            {s.developer_portfolio && (
              <a href={s.developer_portfolio} target="_blank" rel="noopener noreferrer"
                className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-secondary hover:text-white transition-colors">
                Portfolio ↗
              </a>
            )}
          </div>
        )}

        {/* Problem */}
        {s.problem_title && (
          <div className="mb-5 rounded-xl border border-white/10 bg-white/5 px-4 py-3">
            <p className="text-xs font-semibold uppercase tracking-wider text-secondary mb-1">Problem</p>
            <p className="text-sm text-white font-medium">{s.problem_title}</p>
          </div>
        )}

        {/* Proposal */}
        <div className="mb-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-secondary mb-2">Proposal</p>
          <div className="rounded-xl border border-white/10 bg-white/5 px-4 py-4 text-sm text-white/80 leading-relaxed whitespace-pre-wrap max-h-40 overflow-y-auto">
            {s.proposal}
          </div>
        </div>

        {/* Solution notes */}
        {s.solution_notes && (
          <div className="mb-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-secondary mb-2">Technical Notes</p>
            <div className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/80 leading-relaxed whitespace-pre-wrap max-h-32 overflow-y-auto">
              {s.solution_notes}
            </div>
          </div>
        )}

        {/* Tech stack */}
        {Array.isArray(s.tech_stack) && s.tech_stack.length > 0 && (
          <div className="mb-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-secondary mb-2">Tech Stack</p>
            <div className="flex flex-wrap gap-1.5">
              {s.tech_stack.map((t: string) => (
                <span key={t} className="rounded-full border border-blue-500/20 bg-blue-500/5 px-2.5 py-0.5 text-xs text-blue-400">{t}</span>
              ))}
            </div>
          </div>
        )}

        {/* Solution links */}
        {(s.repo_url || s.demo_url) && (
          <div className="mb-5 flex flex-wrap gap-2">
            {s.repo_url && (
              <a href={s.repo_url} target="_blank" rel="noopener noreferrer"
                className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs text-primary hover:bg-primary/10 transition-colors">
                📦 Repository ↗
              </a>
            )}
            {s.demo_url && (
              <a href={s.demo_url} target="_blank" rel="noopener noreferrer"
                className="rounded-lg border border-blue-500/20 bg-blue-500/5 px-3 py-1.5 text-xs text-blue-400 hover:bg-blue-500/10 transition-colors">
                🌐 Live Demo ↗
              </a>
            )}
          </div>
        )}

        {/* Date */}
        <p className="mb-6 text-xs text-white/30">
          Submitted on {new Date(s.created_at).toLocaleDateString("en-US", {
            weekday: "long", day: "numeric", month: "long", year: "numeric"
          })}
        </p>

        {/* Actions */}
        <div className="flex flex-col gap-3">
          {/* View Developer Profile button */}
          <button
            onClick={onViewProfile}
            className="w-full rounded-full border border-primary/30 bg-primary/5 py-2.5 text-sm font-bold text-primary hover:bg-primary/10 transition-colors"
          >
            🧑‍💻 View Developer Profile
          </button>
          <div className="flex items-center gap-3">
          {s.status === "pending" && (
            <>
              <button
                onClick={onAccept}
                disabled={isLoading}
                className="flex-1 rounded-full bg-primary py-3 text-sm font-bold text-black transition-opacity hover:opacity-80 disabled:opacity-40"
              >
                {isLoading ? "Saving…" : "✓ Accept Proposal"}
              </button>
              <button
                onClick={onReject}
                disabled={isLoading}
                className="flex-1 rounded-full border border-red-500/30 bg-red-500/10 py-3 text-sm font-bold text-red-400 transition hover:bg-red-500/20 disabled:opacity-40"
              >
                {isLoading ? "Saving…" : "✕ Reject"}
              </button>
            </>
          )}
          {s.status === "accepted" && (
            <>
              <p className="flex-1 text-sm text-primary font-semibold">✓ You accepted this proposal.</p>
              <button
                onClick={onReject}
                disabled={isLoading}
                className="rounded-full border border-white/10 px-5 py-2.5 text-sm text-secondary transition hover:border-red-500/30 hover:text-red-400 disabled:opacity-40"
              >
                Revoke
              </button>
            </>
          )}
          {s.status === "rejected" && (
            <>
              <p className="flex-1 text-sm text-red-400 font-semibold">✕ You rejected this proposal.</p>
              <button
                onClick={onAccept}
                disabled={isLoading}
                className="rounded-full border border-white/10 px-5 py-2.5 text-sm text-secondary transition hover:border-primary/30 hover:text-primary disabled:opacity-40"
              >
                Reconsider
              </button>
            </>
          )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Dev Profile Overlay ──────────────────────────────────────────────────────

function DevProfileOverlay({ submission: s, onClose }: { submission: Submission; onClose: () => void }) {
  const statusInfo = DEV_STATUS_STYLE[s.developer_working_status ?? ""] ?? DEV_STATUS_STYLE.busy;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-lg rounded-3xl border border-white/10 bg-black/90 p-7 shadow-2xl overflow-y-auto max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-secondary hover:text-white text-xl">✕</button>

        {/* Avatar + name */}
        <div className="flex items-center gap-4 mb-6">
          <div
            className="relative h-16 w-16 shrink-0 rounded-full flex items-center justify-center text-2xl font-black text-black"
            style={{ background: (s as Submission & { developer_avatar_color?: string }).developer_avatar_color || "#22c55e" }}
          >
            {s.developer_name?.charAt(0) ?? "?"}
            {s.developer_working_status && (
              <span className={cn("absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-black", statusInfo.dot)} />
            )}
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-white">{s.developer_name ?? "Unknown Developer"}</h2>
            {s.developer_working_status && (
              <p className={cn("text-sm font-semibold", statusInfo.color)}>● {statusInfo.label}</p>
            )}
            {s.developer_email && <p className="text-xs text-secondary">{s.developer_email}</p>}
          </div>
        </div>

        {/* Stats */}
        <div className="mb-5 grid grid-cols-3 gap-3">
          {[
            { label: "Rank",          value: s.developer_rank ? `#${s.developer_rank}` : "—" },
            { label: "Contributions", value: String(s.developer_contributions ?? 0) },
            { label: "Est. Hours",    value: s.estimated_hours ? `${s.estimated_hours}h` : "—" },
          ].map((stat) => (
            <div key={stat.label} className="rounded-xl border border-white/8 bg-white/3 p-3 text-center">
              <p className="text-lg font-black text-primary">{stat.value}</p>
              <p className="text-[10px] text-secondary uppercase tracking-wider">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Bio */}
        {s.developer_bio && (
          <div className="mb-5 rounded-xl border border-white/8 bg-white/3 px-4 py-3">
            <p className="text-xs font-bold uppercase tracking-widest text-secondary/60 mb-1">About</p>
            <p className="text-sm text-white/80 leading-relaxed">{s.developer_bio}</p>
          </div>
        )}

        {/* Skills */}
        {Array.isArray(s.developer_skills) && s.developer_skills.length > 0 && (
          <div className="mb-5">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-secondary/60">Skills</p>
            <div className="flex flex-wrap gap-1.5">
              {s.developer_skills.map((sk: string) => (
                <span key={sk} className="rounded-full border border-primary/20 bg-primary/5 px-2.5 py-0.5 text-xs text-primary">{sk}</span>
              ))}
            </div>
          </div>
        )}

        {/* External links */}
        {(s.developer_github || s.developer_linkedin || s.developer_portfolio) && (
          <div className="mb-5 flex flex-wrap gap-3">
            {s.developer_github && (
              <a href={s.developer_github} target="_blank" rel="noopener noreferrer"
                className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-secondary hover:text-white transition-colors">
                GitHub ↗
              </a>
            )}
            {s.developer_linkedin && (
              <a href={s.developer_linkedin} target="_blank" rel="noopener noreferrer"
                className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-secondary hover:text-white transition-colors">
                LinkedIn ↗
              </a>
            )}
            {s.developer_portfolio && (
              <a href={s.developer_portfolio} target="_blank" rel="noopener noreferrer"
                className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-secondary hover:text-white transition-colors">
                Portfolio ↗
              </a>
            )}
          </div>
        )}

        {/* Solution links */}
        {(s.repo_url || s.demo_url) && (
          <div className="flex flex-wrap gap-2">
            {s.repo_url && (
              <a href={s.repo_url} target="_blank" rel="noopener noreferrer"
                className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs text-primary hover:bg-primary/10 transition-colors">
                📦 Repository ↗
              </a>
            )}
            {s.demo_url && (
              <a href={s.demo_url} target="_blank" rel="noopener noreferrer"
                className="rounded-lg border border-blue-500/20 bg-blue-500/5 px-3 py-1.5 text-xs text-blue-400 hover:bg-blue-500/10 transition-colors">
                🌐 Live Demo ↗
              </a>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Empty State ──────────────────────────────────────────────────────────────

function EmptyState({
  hasProblems,
  hasSubmissions,
  onClearFilters,
}: {
  hasProblems: boolean;
  hasSubmissions: boolean;
  onClearFilters: () => void;
}) {
  if (!hasProblems) {
    return (
      <div className="rounded-2xl border border-dashed border-white/10 p-14 text-center">
        <p className="text-5xl mb-4">📭</p>
        <p className="text-lg font-bold text-white mb-2">No problems posted yet</p>
        <p className="text-sm text-secondary mb-8 max-w-xs mx-auto">
          Post your first problem to start attracting developer proposals.
        </p>
        <Link
          href="/post-problem"
          className="rounded-full bg-primary px-8 py-3 text-sm font-bold text-black transition-opacity hover:opacity-80"
        >
          Post a Problem
        </Link>
      </div>
    );
  }

  if (!hasSubmissions) {
    return (
      <div className="rounded-2xl border border-dashed border-white/10 p-14 text-center">
        <p className="text-5xl mb-4">⏳</p>
        <p className="text-lg font-bold text-white mb-2">No submissions yet</p>
        <p className="text-sm text-secondary mb-8 max-w-sm mx-auto">
          Your problems are live — developers can submit proposals. Check back soon.
        </p>
        <Link
          href="/company-dashboard"
          className="text-sm font-semibold text-blue-400 hover:text-white transition-colors"
        >
          ← Back to Dashboard
        </Link>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-dashed border-white/10 p-14 text-center">
      <p className="text-5xl mb-4">🔍</p>
      <p className="text-lg font-bold text-white mb-2">No matching submissions</p>
      <p className="text-sm text-secondary mb-6">Try adjusting your filters or search query.</p>
      <button
        onClick={onClearFilters}
        className="rounded-full border border-white/20 px-6 py-2.5 text-sm font-semibold text-secondary transition hover:border-white/40 hover:text-white"
      >
        Clear Filters
      </button>
    </div>
  );
}

// ─── Loading States ───────────────────────────────────────────────────────────

function SkeletonList() {
  return (
    <div className="flex flex-col gap-3">
      {Array.from({ length: 4 }).map((_, i) => (
        <div
          key={i}
          className="rounded-2xl border border-white/10 bg-white/5 px-6 py-5 animate-pulse"
        >
          <div className="flex items-start gap-4">
            <div className="h-10 w-10 rounded-full bg-white/10 shrink-0" />
            <div className="flex-1 flex flex-col gap-2.5">
              <div className="h-4 w-40 rounded bg-white/10" />
              <div className="h-3 w-64 rounded bg-white/10" />
              <div className="h-3 w-full max-w-sm rounded bg-white/10" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="flex flex-col items-center gap-4">
        <svg className="h-8 w-8 animate-spin text-blue-400" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
        </svg>
        <p className="text-sm text-secondary">Loading submissions…</p>
      </div>
    </div>
  );
}
