﻿"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
export default function BusinessDashboardRedirect() {
  const router = useRouter();
  useEffect(() => { router.replace("/company-dashboard"); }, [router]);
  return null;
}