﻿"use client";

import { useState, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { signIn } from "@/lib/auth";
import { getRoleHome } from "@/lib/rbac";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const nextPath = searchParams.get("next");

  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setError(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { profile, error: loginError } = await signIn({ email: form.email, password: form.password });
    setLoading(false);
    if (loginError) { setError(loginError); return; }
    if (!profile) { setError("Something went wrong. Please try again."); return; }
    router.push(nextPath ?? getRoleHome(profile.role));
  }

  return (
    <div className="w-full max-w-md mx-auto">
      <div
        className="relative rounded-3xl p-px overflow-hidden"
        style={{ background: "linear-gradient(135deg, rgba(34,197,94,0.3), rgba(34,197,94,0.05), rgba(34,197,94,0.15))" }}
      >
        <div className="rounded-3xl bg-black/90 p-8 sm:p-10" style={{ backdropFilter: "blur(40px)" }}>
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-2xl font-extrabold text-white mb-1">Welcome back</h1>
            <p className="text-sm text-secondary">
              Don&apos;t have an account?{" "}
              <Link href="/signup" className="font-semibold text-primary hover:opacity-80 transition-opacity">
                Create one free
              </Link>
            </p>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-5" noValidate>
            {/* Email */}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="email" className="text-xs font-semibold uppercase tracking-widest text-secondary">
                Email Address
              </label>
              <input
                id="email" name="email" type="email" autoComplete="email" required
                placeholder="you@company.com"
                value={form.email} onChange={handleChange}
                className="input-glow w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-white/20 outline-none transition-all duration-200"
              />
            </div>

            {/* Password */}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="password" className="text-xs font-semibold uppercase tracking-widest text-secondary">
                Password
              </label>
              <input
                id="password" name="password" type="password" autoComplete="current-password" required
                placeholder="Your password"
                value={form.password} onChange={handleChange}
                className="input-glow w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-white/20 outline-none transition-all duration-200"
              />
            </div>

            {/* Error */}
            {error && (
              <div role="alert" className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400 flex items-start gap-2">
                <span className="mt-0.5 shrink-0">⚠</span>
                <span>{error}</span>
              </div>
            )}

            {/* Submit */}
            <button
              type="submit" disabled={loading}
              className="btn-glow mt-1 flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3.5 text-sm font-bold text-black transition-all duration-300 hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? (
                <><svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" /></svg>Signing in…</>
              ) : "Sign In →"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
