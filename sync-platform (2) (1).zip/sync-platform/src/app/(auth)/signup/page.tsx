﻿"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { signUp } from "@/lib/auth";
import { getRoleHome } from "@/lib/rbac";
import { cn } from "@/lib/utils";

const ROLES = [
  {
    value: "user" as const,
    label: "Developer",
    description: "I build products and want to work on real challenges",
    icon: "⚡",
    gradient: "from-blue-500/10 to-cyan-500/5",
    border: "border-blue-500/40",
  },
  {
    value: "company" as const,
    label: "Company",
    description: "I have challenges that need exceptional developers",
    icon: "🏢",
    gradient: "from-primary/10 to-emerald-500/5",
    border: "border-primary/40",
  },
];

export default function SignupPage() {
  const router = useRouter();

  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [role, setRole] = useState<"user" | "company" | "">("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setError(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!role) { setError("Please select your account type."); return; }
    if (form.password.length < 6) { setError("Password must be at least 6 characters."); return; }

    setLoading(true);
    const { profile, error: signUpError } = await signUp({
      name: form.name, email: form.email, password: form.password, role,
    });
    setLoading(false);

    if (signUpError) { setError(signUpError); return; }
    if (profile) { router.push(getRoleHome(profile.role)); }
  }

  return (
    <div className="w-full max-w-md mx-auto">
      <div
        className="relative rounded-3xl p-px overflow-hidden"
        style={{ background: "linear-gradient(135deg, rgba(34,197,94,0.3), rgba(34,197,94,0.05), rgba(34,197,94,0.15))" }}
      >
        <div className="rounded-3xl bg-black/90 p-8 sm:p-10" style={{ backdropFilter: "blur(40px)" }}>
          <div className="mb-8">
            <h1 className="text-2xl font-extrabold text-white mb-1">Create your account</h1>
            <p className="text-sm text-secondary">
              Already have an account?{" "}
              <Link href="/login" className="font-semibold text-primary hover:opacity-80 transition-opacity">
                Sign in
              </Link>
            </p>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-5" noValidate>
            {/* Role selector */}
            <div className="flex flex-col gap-2">
              <span className="text-xs font-semibold uppercase tracking-widest text-secondary">
                I am joining as...
              </span>
              <div className="grid grid-cols-2 gap-3">
                {ROLES.map((r) => (
                  <button
                    key={r.value} type="button"
                    onClick={() => { setRole(r.value); setError(null); }}
                    className={cn(
                      "card-3d flex flex-col items-start rounded-2xl border p-5 text-left transition-all duration-200 focus:outline-none",
                      role === r.value
                        ? `${r.border} bg-gradient-to-br ${r.gradient} shadow-lg`
                        : "border-white/8 bg-white/3 hover:border-white/20"
                    )}
                    aria-pressed={role === r.value}
                  >
                    <span className="mb-2 text-2xl">{r.icon}</span>
                    <span className={cn("text-sm font-bold", role === r.value ? "text-white" : "text-secondary")}>{r.label}</span>
                    <span className="mt-1 text-xs leading-relaxed" style={{ color: role === r.value ? "rgba(255,255,255,0.6)" : "rgba(156,163,175,0.7)" }}>{r.description}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Name */}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="name" className="text-xs font-semibold uppercase tracking-widest text-secondary">Full Name</label>
              <input
                id="name" name="name" type="text" autoComplete="name" required
                placeholder="Your full name"
                value={form.name} onChange={handleChange}
                className="input-glow w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-white/20 outline-none transition-all duration-200"
              />
            </div>

            {/* Email */}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="email" className="text-xs font-semibold uppercase tracking-widest text-secondary">Email Address</label>
              <input
                id="email" name="email" type="email" autoComplete="email" required
                placeholder="you@example.com"
                value={form.email} onChange={handleChange}
                className="input-glow w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-white/20 outline-none transition-all duration-200"
              />
            </div>

            {/* Password */}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="password" className="text-xs font-semibold uppercase tracking-widest text-secondary">Password</label>
              <input
                id="password" name="password" type="password" autoComplete="new-password" required
                placeholder="Min. 6 characters"
                value={form.password} onChange={handleChange}
                className="input-glow w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-white/20 outline-none transition-all duration-200"
              />
            </div>

            {/* Error */}
            {error && (
              <div role="alert" className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400 flex items-start gap-2">
                <span className="mt-0.5 shrink-0">⚠</span>
                <span>{error}</span>
              </div>
            )}

            {/* Submit */}
            <button
              type="submit" disabled={loading}
              className="btn-glow mt-1 flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3.5 text-sm font-bold text-black transition-all duration-300 hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? (
                <><svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" /></svg>Creating account…</>
              ) : "Create Account →"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}