import Link from "next/link";
import { siteConfig } from "@/config/site";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-black px-4 py-16">
      {/* Background glows */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[600px] w-[600px] rounded-full"
          style={{ background: "radial-gradient(circle, rgba(34,197,94,0.08) 0%, transparent 70%)" }}
        />
        <div
          className="absolute top-0 right-0 h-96 w-96 rounded-full blur-[100px] opacity-20"
          style={{ background: "rgba(34,197,94,0.15)" }}
        />
        <div
          className="absolute bottom-0 left-0 h-64 w-64 rounded-full blur-[80px] opacity-15"
          style={{ background: "rgba(20,184,166,0.12)" }}
        />
      </div>

      {/* Grid overlay */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 grid-overlay opacity-40" />

      {/* Logo */}
      <Link
        href="/"
        className="relative mb-10 group flex items-center gap-3"
      >
        <span className="text-3xl font-black tracking-widest text-primary transition-all duration-300 group-hover:neon-text">
          {siteConfig.name}
        </span>
      </Link>

      {/* Content */}
      <div className="relative w-full">{children}</div>
    </div>
  );
}

