"use client";

import { useState, useRef, KeyboardEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import { postProblem } from "@/lib/problems";
import { cn } from "@/lib/utils";

const SUGGESTED_SKILLS = [
  "React", "Next.js", "TypeScript", "Node.js", "Python", "FastAPI",
  "PostgreSQL", "Supabase", "Docker", "AWS", "UI/UX", "Figma",
  "GraphQL", "REST API", "Machine Learning", "Web3", "Solidity",
];

export default function PostProblemPage() {
  const { profile, loading } = useAuth(["0", "company"]);
  const router = useRouter();

  const [form, setForm] = useState({
    title: "",
    description: "",
    budget: "",
    deadline: "",
  });
  const [skills, setSkills]       = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]         = useState<string | null>(null);
  const skillRef = useRef<HTMLInputElement>(null);

  function handleChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setError(null);
  }

  function addSkill(skill: string) {
    const trimmed = skill.trim();
    if (!trimmed || skills.includes(trimmed) || skills.length >= 10) return;
    setSkills((prev) => [...prev, trimmed]);
    setSkillInput("");
  }

  function removeSkill(skill: string) {
    setSkills((prev) => prev.filter((s) => s !== skill));
  }

  function handleSkillKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addSkill(skillInput);
    }
    if (e.key === "Backspace" && !skillInput && skills.length > 0) {
      setSkills((prev) => prev.slice(0, -1));
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!form.title.trim())       return setError("Title is required.");
    if (!form.description.trim()) return setError("Description is required.");
    if (!form.budget || isNaN(Number(form.budget)) || Number(form.budget) <= 0)
      return setError("Enter a valid budget greater than 0.");
    if (!form.deadline)           return setError("Deadline is required.");
    if (skills.length === 0)      return setError("Add at least one required skill.");

    setSubmitting(true);

    const { problem, error: postError } = await postProblem(profile!.id, {
      title: form.title.trim(),
      description: form.description.trim(),
      budget: Number(form.budget),
      deadline: form.deadline,
      skills,
    });

    setSubmitting(false);

    if (postError) {
      setError(postError);
      return;
    }

    if (problem) {
      router.push("/company-dashboard?posted=1");
    }
  }

  if (loading || !profile) return null;

  const today = new Date().toISOString().split("T")[0];

  return (
    <DashboardShell profile={profile}>
      {/* Breadcrumb */}
      <div className="mb-8 flex items-center gap-2 text-sm text-secondary">
        <Link href="/company-dashboard" className="hover:text-white transition-colors">
          Dashboard
        </Link>
        <span>/</span>
        <span className="text-white">Post a Problem</span>
      </div>

      <div className="max-w-2xl">
        <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-blue-400">New Listing</p>
        <h1 className="mb-2 text-3xl font-extrabold text-white">Post a Problem</h1>
        <p className="mb-10 text-secondary text-sm">
          Describe your challenge clearly to attract the best developers.
        </p>

        <form onSubmit={handleSubmit} className="flex flex-col gap-7" noValidate>

          {/* Title */}
          <Field label="Problem Title" hint="Be specific — e.g. 'Build a REST API for payments'">
            <input
              name="title"
              type="text"
              required
              maxLength={120}
              placeholder="e.g. Build a real-time chat feature"
              value={form.title}
              onChange={handleChange}
              className={inputCls}
            />
          </Field>

          {/* Description */}
          <Field label="Description" hint="Include context, expected outcome and any constraints">
            <textarea
              name="description"
              required
              rows={6}
              placeholder="Describe your problem in detail…"
              value={form.description}
              onChange={handleChange}
              className={cn(inputCls, "resize-none")}
            />
          </Field>

          {/* Budget + Deadline side by side */}
          <div className="grid gap-6 sm:grid-cols-2">
            <Field label="Budget (USD)" hint="Total budget for this project">
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-secondary text-sm">$</span>
                <input
                  name="budget"
                  type="number"
                  min="1"
                  step="1"
                  required
                  placeholder="5000"
                  value={form.budget}
                  onChange={handleChange}
                  className={cn(inputCls, "pl-8")}
                />
              </div>
            </Field>

            <Field label="Deadline" hint="When do you need this done?">
              <input
                name="deadline"
                type="date"
                required
                min={today}
                value={form.deadline}
                onChange={handleChange}
                className={inputCls}
              />
            </Field>
          </div>

          {/* Skills */}
          <Field label="Required Skills" hint="Press Enter or comma to add · max 10">
            <div
              className="flex flex-wrap gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-3 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary cursor-text"
              onClick={() => skillRef.current?.focus()}
            >
              {skills.map((sk) => (
                <span
                  key={sk}
                  className="flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-3 py-0.5 text-xs font-medium text-primary"
                >
                  {sk}
                  <button
                    type="button"
                    onClick={() => removeSkill(sk)}
                    className="hover:text-white transition-colors"
                    aria-label={`Remove ${sk}`}
                  >
                    ×
                  </button>
                </span>
              ))}
              <input
                ref={skillRef}
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyDown={handleSkillKeyDown}
                placeholder={skills.length === 0 ? "Type a skill and press Enter…" : ""}
                className="flex-1 min-w-[120px] bg-transparent text-sm text-white placeholder-white/20 outline-none"
              />
            </div>

            {/* Suggested skills */}
            <div className="mt-3 flex flex-wrap gap-2">
              {SUGGESTED_SKILLS.filter((s) => !skills.includes(s)).slice(0, 10).map((sk) => (
                <button
                  key={sk}
                  type="button"
                  onClick={() => addSkill(sk)}
                  className="rounded-full border border-white/10 bg-white/5 px-3 py-0.5 text-xs text-secondary transition hover:border-white/30 hover:text-white"
                >
                  + {sk}
                </button>
              ))}
            </div>
          </Field>

          {/* Error */}
          {error && (
            <div role="alert" className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">
              {error}
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center gap-4 pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-sm font-bold text-black transition-opacity hover:opacity-80 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {submitting ? <><Spinner /> Posting…</> : "Post Problem →"}
            </button>
            <Link
              href="/company-dashboard"
              className="text-sm text-secondary hover:text-white transition-colors"
            >
              Cancel
            </Link>
          </div>

        </form>
      </div>
    </DashboardShell>
  );
}

// ─── Sub-components ────────────────────────────────────────────────────────────

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-semibold uppercase tracking-wider text-secondary">
        {label}
      </label>
      {children}
      {hint && <p className="text-xs text-white/30">{hint}</p>}
    </div>
  );
}

const inputCls =
  "w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-white/20 outline-none transition focus:border-primary focus:ring-1 focus:ring-primary";

function Spinner() {
  return (
    <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
    </svg>
  );
}
