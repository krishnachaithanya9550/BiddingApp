"use client";

import { useEffect, useState, useCallback } from "react";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import { cn } from "@/lib/utils";

// ---- Types -----------------------------------------------------------------

interface MyListing {
  id: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  price: number;
  demo_url: string;
  repo_url: string;
  status: "active" | "draft" | "paused";
  purchase_count: number;
  created_at: string;
}

interface Purchase {
  id: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  price_paid: number;
  demo_url: string;
  repo_url: string;
  seller_name: string;
  purchased_at: string;
}

// ---- Constants -------------------------------------------------------------

const CATEGORIES = [
  { value: "automation", label: "Automation",      icon: "🤖" },
  { value: "agent",      label: "AI Agent",        icon: "🧠" },
  { value: "tool",       label: "Dev Tool",        icon: "🛠️" },
  { value: "template",   label: "Template",        icon: "📋" },
  { value: "script",     label: "Script",          icon: "📜" },
  { value: "api",        label: "API / Wrapper",   icon: "🔌" },
  { value: "other",      label: "Other",           icon: "📦" },
];

const STATUS_STYLES = {
  active: "border-primary/30 bg-primary/10 text-primary",
  draft:  "border-yellow-500/30 bg-yellow-500/10 text-yellow-400",
  paused: "border-white/15 bg-white/5 text-secondary",
};

// ---- CreateEditModal -------------------------------------------------------

interface FormValues {
  title: string;
  description: string;
  category: string;
  tags: string;
  price: string;
  demo_url: string;
  repo_url: string;
  status: string;
}

const EMPTY_FORM: FormValues = {
  title: "",
  description: "",
  category: "automation",
  tags: "",
  price: "0",
  demo_url: "",
  repo_url: "",
  status: "active",
};

function CreateEditModal({
  initial,
  onClose,
  onSaved,
}: {
  initial?: MyListing | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<FormValues>(
    initial
      ? {
          title:       initial.title,
          description: initial.description,
          category:    initial.category,
          tags:        initial.tags.join(", "),
          price:       String(initial.price),
          demo_url:    initial.demo_url || "",
          repo_url:    initial.repo_url || "",
          status:      initial.status,
        }
      : EMPTY_FORM
  );
  const [saving,  setSaving]  = useState(false);
  const [error,   setError]   = useState("");

  function set(k: keyof FormValues, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const price = parseFloat(form.price);
    if (isNaN(price) || price < 0) { setError("Price must be a non-negative number."); return; }
    setSaving(true);
    const payload = {
      title:       form.title.trim(),
      description: form.description.trim(),
      category:    form.category,
      tags:        form.tags.split(",").map((t) => t.trim()).filter(Boolean),
      price,
      demo_url:    form.demo_url.trim(),
      repo_url:    form.repo_url.trim(),
      status:      form.status,
    };
    const res = initial
      ? await fetch(`/api/marketplace/${initial.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) })
      : await fetch("/api/marketplace", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const d = await res.json();
    if (!res.ok) { setError(d.error ?? "Something went wrong."); setSaving(false); return; }
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/75 backdrop-blur-sm" />
      <form
        className="relative w-full max-w-xl rounded-3xl border border-white/10 bg-black/95 shadow-2xl overflow-y-auto max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
        onSubmit={submit}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/8 bg-black/95 px-7 py-5" style={{ backdropFilter: "blur(20px)" }}>
          <h2 className="text-lg font-extrabold text-white">{initial ? "Edit Listing" : "Create Listing"}</h2>
          <button type="button" onClick={onClose} className="rounded-full p-1.5 text-secondary hover:text-white transition-colors">
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="p-7 space-y-5">
          {error && (
            <div className="rounded-2xl border border-red-500/20 bg-red-500/8 p-3 text-sm text-red-400">{error}</div>
          )}

          {/* Title */}
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-secondary">Title *</label>
            <input
              required
              value={form.title}
              onChange={(e) => set("title", e.target.value)}
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/40 outline-none focus:border-purple-500/40 transition-colors"
              placeholder="e.g. LinkedIn Outreach Automation"
            />
          </div>

          {/* Description */}
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-secondary">Description *</label>
            <textarea
              required
              rows={4}
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/40 outline-none focus:border-purple-500/40 transition-colors resize-y"
              placeholder="What does your product do? What problems does it solve?"
            />
          </div>

          {/* Category + Status */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-secondary">Category *</label>
              <select
                value={form.category}
                onChange={(e) => set("category", e.target.value)}
                className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-purple-500/40 transition-colors"
              >
                {CATEGORIES.map((c) => (
                  <option key={c.value} value={c.value} className="bg-zinc-900">{c.icon} {c.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-secondary">Status</label>
              <select
                value={form.status}
                onChange={(e) => set("status", e.target.value)}
                className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white outline-none focus:border-purple-500/40 transition-colors"
              >
                <option value="active"  className="bg-zinc-900">Active (public)</option>
                <option value="draft"   className="bg-zinc-900">Draft (hidden)</option>
                <option value="paused"  className="bg-zinc-900">Paused</option>
              </select>
            </div>
          </div>

          {/* Price */}
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-secondary">Price (USD — set 0 for Free)</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-secondary text-sm">$</span>
              <input
                type="number"
                min="0"
                step="0.01"
                value={form.price}
                onChange={(e) => set("price", e.target.value)}
                className="w-full rounded-2xl border border-white/10 bg-white/5 pl-8 pr-4 py-2.5 text-sm text-white outline-none focus:border-purple-500/40 transition-colors"
              />
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-secondary">Tags (comma-separated)</label>
            <input
              value={form.tags}
              onChange={(e) => set("tags", e.target.value)}
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/40 outline-none focus:border-purple-500/40 transition-colors"
              placeholder="e.g. gpt-4, n8n, twitter, headless"
            />
          </div>

          {/* Demo URL */}
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-secondary">Demo URL</label>
            <input
              type="url"
              value={form.demo_url}
              onChange={(e) => set("demo_url", e.target.value)}
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/40 outline-none focus:border-purple-500/40 transition-colors"
              placeholder="https://youtube.com/watch?v=… or https://demo.example.com"
            />
            <p className="mt-1 text-[10px] text-secondary">YouTube links will be embedded automatically.</p>
          </div>

          {/* Repo / Download URL */}
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-secondary">Repo / Download URL</label>
            <input
              type="url"
              value={form.repo_url}
              onChange={(e) => set("repo_url", e.target.value)}
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/40 outline-none focus:border-purple-500/40 transition-colors"
              placeholder="https://github.com/…"
            />
            <p className="mt-1 text-[10px] text-secondary">Shared only with buyers after purchase.</p>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full rounded-2xl bg-primary py-3 text-sm font-bold text-black hover:opacity-90 transition-opacity disabled:opacity-40"
          >
            {saving ? "Saving…" : initial ? "Save Changes" : "Create Listing"}
          </button>
        </div>
      </form>
    </div>
  );
}

// ---- DeleteConfirmModal ----------------------------------------------------

function DeleteConfirmModal({
  title,
  onClose,
  onConfirm,
}: {
  title: string;
  onClose: () => void;
  onConfirm: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/75 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-sm rounded-3xl border border-red-500/20 bg-black/95 p-7 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl border border-red-500/20 bg-red-500/10 text-3xl">
          🗑️
        </div>
        <h3 className="mb-2 font-extrabold text-white">Delete listing?</h3>
        <p className="mb-6 text-sm text-secondary">
          &ldquo;{title}&rdquo; will be permanently removed. This cannot be undone.
        </p>
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 rounded-2xl border border-white/10 py-2.5 text-sm font-semibold text-secondary hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 rounded-2xl border border-red-500/30 bg-red-500/15 py-2.5 text-sm font-bold text-red-400 hover:bg-red-500/25 transition-colors"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

// ---- Main page -------------------------------------------------------------

export default function DevMarketplacePage() {
  const { profile, loading } = useAuth();

  const [tab, setTab]                   = useState<"listings" | "purchases">("listings");
  const [listings, setListings]         = useState<MyListing[]>([]);
  const [purchases, setPurchases]       = useState<Purchase[]>([]);
  const [dataLoading, setDataLoading]   = useState(true);
  const [modalOpen, setModalOpen]       = useState(false);
  const [editListing, setEditListing]   = useState<MyListing | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<MyListing | null>(null);
  const [deleting, setDeleting]         = useState(false);
  const [actionMsg, setActionMsg]       = useState("");

  const loadData = useCallback(async () => {
    setDataLoading(true);
    try {
      const [mRes, pRes] = await Promise.all([
        fetch("/api/marketplace/mine"),
        fetch("/api/marketplace/purchased"),
      ]);
      if (mRes.ok)  { const d = await mRes.json(); setListings(d.listings ?? []); }
      if (pRes.ok)  { const d = await pRes.json(); setPurchases(d.purchases ?? []); }
    } finally {
      setDataLoading(false);
    }
  }, []);

  useEffect(() => { if (profile) loadData(); }, [profile, loadData]);

  async function deleteListing() {
    if (!deleteTarget) return;
    setDeleting(true);
    const res = await fetch(`/api/marketplace/${deleteTarget.id}`, { method: "DELETE" });
    const d   = await res.json();
    if (res.ok) {
      setListings((prev) => prev.filter((l) => l.id !== deleteTarget.id));
      setDeleteTarget(null);
      setActionMsg("Listing deleted.");
      setTimeout(() => setActionMsg(""), 3000);
    } else {
      setActionMsg(d.error ?? "Delete failed.");
    }
    setDeleting(false);
  }

  if (loading || !profile) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-purple-400 border-t-transparent" />
      </div>
    );
  }

  if (profile.role !== "user") {
    return (
      <DashboardShell profile={profile}>
        <div className="rounded-2xl border border-white/8 bg-white/3 p-16 text-center">
          <p className="text-xl font-bold text-white">Developers only</p>
          <p className="text-sm text-secondary mt-2">Only developer accounts can manage marketplace listings.</p>
        </div>
      </DashboardShell>
    );
  }

  const totalRevenue = listings.reduce((acc, l) => acc + l.purchase_count * l.price, 0);

  return (
    <DashboardShell profile={profile}>

      {/* Header */}
      <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="mb-1 text-[10px] font-semibold uppercase tracking-widest text-purple-400">Marketplace</p>
          <h1 className="text-3xl font-extrabold text-white">My Products</h1>
          <p className="mt-1 text-secondary text-sm">Manage your listings and view your purchases.</p>
        </div>
        <div className="flex items-center gap-3">
          {actionMsg && <span className="text-xs font-semibold text-primary">{actionMsg}</span>}
          <button
            onClick={() => { setEditListing(null); setModalOpen(true); }}
            className="rounded-2xl bg-primary px-4 py-2 text-sm font-bold text-black hover:opacity-90 transition-opacity"
          >
            + New Listing
          </button>
        </div>
      </div>

      {/* Stats row */}
      <div className="mb-7 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          { label: "Listings",           value: listings.length },
          { label: "Active",             value: listings.filter((l) => l.status === "active").length },
          { label: "Total Sales",        value: listings.reduce((a, l) => a + l.purchase_count, 0) },
          { label: "Est. Revenue",       value: `$${totalRevenue.toFixed(2)}` },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-white/8 bg-white/3 p-4">
            <p className="text-2xl font-extrabold text-white">{s.value}</p>
            <p className="text-xs text-secondary mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="mb-6 flex gap-1 rounded-2xl border border-white/8 bg-white/3 p-1 w-fit">
        {(["listings", "purchases"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "rounded-xl px-5 py-2 text-sm font-semibold capitalize transition-all",
              tab === t ? "bg-purple-500/20 text-purple-300" : "text-secondary hover:text-white"
            )}
          >
            {t === "listings" ? "My Listings" : "My Purchases"}
            <span className="ml-2 rounded-full bg-white/5 px-1.5 py-0.5 text-[10px]">
              {t === "listings" ? listings.length : purchases.length}
            </span>
          </button>
        ))}
      </div>

      {/* ---------- MY LISTINGS TAB ---------- */}
      {tab === "listings" && (
        dataLoading ? (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => <div key={i} className="h-24 animate-pulse rounded-2xl border border-white/5 bg-white/3" />)}
          </div>
        ) : listings.length === 0 ? (
          <div className="rounded-2xl border border-white/8 bg-white/3 p-16 text-center">
            <p className="text-5xl mb-4">📦</p>
            <p className="text-lg font-bold text-white mb-1">No listings yet</p>
            <p className="text-sm text-secondary mb-6">Create your first listing to start selling on the marketplace.</p>
            <button
              onClick={() => { setEditListing(null); setModalOpen(true); }}
              className="rounded-2xl bg-primary px-6 py-2.5 text-sm font-bold text-black hover:opacity-90 transition-opacity"
            >
              Create Listing
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {listings.map((listing) => (
              <div key={listing.id} className="flex flex-col gap-3 rounded-2xl border border-white/8 bg-white/3 p-5 sm:flex-row sm:items-center">
                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="font-extrabold text-white">{listing.title}</h3>
                    <span className={cn("rounded-full border px-2 py-0.5 text-[10px] font-bold capitalize", STATUS_STYLES[listing.status])}>
                      {listing.status}
                    </span>
                    <span className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] text-secondary">
                      {CATEGORIES.find((c) => c.value === listing.category)?.icon} {listing.category}
                    </span>
                  </div>
                  <p className="text-xs text-secondary line-clamp-2">{listing.description}</p>
                  {listing.tags.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {listing.tags.slice(0, 4).map((t) => (
                        <span key={t} className="rounded-full border border-primary/20 bg-primary/5 px-2 py-0.5 text-[10px] text-primary">{t}</span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Stats */}
                <div className="flex shrink-0 items-center gap-6">
                  <div className="text-center">
                    <p className="text-lg font-extrabold text-primary">{listing.price === 0 ? "Free" : `$${listing.price.toFixed(2)}`}</p>
                    <p className="text-[10px] text-secondary">price</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-extrabold text-white">{listing.purchase_count}</p>
                    <p className="text-[10px] text-secondary">sales</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-extrabold text-purple-400">${(listing.purchase_count * listing.price).toFixed(2)}</p>
                    <p className="text-[10px] text-secondary">revenue</p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex shrink-0 items-center gap-2">
                  {listing.demo_url && (
                    <a
                      href={listing.demo_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-xl border border-white/10 px-3 py-1.5 text-xs font-semibold text-secondary hover:text-white transition-colors"
                    >
                      Demo ↗
                    </a>
                  )}
                  <button
                    onClick={() => { setEditListing(listing); setModalOpen(true); }}
                    className="rounded-xl border border-white/10 px-3 py-1.5 text-xs font-semibold text-secondary hover:text-white transition-colors"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => setDeleteTarget(listing)}
                    className="rounded-xl border border-red-500/20 bg-red-500/5 px-3 py-1.5 text-xs font-semibold text-red-400 hover:bg-red-500/15 transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      {/* ---------- MY PURCHASES TAB ---------- */}
      {tab === "purchases" && (
        dataLoading ? (
          <div className="grid gap-4 sm:grid-cols-2">
            {[...Array(4)].map((_, i) => <div key={i} className="h-48 animate-pulse rounded-2xl border border-white/5 bg-white/3" />)}
          </div>
        ) : purchases.length === 0 ? (
          <div className="rounded-2xl border border-white/8 bg-white/3 p-16 text-center">
            <p className="text-5xl mb-4">🛍️</p>
            <p className="text-lg font-bold text-white mb-1">No purchases yet</p>
            <p className="text-sm text-secondary mb-6">Browse the marketplace to discover great tools.</p>
            <a
              href="/marketplace"
              className="inline-block rounded-2xl bg-primary px-6 py-2.5 text-sm font-bold text-black hover:opacity-90 transition-opacity"
            >
              Browse Marketplace
            </a>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {purchases.map((p) => (
              <div key={p.id} className="flex flex-col rounded-2xl border border-white/8 bg-white/3 p-5">
                <div className="mb-3 flex items-center justify-between gap-2">
                  <span className="text-xs text-secondary">by {p.seller_name}</span>
                  <span className="text-[10px] text-secondary">{new Date(p.purchased_at).toLocaleDateString()}</span>
                </div>
                <h3 className="mb-1.5 font-extrabold text-white">{p.title}</h3>
                <p className="flex-1 text-xs text-secondary line-clamp-3 leading-relaxed">{p.description}</p>
                {p.tags.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1">
                    {p.tags.slice(0, 3).map((t) => (
                      <span key={t} className="rounded-full border border-primary/20 bg-primary/5 px-2 py-0.5 text-[10px] text-primary">{t}</span>
                    ))}
                  </div>
                )}
                <div className="mt-4 flex items-center justify-between border-t border-white/5 pt-3">
                  <span className="font-black text-primary">
                    {p.price_paid === 0 ? "Free" : `$${p.price_paid.toFixed(2)} paid`}
                  </span>
                  <div className="flex gap-2">
                    {p.demo_url && (
                      <a href={p.demo_url} target="_blank" rel="noopener noreferrer"
                        className="rounded-xl border border-white/10 px-3 py-1.5 text-xs font-semibold text-secondary hover:text-white transition-colors">
                        Demo ↗
                      </a>
                    )}
                    {p.repo_url && (
                      <a href={p.repo_url} target="_blank" rel="noopener noreferrer"
                        className="rounded-xl border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs font-bold text-primary hover:bg-primary/10 transition-colors">
                        Repo / Download ↗
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      {/* Modals */}
      {modalOpen && (
        <CreateEditModal
          initial={editListing}
          onClose={() => setModalOpen(false)}
          onSaved={() => {
            const isNew = editListing === null;
            setModalOpen(false);
            loadData();
            setActionMsg(isNew ? "Listing created!" : "Listing updated!");
            setTimeout(() => setActionMsg(""), 3000);
          }}
        />
      )}
      {deleteTarget && (
        <DeleteConfirmModal
          title={deleteTarget.title}
          onClose={() => setDeleteTarget(null)}
          onConfirm={deleteListing}
        />
      )}
      {deleting && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        </div>
      )}

    </DashboardShell>
  );
}
