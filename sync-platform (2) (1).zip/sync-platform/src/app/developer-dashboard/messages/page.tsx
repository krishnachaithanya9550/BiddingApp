"use client";

import { useEffect, useState, useRef } from "react";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import { cn } from "@/lib/utils";
import { useSearchParams } from "next/navigation";
import type { Message, GroupChat } from "@/types";

interface Friend {
  id: string;
  other_id: string;
  other_name: string;
  other_email: string;
  other_avatar_color: string;
  status: string;
}

interface DMMessage extends Message {
  sender_name: string;
  sender_avatar_color: string;
}

export default function MessagesPage() {
  const { profile, loading } = useAuth(["0", "user"]);
  const searchParams = useSearchParams();

  const [friends, setFriends]         = useState<Friend[]>([]);
  const [groups, setGroups]           = useState<GroupChat[]>([]);
  const [activeChat, setActiveChat]   = useState<{ type: "dm" | "group"; id: string; name: string; avatarColor?: string } | null>(null);
  const [messages, setMessages]       = useState<DMMessage[]>([]);
  const [msgInput, setMsgInput]       = useState("");
  const [sending, setSending]         = useState(false);
  const [sendError, setSendError]     = useState("");
  const [showNewGroup, setShowNewGroup] = useState(false);
  const [groupName, setGroupName]     = useState("");
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [unreadIds, setUnreadIds]     = useState<Set<string>>(new Set());
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const autoOpenedRef  = useRef(false);

  useEffect(() => {
    if (!profile) return;
    loadFriendsAndGroups();
    fetchUnread();
  }, [profile]);

  // After friends load, auto-open the ?with= chat (only once)
  useEffect(() => {
    if (autoOpenedRef.current || friends.length === 0) return;
    const withId = searchParams.get("with");
    if (!withId) return;
    const friend = friends.find((f) => f.other_id === withId);
    if (friend) {
      autoOpenedRef.current = true;
      openChat("dm", friend.other_id, friend.other_name, friend.other_avatar_color);
    }
  }, [friends, searchParams]);

  // Poll for new messages every 3 seconds
  useEffect(() => {
    if (!activeChat) return;
    const interval = setInterval(loadMessages, 3000);
    return () => clearInterval(interval);
  }, [activeChat]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function fetchUnread() {
    try {
      const res = await fetch("/api/notifications?since=1970-01-01T00:00:00.000Z");
      if (!res.ok) return;
      const data = await res.json();
      const ids = new Set<string>((data.unread_senders ?? []).map((s: { id: string }) => s.id));
      setUnreadIds(ids);
    } catch { /* ignore */ }
  }

  async function loadFriendsAndGroups() {
    const [fRes, gRes] = await Promise.all([
      fetch("/api/friendships"),
      fetch("/api/groups"),
    ]);
    const fData = fRes.ok ? await fRes.json() : {};
    const gData = gRes.ok ? await gRes.json() : {};
    setFriends((fData.friendships ?? []).filter((f: Friend) => f.status === "accepted"));
    setGroups(gData.groups ?? []);
  }

  async function loadMessages() {
    if (!activeChat) return;
    const url = activeChat.type === "dm"
      ? `/api/messages?with=${activeChat.id}`
      : `/api/groups/${activeChat.id}/messages`;
    try {
      const res = await fetch(url);
      if (!res.ok) return;
      const data = await res.json();
      setMessages(data.messages ?? []);
    } catch { /* ignore transient errors */ }
  }

  async function openChat(type: "dm" | "group", id: string, name: string, avatarColor?: string) {
    setActiveChat({ type, id, name, avatarColor });
    setMessages([]);
    const url = type === "dm" ? `/api/messages?with=${id}` : `/api/groups/${id}/messages`;
    try {
      const res = await fetch(url);
      if (!res.ok) return;
      const data = await res.json();
      setMessages(data.messages ?? []);
      // Remove this sender from unread set (messages GET marks them as read server-side)
      if (type === "dm") {
        setUnreadIds((prev) => { const next = new Set(prev); next.delete(id); return next; });
      }
    } catch { /* ignore */ }
  }

  async function sendMessage() {
    if (!msgInput.trim() || !activeChat || sending) return;
    setSending(true);
    setSendError("");
    const content = msgInput.trim();
    const url = activeChat.type === "dm" ? "/api/messages" : `/api/groups/${activeChat.id}/messages`;
    const body = activeChat.type === "dm"
      ? { recipient_id: activeChat.id, content }
      : { content };

    // Optimistic update — show the message immediately
    const optimisticMsg: DMMessage = {
      id: `optimistic-${Date.now()}`,
      sender_id: profile!.id,
      recipient_id: activeChat.type === "dm" ? activeChat.id : undefined,
      group_id: activeChat.type === "group" ? activeChat.id : undefined,
      content,
      created_at: new Date().toISOString(),
      sender_name: profile!.name,
      sender_avatar_color: (profile as any).avatar_color || "#22c55e",
    } as unknown as DMMessage;
    setMessages((prev) => [...prev, optimisticMsg]);
    setMsgInput("");

    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        // Replace optimistic message with real one from server
        await loadMessages();
      } else {
        const err = await res.json().catch(() => ({}));
        setSendError(err.error ?? "Failed to send message.");
        // Remove the optimistic message
        setMessages((prev) => prev.filter((m) => m.id !== optimisticMsg.id));
        setMsgInput(content); // restore input
      }
    } catch {
      setSendError("Network error. Please try again.");
      setMessages((prev) => prev.filter((m) => m.id !== optimisticMsg.id));
      setMsgInput(content);
    } finally {
      setSending(false);
    }
  }

  async function createGroup() {
    if (!groupName.trim() || selectedMembers.length === 0) return;
    const res = await fetch("/api/groups", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: groupName.trim(), member_ids: selectedMembers }),
    });
    if (res.ok) {
      const data = await res.json();
      setShowNewGroup(false);
      setGroupName("");
      setSelectedMembers([]);
      await loadFriendsAndGroups();
      openChat("group", data.id, data.name);
    }
  }

  if (loading || !profile) return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
    </div>
  );

  return (
    <DashboardShell profile={profile}>
      <div className="mb-6">
        <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-primary">Messaging</p>
        <h1 className="text-2xl font-extrabold text-white">Messages</h1>
      </div>

      <div className="flex gap-4 h-[70vh]">

        {/* Sidebar */}
        <div className="w-72 shrink-0 flex flex-col rounded-2xl border border-white/8 bg-white/3 overflow-hidden">
          {/* DMs */}
          <div className="border-b border-white/5 p-3">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-secondary/50">Direct Messages</p>
            {friends.length === 0 ? (
              <p className="text-xs text-secondary px-1">No friends yet. Visit Community to connect!</p>
            ) : (
              friends.map((f) => {
                const hasUnread = unreadIds.has(f.other_id);
                return (
                  <button
                    key={f.other_id}
                    onClick={() => openChat("dm", f.other_id, f.other_name, f.other_avatar_color)}
                    className={cn(
                      "w-full flex items-center gap-2 rounded-xl px-3 py-2 text-left transition-all",
                      activeChat?.id === f.other_id && activeChat.type === "dm"
                        ? "bg-primary/10 border border-primary/20"
                        : hasUnread
                          ? "bg-red-500/8 border border-red-500/20 hover:bg-red-500/12"
                          : "hover:bg-white/5"
                    )}
                  >
                    <div className="relative h-8 w-8 shrink-0">
                      <div className="h-8 w-8 rounded-full flex items-center justify-center text-sm font-black text-black"
                        style={{ background: f.other_avatar_color || "#22c55e" }}>
                        {f.other_name.charAt(0).toUpperCase()}
                      </div>
                      {hasUnread && (
                        <span className="absolute -top-0.5 -right-0.5 h-3 w-3 rounded-full bg-red-500 border-2 border-black" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className={cn("text-sm truncate", hasUnread ? "font-extrabold text-white" : "font-semibold text-white")}>
                        {f.other_name}
                      </p>
                      {hasUnread && (
                        <p className="text-[10px] text-red-400 font-semibold">New messages</p>
                      )}
                    </div>
                    {hasUnread && (
                      <span className="shrink-0 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-black text-white">
                        !
                      </span>
                    )}
                  </button>
                );
              })
            )}
          </div>

          {/* Groups */}
          <div className="flex-1 overflow-y-auto p-3">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[10px] font-bold uppercase tracking-widest text-secondary/50">Group Chats</p>
              <button onClick={() => setShowNewGroup(true)}
                className="text-[10px] text-primary hover:text-primary/80 font-bold border border-primary/20 rounded-lg px-2 py-0.5">
                + New
              </button>
            </div>
            {groups.length === 0 ? (
              <p className="text-xs text-secondary px-1">No groups yet.</p>
            ) : (
              groups.map((g) => (
                <button
                  key={g.id}
                  onClick={() => openChat("group", g.id, g.name)}
                  className={cn(
                    "w-full flex items-center gap-2 rounded-xl px-3 py-2 text-left transition-all mb-1",
                    activeChat?.id === g.id && activeChat.type === "group"
                      ? "bg-primary/10 border border-primary/20"
                      : "hover:bg-white/5"
                  )}
                >
                  <div className="h-8 w-8 shrink-0 rounded-full bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-base">
                    👥
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{g.name}</p>
                    <p className="text-xs text-secondary">{g.member_count ?? 0} members</p>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Chat area */}
        <div className="flex-1 flex flex-col rounded-2xl border border-white/8 bg-black/60 overflow-hidden">
          {!activeChat ? (
            <div className="flex-1 flex items-center justify-center text-center p-8">
              <div>
                <p className="text-4xl mb-3">💬</p>
                <p className="font-semibold text-white">Select a conversation</p>
                <p className="text-sm text-secondary mt-1">Choose a friend or group chat from the sidebar.</p>
              </div>
            </div>
          ) : (
            <>
              {/* Chat header */}
              <div className="border-b border-white/5 px-5 py-4 flex items-center gap-3">
                <div
                  className="h-9 w-9 rounded-full flex items-center justify-center text-sm font-black"
                  style={activeChat.type === "dm"
                    ? { background: activeChat.avatarColor || "#22c55e", color: "black" }
                    : { background: "rgba(168,85,247,0.2)", border: "1px solid rgba(168,85,247,0.3)", fontSize: 16 }}
                >
                  {activeChat.type === "dm" ? activeChat.name.charAt(0).toUpperCase() : "👥"}
                </div>
                <div>
                  <p className="font-bold text-white">{activeChat.name}</p>
                  <p className="text-xs text-secondary">{activeChat.type === "dm" ? "Direct Message" : "Group Chat"}</p>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
                {messages.length === 0 && (
                  <div className="text-center text-xs text-secondary py-8">No messages yet. Say hello! 👋</div>
                )}
                {messages.map((msg) => {
                  const isMe = msg.sender_id === profile.id;
                  return (
                    <div key={msg.id} className={cn("flex gap-2 max-w-[75%]", isMe ? "self-end flex-row-reverse" : "self-start")}>
                      <div
                        className="h-7 w-7 shrink-0 rounded-full flex items-center justify-center text-xs font-black text-black"
                        style={{ background: (msg as DMMessage).sender_avatar_color || "#22c55e" }}
                      >
                        {msg.sender_name?.charAt(0).toUpperCase() ?? "?"}
                      </div>
                      <div>
                        {!isMe && <p className="text-[10px] text-secondary mb-0.5">{msg.sender_name}</p>}
                        <div className={cn(
                          "rounded-2xl px-3 py-2 text-sm",
                          isMe ? "bg-primary text-black rounded-tr-sm" : "bg-white/8 text-white rounded-tl-sm"
                        )}>
                          {msg.content}
                        </div>
                        <p className="text-[9px] text-secondary/40 mt-0.5 px-1">
                          {new Date(msg.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="border-t border-white/5 p-3 flex flex-col gap-2">
                {sendError && (
                  <p className="text-xs text-red-400 px-1">{sendError}</p>
                )}
                <div className="flex gap-2">
                  <input
                    className="flex-1 rounded-2xl border border-white/8 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-secondary/50 focus:outline-none focus:border-primary/30 transition-colors"
                    value={msgInput}
                    onChange={(e) => setMsgInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                    placeholder="Type a message…"
                  />
                  <button onClick={sendMessage} disabled={sending || !msgInput.trim()}
                    className="rounded-2xl bg-primary px-4 font-bold text-black disabled:opacity-40 transition-all hover:-translate-y-0.5">
                    →
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* New group modal */}
      {showNewGroup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={() => setShowNewGroup(false)}>
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
          <div className="relative w-full max-w-md rounded-3xl border border-white/10 bg-black/90 p-6" onClick={(e) => e.stopPropagation()}>
            <h3 className="mb-4 text-lg font-extrabold text-white">Create Group Chat</h3>
            <div className="mb-4">
              <label className="mb-1 block text-xs font-semibold text-secondary">Group Name</label>
              <input className="input-glow w-full" value={groupName} onChange={(e) => setGroupName(e.target.value)} placeholder="Team Alpha" />
            </div>
            <div className="mb-6">
              <label className="mb-2 block text-xs font-semibold text-secondary">Add Friends</label>
              {friends.length === 0 ? (
                <p className="text-xs text-secondary">You need to connect with developers first.</p>
              ) : (
                <div className="flex flex-col gap-2">
                  {friends.map((f) => (
                    <label key={f.other_id} className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedMembers.includes(f.other_id)}
                        onChange={(e) => setSelectedMembers((p) =>
                          e.target.checked ? [...p, f.other_id] : p.filter((x) => x !== f.other_id)
                        )}
                        className="accent-primary"
                      />
                      <div className="h-7 w-7 rounded-full flex items-center justify-center text-xs font-black text-black"
                        style={{ background: f.other_avatar_color }}>
                        {f.other_name.charAt(0).toUpperCase()}
                      </div>
                      <span className="text-sm text-white">{f.other_name}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowNewGroup(false)}
                className="flex-1 rounded-xl border border-white/10 py-2.5 text-sm font-semibold text-secondary hover:text-white transition-colors">
                Cancel
              </button>
              <button onClick={createGroup} disabled={!groupName.trim() || selectedMembers.length === 0}
                className="flex-1 rounded-xl bg-primary py-2.5 text-sm font-bold text-black disabled:opacity-40">
                Create Group
              </button>
            </div>
          </div>
        </div>
      )}
    </DashboardShell>
  );
}
