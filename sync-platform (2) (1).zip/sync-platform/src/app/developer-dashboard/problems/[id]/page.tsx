"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import { cn } from "@/lib/utils";
import type { Problem } from "@/types";

// ── Dummy AI Agent suggestions ────────────────────────────────────────────────
const AI_AGENTS = [
  {
    id: "sync-ai",
    name: "SYNC AI",
    avatar: "🤖",
    color: "#22c55e",
    suggestions: [
      "Consider using a microservices architecture for scalability.",
      "A React frontend with a REST API backend would work well here.",
      "Think about caching strategies to reduce database load.",
      "Use JWT for stateless authentication between services.",
      "Docker Compose could simplify your local dev setup.",
    ],
  },
  {
    id: "arch-bot",
    name: "Arch Bot",
    avatar: "🏗️",
    color: "#3b82f6",
    suggestions: [
      "Start with a monolith, split to microservices when needed.",
      "Event-driven architecture fits this use-case well.",
      "A message queue (e.g. BullMQ / Redis) would handle async tasks.",
      "Consider a CQRS pattern for read-heavy workloads.",
      "GraphQL subscriptions can power real-time updates.",
    ],
  },
  {
    id: "code-buddy",
    name: "Code Buddy",
    avatar: "🧑‍💻",
    color: "#a855f7",
    suggestions: [
      "Write unit tests first — it clarifies the requirements.",
      "Use zod for schema validation at your API boundary.",
      "Optimistic UI updates will make the UX feel snappier.",
      "Abstract DB queries into a repository layer for testability.",
      "E2E tests with Playwright will catch regressions fast.",
    ],
  },
];

// ── Dummy file tree ────────────────────────────────────────────────────────────
const DUMMY_FILES = [
  { name: "src/", type: "folder", depth: 0 },
  { name: "  index.ts", type: "file", depth: 1 },
  { name: "  api/", type: "folder", depth: 1 },
  { name: "    routes.ts", type: "file", depth: 2 },
  { name: "    middleware.ts", type: "file", depth: 2 },
  { name: "  models/", type: "folder", depth: 1 },
  { name: "    User.ts", type: "file", depth: 2 },
  { name: "  utils/", type: "folder", depth: 1 },
  { name: "    helpers.ts", type: "file", depth: 2 },
  { name: "package.json", type: "file", depth: 0 },
  { name: "tsconfig.json", type: "file", depth: 0 },
  { name: "Dockerfile", type: "file", depth: 0 },
];

// ── Dummy starter code ─────────────────────────────────────────────────────────
const STARTER_CODE = `// SYNC — Solution Workspace
// Write your solution approach below

import express from 'express';
import { db } from './models/db';

const app = express();
app.use(express.json());

// TODO: Implement your solution here
app.get('/api/solution', async (req, res) => {
  try {
    // Your implementation
    const result = await db.query('SELECT * FROM data');
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default app;
`;

const TECH_STACK_OPTIONS = ["React", "Next.js", "Node.js", "Python", "FastAPI", "Express",
  "PostgreSQL", "MongoDB", "Redis", "Docker", "AWS", "TypeScript", "GraphQL", "WebSockets"];

export default function ProblemWorkspacePage() {
  const { profile, loading } = useAuth(["0", "user"]);
  const params = useParams();
  const router = useRouter();
  const problemId = params?.id as string;

  const [problem, setProblem]         = useState<Problem | null>(null);
  const [probLoading, setProbLoading] = useState(true);
  const [activeTab, setActiveTab]     = useState<"problem" | "code" | "submit">("problem");
  const [code, setCode]               = useState(STARTER_CODE);
  const [activeFile, setActiveFile]   = useState("src/  index.ts");
  const [activeAgent, setActiveAgent] = useState(AI_AGENTS[0]);
  const [agentChat, setAgentChat]     = useState<Array<{ from: "user" | "agent"; text: string }>>([
    { from: "agent", text: `Hello! I'm ${AI_AGENTS[0].name}. I'll help you architect a solution for this problem. Ask me anything!` }
  ]);
  const [chatInput, setChatInput]     = useState("");
  const [termOutput, setTermOutput]   = useState("> Ready. Type a command or run your code.\n");

  // Submit form
  const [proposal, setProposal]               = useState("");
  const [solutionNotes, setSolutionNotes]     = useState("");
  const [techStack, setTechStack]             = useState<string[]>([]);
  const [repoUrl, setRepoUrl]                 = useState("");
  const [demoUrl, setDemoUrl]                 = useState("");
  const [estimatedHours, setEstimatedHours]   = useState(0);
  const [submitting, setSubmitting]           = useState(false);
  const [submitError, setSubmitError]         = useState<string | null>(null);
  const [submitted, setSubmitted]             = useState(false);

  useEffect(() => {
    if (!problemId) return;
    fetch(`/api/problems/${problemId}`)
      .then((r) => r.json())
      .then((d) => { setProblem(d.problem); setProbLoading(false); })
      .catch(() => setProbLoading(false));
  }, [problemId]);

  if (loading || !profile) return <Spinner />;

  function sendAgentMessage() {
    if (!chatInput.trim()) return;
    const userMsg = chatInput.trim();
    setChatInput("");
    setAgentChat((prev) => [...prev, { from: "user", text: userMsg }]);
    // Dummy AI response
    const suggestions = activeAgent.suggestions;
    const reply = suggestions[Math.floor(Math.random() * suggestions.length)];
    setTimeout(() => {
      setAgentChat((prev) => [...prev, { from: "agent", text: reply }]);
    }, 600);
  }

  function runCode() {
    setTermOutput((prev) =>
      prev + `\n> Running index.ts...\n[INFO] Compiled successfully.\n[INFO] Server started on port 3000.\n[LOG] GET /api/solution → 200 OK (12ms)\n`
    );
  }

  async function handleSubmit() {
    if (!proposal.trim()) { setSubmitError("Proposal is required."); return; }
    setSubmitting(true); setSubmitError(null);
    const res = await fetch("/api/submissions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        problem_id: problemId,
        proposal,
        solution_notes: solutionNotes,
        tech_stack: techStack,
        repo_url: repoUrl,
        demo_url: demoUrl,
        estimated_hours: estimatedHours,
      }),
    });
    const data = await res.json();
    if (!res.ok) { setSubmitError(data.error); }
    else { setSubmitted(true); }
    setSubmitting(false);
  }

  if (submitted) {
    return (
      <DashboardShell profile={profile}>
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <div className="mb-6 text-6xl">🎉</div>
          <h2 className="text-2xl font-extrabold text-white mb-2">Solution Submitted!</h2>
          <p className="text-secondary mb-8">The company will review your proposal. Check your submissions for updates.</p>
          <button onClick={() => router.push("/developer-dashboard")} className="btn-glow rounded-full bg-primary px-8 py-3 font-bold text-black">
            Back to Dashboard
          </button>
        </div>
      </DashboardShell>
    );
  }

  return (
    <DashboardShell profile={profile}>
      {/* Breadcrumb */}
      <div className="mb-4 flex items-center gap-2 text-xs text-secondary">
        <button onClick={() => router.push("/developer-dashboard")} className="hover:text-white transition-colors">Dashboard</button>
        <span>/</span>
        <span className="text-white">{probLoading ? "Loading…" : problem?.title ?? "Problem"}</span>
      </div>

      {probLoading ? (
        <div className="flex items-center justify-center py-24"><Spinner /></div>
      ) : !problem ? (
        <div className="text-center py-24 text-secondary">Problem not found.</div>
      ) : (
        <>
          {/* Problem header */}
          <div className="mb-6 rounded-2xl border border-white/8 bg-gradient-to-r from-primary/5 to-transparent p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h1 className="text-xl font-extrabold text-white">{problem.title}</h1>
                <p className="mt-1 text-sm text-secondary">Budget: <span className="text-primary font-bold">${problem.budget.toLocaleString()}</span> · Deadline: {new Date(problem.deadline).toLocaleDateString()}</p>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {problem.skills.map((s) => (
                  <span key={s} className="rounded-full border border-primary/20 bg-primary/5 px-2.5 py-0.5 text-xs text-primary">{s}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="mb-6 flex gap-1 rounded-2xl border border-white/8 bg-white/3 p-1">
            {(["problem", "code", "submit"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all",
                  activeTab === tab ? "bg-primary text-black" : "text-secondary hover:text-white"
                )}
              >
                {{ problem: "📋 Problem", code: "💻 Workspace", submit: "📤 Submit" }[tab]}
              </button>
            ))}
          </div>

          {/* ── PROBLEM TAB ── */}
          {activeTab === "problem" && (
            <div className="rounded-2xl border border-white/8 bg-white/3 p-6">
              <h2 className="mb-3 text-sm font-bold uppercase tracking-widest text-secondary">Description</h2>
              <p className="text-sm text-white/80 leading-relaxed whitespace-pre-wrap">{problem.description}</p>
              <div className="mt-6">
                <button onClick={() => setActiveTab("code")} className="btn-glow rounded-full bg-primary px-6 py-2.5 text-sm font-bold text-black">
                  Open Workspace →
                </button>
              </div>
            </div>
          )}

          {/* ── CODE TAB ── */}
          {activeTab === "code" && (
            <div className="grid grid-cols-1 gap-4 xl:grid-cols-[220px_1fr_280px]">

              {/* File tree */}
              <div className="rounded-2xl border border-white/8 bg-black/60 p-3 font-mono text-xs">
                <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-secondary/60">Explorer</p>
                {DUMMY_FILES.map((f) => (
                  <button
                    key={f.name}
                    onClick={() => f.type === "file" && setActiveFile(f.name)}
                    className={cn(
                      "w-full text-left px-2 py-0.5 rounded transition-colors",
                      f.type === "folder" ? "text-secondary font-bold" : "text-white/70 hover:text-white hover:bg-white/5",
                      activeFile === f.name && "bg-primary/10 text-primary"
                    )}
                  >
                    {f.type === "folder" ? "📁" : "📄"} {f.name.trim()}
                  </button>
                ))}
              </div>

              {/* Code editor + terminal */}
              <div className="flex flex-col gap-3">
                {/* Editor header */}
                <div className="flex items-center gap-2 rounded-t-xl border border-b-0 border-white/8 bg-black/80 px-4 py-2">
                  <div className="flex gap-1.5">
                    <span className="h-3 w-3 rounded-full bg-red-500/70"></span>
                    <span className="h-3 w-3 rounded-full bg-yellow-500/70"></span>
                    <span className="h-3 w-3 rounded-full bg-green-500/70"></span>
                  </div>
                  <span className="ml-2 text-xs text-secondary font-mono">{activeFile.trim()}</span>
                </div>

                {/* Code area */}
                <textarea
                  className="min-h-[300px] resize-y rounded-none border border-white/8 bg-black/90 p-4 font-mono text-xs text-green-400 focus:outline-none focus:border-primary/30"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  spellCheck={false}
                />

                {/* Terminal */}
                <div className="rounded-b-xl border border-t-0 border-white/8 bg-black">
                  <div className="flex items-center justify-between border-b border-white/5 px-4 py-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-secondary/60">Terminal</span>
                    <button onClick={runCode} className="rounded-lg border border-primary/30 bg-primary/10 px-3 py-0.5 text-[10px] font-bold text-primary hover:bg-primary/20 transition-colors">
                      ▶ Run
                    </button>
                  </div>
                  <pre className="h-28 overflow-y-auto p-3 font-mono text-[11px] text-green-400 whitespace-pre-wrap">
                    {termOutput}
                  </pre>
                </div>
              </div>

              {/* AI Agents panel */}
              <div className="flex flex-col rounded-2xl border border-white/8 bg-black/60 overflow-hidden">
                {/* Agent selector */}
                <div className="border-b border-white/8 p-3">
                  <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-secondary/60">AI Agents</p>
                  <div className="flex flex-col gap-1">
                    {AI_AGENTS.map((agent) => (
                      <button
                        key={agent.id}
                        onClick={() => {
                          setActiveAgent(agent);
                          setAgentChat([{ from: "agent", text: `Hello! I'm ${agent.name}. ${agent.suggestions[0]}` }]);
                        }}
                        className={cn(
                          "flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold text-left transition-all",
                          activeAgent.id === agent.id
                            ? "bg-white/8 text-white border border-white/10"
                            : "text-secondary hover:bg-white/5"
                        )}
                      >
                        <span>{agent.avatar}</span>
                        <span>{agent.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Chat */}
                <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2 min-h-[200px]">
                  {agentChat.map((msg, i) => (
                    <div key={i} className={cn("rounded-xl px-3 py-2 text-xs max-w-[90%]",
                      msg.from === "agent"
                        ? "bg-white/5 text-white self-start"
                        : "bg-primary/20 text-primary self-end"
                    )}>
                      {msg.from === "agent" && (
                        <p className="mb-0.5 text-[9px] font-bold uppercase tracking-widest text-secondary/50">{activeAgent.name}</p>
                      )}
                      {msg.text}
                    </div>
                  ))}
                </div>

                {/* Chat input */}
                <div className="border-t border-white/8 p-2 flex gap-2">
                  <input
                    className="flex-1 rounded-xl border border-white/8 bg-white/3 px-3 py-1.5 text-xs text-white placeholder:text-secondary/50 focus:outline-none focus:border-primary/30"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") sendAgentMessage(); }}
                    placeholder="Ask the AI agent…"
                  />
                  <button onClick={sendAgentMessage} className="rounded-xl bg-primary/20 border border-primary/30 px-2 text-xs text-primary hover:bg-primary/30 transition-colors">
                    →
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ── SUBMIT TAB ── */}
          {activeTab === "submit" && (
            <div className="rounded-2xl border border-white/8 bg-white/3 p-6 max-w-2xl">
              <h2 className="mb-1 text-lg font-extrabold text-white">Submit Your Solution</h2>
              <p className="mb-6 text-sm text-secondary">Fill in the details below. The company will review your submission.</p>

              {submitError && (
                <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">{submitError}</div>
              )}

              <div className="flex flex-col gap-4">
                <FormField label="Cover Letter / Proposal *">
                  <textarea className="input-glow min-h-[100px] resize-y" value={proposal}
                    onChange={(e) => setProposal(e.target.value)}
                    placeholder="Why are you the right developer for this problem? Describe your approach…" />
                </FormField>

                <FormField label="Technical Notes">
                  <textarea className="input-glow min-h-[80px] resize-y" value={solutionNotes}
                    onChange={(e) => setSolutionNotes(e.target.value)}
                    placeholder="Architecture decisions, trade-offs, known limitations…" />
                </FormField>

                <FormField label="Tech Stack">
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {techStack.map((s) => (
                      <span key={s} className="flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 text-xs text-primary">
                        {s}
                        <button onClick={() => setTechStack((p) => p.filter((x) => x !== s))} className="text-primary/50 hover:text-primary">×</button>
                      </span>
                    ))}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {TECH_STACK_OPTIONS.filter((s) => !techStack.includes(s)).map((s) => (
                      <button key={s} onClick={() => setTechStack((p) => [...p, s])}
                        className="rounded-full border border-white/8 bg-white/3 px-2.5 py-0.5 text-xs text-secondary hover:text-white hover:border-primary/30 transition-colors">
                        + {s}
                      </button>
                    ))}
                  </div>
                </FormField>

                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField label="Repository URL">
                    <input className="input-glow" value={repoUrl}
                      onChange={(e) => setRepoUrl(e.target.value)}
                      placeholder="https://github.com/you/repo" />
                  </FormField>
                  <FormField label="Demo / Live URL">
                    <input className="input-glow" value={demoUrl}
                      onChange={(e) => setDemoUrl(e.target.value)}
                      placeholder="https://your-demo.com" />
                  </FormField>
                  <FormField label="Estimated Hours">
                    <input className="input-glow" type="number" min={0} value={estimatedHours}
                      onChange={(e) => setEstimatedHours(Number(e.target.value))}
                      placeholder="40" />
                  </FormField>
                </div>

                <button
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="btn-glow rounded-2xl bg-primary py-4 font-bold text-black transition-all hover:-translate-y-0.5 disabled:opacity-50"
                >
                  {submitting ? "Submitting…" : "🚀 Submit Solution"}
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </DashboardShell>
  );
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-xs font-semibold text-secondary">{label}</label>
      {children}
    </div>
  );
}

function Spinner() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
    </div>
  );
}
