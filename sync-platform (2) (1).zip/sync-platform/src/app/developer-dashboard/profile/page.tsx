"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import { cn } from "@/lib/utils";
import ContributionHeatmap from "@/components/ui/ContributionHeatmap";
import type { WorkExperience } from "@/types";

const WORKING_STATUS_OPTIONS = [
  { value: "available",      label: "Available",        color: "text-primary",     dot: "bg-primary" },
  { value: "open_to_offers", label: "Open to Offers",   color: "text-yellow-400",  dot: "bg-yellow-400" },
  { value: "busy",           label: "Not Available",    color: "text-red-400",     dot: "bg-red-400" },
];

const AVATAR_COLORS = ["#22c55e", "#3b82f6", "#a855f7", "#f59e0b", "#ef4444", "#06b6d4", "#f97316", "#ec4899"];

const SKILL_SUGGESTIONS = [
  "React", "Next.js", "TypeScript", "Node.js", "Python", "Rust", "Go",
  "PostgreSQL", "SQLite", "MongoDB", "Docker", "Kubernetes", "AWS",
  "GraphQL", "REST API", "WebSockets", "Machine Learning", "OpenAI API",
  "Solidity", "Web3", "Figma", "TailwindCSS", "Vue.js", "Angular",
];

export default function ProfilePage() {
  const { profile, loading } = useAuth(["0", "user"]);

  const [form, setForm] = useState({
    name: "", bio: "", github_url: "", linkedin_url: "", portfolio_url: "",
    location: "", hourly_rate: 0, working_status: "available", avatar_color: "#22c55e",
  });
  const [skills, setSkills]       = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState("");
  const [experience, setExperience] = useState<WorkExperience[]>([]);
  const [saving, setSaving]         = useState(false);
  const [saved, setSaved]           = useState(false);
  const [error, setError]           = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;
    fetch("/api/profile")
      .then((r) => r.json())
      .then((d) => {
        const p = d.profile;
        setForm({
          name: p.name ?? "",
          bio: p.bio ?? "",
          github_url: p.github_url ?? "",
          linkedin_url: p.linkedin_url ?? "",
          portfolio_url: p.portfolio_url ?? "",
          location: p.location ?? "",
          hourly_rate: p.hourly_rate ?? 0,
          working_status: p.working_status ?? "available",
          avatar_color: p.avatar_color ?? "#22c55e",
        });
        setSkills(Array.isArray(p.skills) ? p.skills : []);
        setExperience(Array.isArray(p.experience) ? p.experience : []);
      });
  }, [profile]);

  if (loading || !profile) return <LoadingSkeleton />;

  async function handleSave() {
    setSaving(true); setError(null);
    try {
      const res = await fetch("/api/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, skills, experience }),
      });
      if (!res.ok) { const d = await res.json(); setError(d.error); }
      else { setSaved(true); setTimeout(() => setSaved(false), 3000); }
    } catch { setError("Save failed."); }
    setSaving(false);
  }

  function addSkill(s: string) {
    const trimmed = s.trim();
    if (trimmed && !skills.includes(trimmed)) setSkills((prev) => [...prev, trimmed]);
    setSkillInput("");
  }

  function addExperience() {
    setExperience((prev) => [...prev, { company: "", role: "", duration: "", description: "" }]);
  }

  function updateExp(i: number, field: keyof WorkExperience, val: string) {
    setExperience((prev) => prev.map((e, idx) => idx === i ? { ...e, [field]: val } : e));
  }

  const statusCfg = WORKING_STATUS_OPTIONS.find((o) => o.value === form.working_status) ?? WORKING_STATUS_OPTIONS[0];

  return (
    <DashboardShell profile={profile}>
      <div className="max-w-3xl mx-auto">

        {/* Header */}
        <div className="mb-10">
          <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-primary">My Profile</p>
          <h1 className="text-3xl font-extrabold text-white">Build Your Dev Profile</h1>
          <p className="mt-2 text-secondary text-sm">Complete your profile to get noticed by companies.</p>
        </div>

        {/* Save feedback */}
        {saved && (
          <div className="mb-6 rounded-2xl border border-primary/30 bg-primary/10 px-4 py-3 text-sm font-medium text-primary">
            ✓ Profile saved successfully!
          </div>
        )}
        {error && (
          <div className="mb-6 rounded-2xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">
            {error}
          </div>
        )}

        {/* Avatar & availability */}
        <div className="card-3d mb-6 rounded-2xl border border-white/8 bg-white/3 p-6">
          <h2 className="mb-4 text-sm font-bold uppercase tracking-widest text-secondary">Identity</h2>
          <div className="flex items-center gap-6 flex-wrap">
            {/* Avatar preview */}
            <div
              className="h-20 w-20 rounded-full border-2 flex items-center justify-center text-3xl font-black text-black shrink-0"
              style={{ background: form.avatar_color, borderColor: form.avatar_color }}
            >
              {form.name.charAt(0).toUpperCase() || "?"}
            </div>
            {/* Color picker */}
            <div>
              <p className="mb-2 text-xs text-secondary">Avatar colour</p>
              <div className="flex gap-2 flex-wrap">
                {AVATAR_COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => setForm((f) => ({ ...f, avatar_color: c }))}
                    className={cn("h-7 w-7 rounded-full transition-transform", form.avatar_color === c && "scale-125 ring-2 ring-white/40")}
                    style={{ background: c }}
                  />
                ))}
              </div>
            </div>
            {/* Availability */}
            <div className="ml-auto">
              <p className="mb-2 text-xs text-secondary">Availability</p>
              <div className="flex gap-2 flex-wrap">
                {WORKING_STATUS_OPTIONS.map((o) => (
                  <button
                    key={o.value}
                    onClick={() => setForm((f) => ({ ...f, working_status: o.value }))}
                    className={cn(
                      "flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold transition-all",
                      form.working_status === o.value
                        ? `${o.color} border-current bg-current/10`
                        : "border-white/10 text-secondary hover:border-white/20"
                    )}
                  >
                    <span className={cn("h-1.5 w-1.5 rounded-full", o.dot)} />
                    {o.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Basic Info */}
        <div className="card-3d mb-6 rounded-2xl border border-white/8 bg-white/3 p-6">
          <h2 className="mb-4 text-sm font-bold uppercase tracking-widest text-secondary">Basic Info</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Full Name">
              <input className="input-glow" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Your name" />
            </Field>
            <Field label="Location">
              <input className="input-glow" value={form.location} onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))} placeholder="City, Country" />
            </Field>
            <Field label="Hourly Rate (USD)" className="sm:col-span-2">
              <input className="input-glow w-40" type="number" min={0} value={form.hourly_rate}
                onChange={(e) => setForm((f) => ({ ...f, hourly_rate: Number(e.target.value) }))} placeholder="0" />
            </Field>
            <Field label="Bio" className="sm:col-span-2">
              <textarea className="input-glow min-h-[90px] resize-y" value={form.bio}
                onChange={(e) => setForm((f) => ({ ...f, bio: e.target.value }))}
                placeholder="Tell companies about yourself, your background and what you enjoy building..." />
            </Field>
          </div>
        </div>

        {/* Links */}
        <div className="card-3d mb-6 rounded-2xl border border-white/8 bg-white/3 p-6">
          <h2 className="mb-4 text-sm font-bold uppercase tracking-widest text-secondary">Links</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="GitHub">
              <input className="input-glow" value={form.github_url} onChange={(e) => setForm((f) => ({ ...f, github_url: e.target.value }))} placeholder="https://github.com/username" />
            </Field>
            <Field label="LinkedIn">
              <input className="input-glow" value={form.linkedin_url} onChange={(e) => setForm((f) => ({ ...f, linkedin_url: e.target.value }))} placeholder="https://linkedin.com/in/username" />
            </Field>
            <Field label="Portfolio" className="sm:col-span-2">
              <input className="input-glow" value={form.portfolio_url} onChange={(e) => setForm((f) => ({ ...f, portfolio_url: e.target.value }))} placeholder="https://yoursite.com" />
            </Field>
          </div>
        </div>

        {/* Skills */}
        <div className="card-3d mb-6 rounded-2xl border border-white/8 bg-white/3 p-6">
          <h2 className="mb-4 text-sm font-bold uppercase tracking-widest text-secondary">Skills</h2>
          <div className="flex flex-wrap gap-2 mb-3 min-h-[32px]">
            {skills.map((s) => (
              <span key={s} className="flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
                {s}
                <button onClick={() => setSkills((prev) => prev.filter((x) => x !== s))} className="ml-1 text-primary/50 hover:text-primary">×</button>
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              className="input-glow flex-1"
              value={skillInput}
              onChange={(e) => setSkillInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addSkill(skillInput); } }}
              placeholder="Type a skill and press Enter"
            />
            <button onClick={() => addSkill(skillInput)} className="rounded-xl border border-primary/30 bg-primary/10 px-4 text-sm font-semibold text-primary hover:bg-primary/20 transition-colors">
              Add
            </button>
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {SKILL_SUGGESTIONS.filter((s) => !skills.includes(s)).slice(0, 12).map((s) => (
              <button key={s} onClick={() => addSkill(s)}
                className="rounded-full border border-white/8 bg-white/3 px-2.5 py-0.5 text-[11px] text-secondary hover:text-white hover:border-primary/30 transition-colors">
                + {s}
              </button>
            ))}
          </div>
        </div>

        {/* Experience */}
        <div className="card-3d mb-8 rounded-2xl border border-white/8 bg-white/3 p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-widest text-secondary">Experience</h2>
            <button onClick={addExperience} className="rounded-xl border border-white/10 px-3 py-1.5 text-xs font-semibold text-secondary hover:text-white hover:border-white/20 transition-colors">
              + Add Role
            </button>
          </div>
          {experience.length === 0 && (
            <p className="text-sm text-secondary/50">No experience added yet. Click "+ Add Role" to begin.</p>
          )}
          {experience.map((exp, i) => (
            <div key={i} className="mb-4 rounded-xl border border-white/8 bg-black/30 p-4">
              <div className="grid gap-3 sm:grid-cols-2 mb-3">
                <Field label="Company">
                  <input className="input-glow" value={exp.company} onChange={(e) => updateExp(i, "company", e.target.value)} placeholder="Company name" />
                </Field>
                <Field label="Role">
                  <input className="input-glow" value={exp.role} onChange={(e) => updateExp(i, "role", e.target.value)} placeholder="Software Engineer" />
                </Field>
                <Field label="Duration" className="sm:col-span-2">
                  <input className="input-glow" value={exp.duration} onChange={(e) => updateExp(i, "duration", e.target.value)} placeholder="Jan 2022 – Mar 2024" />
                </Field>
                <Field label="Description (optional)" className="sm:col-span-2">
                  <textarea className="input-glow min-h-[60px] resize-y" value={exp.description ?? ""}
                    onChange={(e) => updateExp(i, "description", e.target.value)} placeholder="What did you build?" />
                </Field>
              </div>
              <button onClick={() => setExperience((prev) => prev.filter((_, idx) => idx !== i))}
                className="text-xs text-red-400/60 hover:text-red-400 transition-colors">
                Remove
              </button>
            </div>
          ))}
        </div>

        {/* Contribution Heatmap */}
        <div className="mb-8">
          <ContributionHeatmap devId={profile.id} />
        </div>

        {/* Save */}
        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full btn-glow rounded-2xl bg-primary py-4 text-base font-bold text-black transition-all duration-300 hover:-translate-y-0.5 disabled:opacity-50"
        >
          {saving ? "Saving…" : "Save Profile"}
        </button>

        <div className="mt-4 text-center text-xs text-secondary/40">
          Current status: <span className={statusCfg.color}>{statusCfg.label}</span>
          {" · "}{profile.contributions ?? 0} contributions{" · "}
          <span className="text-white">{profile.email}</span>
        </div>
      </div>
    </DashboardShell>
  );
}

function Field({
  label, children, className,
}: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("flex flex-col gap-1", className)}>
      <label className="text-xs font-semibold text-secondary">{label}</label>
      {children}
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
    </div>
  );
}
