﻿"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import type { Problem } from "@/types";

export default function DeveloperDashboard() {
  const { profile, loading } = useAuth(["0", "user"]);
  const [openProblems, setOpenProblems] = useState<Problem[]>([]);
  const [mySubmissions, setMySubmissions] = useState<number>(0);
  const [myAccepted, setMyAccepted] = useState<number>(0);
  const [myRank, setMyRank] = useState<number | null>(null);
  const [dataLoading, setDataLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    Promise.all([
      fetch("/api/problems").then((r) => r.json()),
      fetch("/api/submissions").then((r) => r.json()),
      fetch("/api/community").then((r) => r.json()),
    ]).then(([pData, sData, cData]) => {
      setOpenProblems(pData.problems ?? []);
      const subs = sData.submissions ?? [];
      setMySubmissions(subs.length);
      setMyAccepted(subs.filter((s: { status: string }) => s.status === "accepted").length);
      const devs: { id: string }[] = cData.developers ?? [];
      const rank = devs.findIndex((d) => d.id === profile.id);
      if (rank !== -1) setMyRank(rank + 1);
      setDataLoading(false);
    }).catch(() => setDataLoading(false));
  }, [profile]);

  if (loading || !profile) return <LoadingSkeleton />;

  return (
    <DashboardShell profile={profile}>
      {/* Welcome */}
      <div className="mb-8">
        <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-primary">Developer Workspace</p>
        <h1 className="text-3xl font-extrabold text-white sm:text-4xl">
          Hey, <span className="text-primary">{profile.name}</span> 👋
        </h1>
        <p className="mt-2 text-secondary">Browse open challenges and submit your proposals.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 mb-10">
        {[
          { label: "Open Jobs",    value: openProblems.length.toString(), icon: "📋", href: null },
          { label: "Applied",      value: mySubmissions.toString(),       icon: "📤", href: null },
          { label: "Accepted",     value: myAccepted.toString(),          icon: "✅", href: null },
          { label: "Leaderboard",  value: myRank ? `#${myRank}` : "—",   icon: "🏆", href: "/developer-dashboard/community" },
        ].map((s) => {
          const inner = (
            <div className="card-3d rounded-2xl border border-white/8 bg-gradient-to-br from-primary/5 to-transparent p-6">
              <span className="text-xl">{s.icon}</span>
              <p className="mt-2 text-2xl font-black text-primary">{s.value}</p>
              <p className="mt-1 text-xs text-secondary uppercase tracking-wider">{s.label}</p>
            </div>
          );
          return s.href
            ? <Link key={s.label} href={s.href}>{inner}</Link>
            : <div key={s.label}>{inner}</div>;
        })}
      </div>

      {/* Quick actions */}
      <div className="mb-8 grid grid-cols-3 gap-3 sm:grid-cols-3">
        {[
          { label: "Community",   href: "/developer-dashboard/community", icon: "👥", desc: "Connect with devs" },
          { label: "Messages",    href: "/developer-dashboard/messages",  icon: "💬", desc: "Chat with friends" },
          { label: "My Profile",  href: "/developer-dashboard/profile",   icon: "🧑‍💻", desc: "Update your profile" },
        ].map((a) => (
          <Link key={a.label} href={a.href}
            className="rounded-2xl border border-white/8 bg-white/3 p-4 text-center hover:border-primary/30 hover:bg-primary/5 transition-all duration-200 group">
            <span className="text-2xl">{a.icon}</span>
            <p className="mt-1 text-sm font-bold text-white group-hover:text-primary transition-colors">{a.label}</p>
            <p className="text-[10px] text-secondary">{a.desc}</p>
          </Link>
        ))}
      </div>

      {/* Open Problems */}
      <div className="mb-5 flex items-center justify-between">
        <h2 className="text-lg font-bold text-white">Open Challenges</h2>
        <span className="text-xs text-secondary">{openProblems.length} available</span>
      </div>

      {dataLoading ? (
        <div className="grid gap-4 sm:grid-cols-2">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-36 rounded-2xl border border-white/5 bg-white/3 animate-pulse" />
          ))}
        </div>
      ) : openProblems.length === 0 ? (
        <div className="rounded-2xl border border-white/8 bg-white/3 p-12 text-center">
          <p className="text-4xl mb-3">🔍</p>
          <p className="text-white font-semibold">No open challenges yet</p>
          <p className="text-sm text-secondary mt-1">Check back soon — companies are posting challenges.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {openProblems.map((p) => (
            <Link
              key={p.id}
              href={`/developer-dashboard/problems/${p.id}`}
              className="card-3d group relative rounded-2xl border border-white/8 bg-gradient-to-br from-white/3 to-transparent p-6 transition-all duration-300 hover:border-primary/30 hover:from-primary/5"
            >
              <div className="flex items-start justify-between mb-3">
                <span className="rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-primary">
                  Open
                </span>
                <span className="text-sm font-bold text-primary">${p.budget.toLocaleString()}</span>
              </div>
              <h3 className="font-bold text-white mb-1 group-hover:text-primary transition-colors">{p.title}</h3>
              <p className="text-xs text-secondary line-clamp-2 mb-3">{p.description}</p>
              <div className="flex flex-wrap gap-1.5">
                {p.skills.slice(0, 4).map((s) => (
                  <span key={s} className="rounded-full border border-white/8 bg-white/5 px-2 py-0.5 text-[10px] text-secondary">{s}</span>
                ))}
              </div>
              <div className="mt-3 flex items-center justify-between text-[10px] text-secondary/60">
                <span>Deadline: {new Date(p.deadline).toLocaleDateString()}</span>
                <span className="text-primary font-semibold opacity-0 group-hover:opacity-100 transition-opacity">Open Workspace →</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </DashboardShell>
  );
}

function LoadingSkeleton() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
    </div>
  );
}


