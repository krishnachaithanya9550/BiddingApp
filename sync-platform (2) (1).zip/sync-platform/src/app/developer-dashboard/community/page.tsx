"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import { cn } from "@/lib/utils";
import ContributionHeatmap from "@/components/ui/ContributionHeatmap";
import type { DeveloperPublicProfile } from "@/types";

const STATUS_STYLE: Record<string, { label: string; color: string; dot: string }> = {
  available:      { label: "Available",      color: "text-primary",    dot: "bg-primary" },
  open_to_offers: { label: "Open to Offers", color: "text-yellow-400", dot: "bg-yellow-400" },
  busy:           { label: "Unavailable",    color: "text-red-400",    dot: "bg-red-400" },
};

export default function CommunityPage() {
  const { profile, loading } = useAuth(["0", "user"]);
  const router = useRouter();

  const [developers, setDevelopers] = useState<DeveloperPublicProfile[]>([]);
  const [dataLoading, setDataLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [actionLoading, setActionLoading] = useState<Record<string, boolean>>({});
  const [selectedDev, setSelectedDev] = useState<DeveloperPublicProfile | null>(null);

  async function loadDevelopers() {
    const res = await fetch("/api/community");
    const d = await res.json();
    setDevelopers(d.developers ?? []);
    setDataLoading(false);
  }

  useEffect(() => {
    if (!profile) return;
    loadDevelopers();
  }, [profile]);

  if (loading || !profile) return <LoadingSkeleton />;

  // Separate incoming pending requests
  const incomingRequests = developers.filter(
    (d) => d.id !== profile.id && d.friendship_status === "pending_received"
  );

  const filtered = developers.filter((d) => {
    if (d.id === profile.id) return false;
    if (d.friendship_status === "pending_received") return false; // shown in requests section
    const matchSearch = !search ||
      d.name.toLowerCase().includes(search.toLowerCase()) ||
      d.location?.toLowerCase().includes(search.toLowerCase()) ||
      (Array.isArray(d.skills) && d.skills.some((s: string) => s.toLowerCase().includes(search.toLowerCase())));
    const matchStatus = statusFilter === "all" || d.working_status === statusFilter;
    return matchSearch && matchStatus;
  });

  async function handleSendRequest(dev: DeveloperPublicProfile) {
    setActionLoading((p) => ({ ...p, [dev.id]: true }));
    try {
      const res = await fetch("/api/friendships", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ addressee_id: dev.id }),
      });
      if (res.ok) {
        const data = await res.json();
        updateDev(dev.id, { friendship_status: "pending_sent", friendship_id: data.id });
      }
    } finally {
      setActionLoading((p) => ({ ...p, [dev.id]: false }));
    }
  }

  async function handleRespond(dev: DeveloperPublicProfile, action: "accepted" | "declined") {
    if (!dev.friendship_id) return;
    setActionLoading((p) => ({ ...p, [dev.id]: true }));
    try {
      const res = await fetch(`/api/friendships/${dev.friendship_id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: action }),
      });
      if (res.ok) {
        updateDev(dev.id, { friendship_status: action === "accepted" ? "accepted" : "none", friendship_id: action === "accepted" ? dev.friendship_id : null });
        if (selectedDev?.id === dev.id) setSelectedDev(null);
      }
    } finally {
      setActionLoading((p) => ({ ...p, [dev.id]: false }));
    }
  }

  function updateDev(id: string, patch: Partial<DeveloperPublicProfile>) {
    setDevelopers((prev) => prev.map((d) => d.id === id ? { ...d, ...patch } : d));
    setSelectedDev((prev) => prev?.id === id ? { ...prev, ...patch } : prev);
  }

  return (
    <DashboardShell profile={profile}>
      {/* Header */}
      <div className="mb-8">
        <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-primary">Community</p>
        <h1 className="text-3xl font-extrabold text-white">Developer Network</h1>
        <p className="mt-2 text-secondary text-sm">Connect with fellow developers, form teams, and collaborate.</p>
      </div>

      {/* ── Incoming Requests Banner ── */}
      {incomingRequests.length > 0 && (
        <div className="mb-8 rounded-2xl border border-yellow-500/30 bg-yellow-500/5 p-5">
          <p className="mb-4 flex items-center gap-2 text-sm font-bold text-yellow-400">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-yellow-400 text-[10px] font-black text-black">
              {incomingRequests.length}
            </span>
            Incoming Connect Request{incomingRequests.length > 1 ? "s" : ""}
          </p>
          <div className="flex flex-col gap-3">
            {incomingRequests.map((dev) => {
              const isLoading = !!actionLoading[dev.id];
              return (
                <div key={dev.id} className="flex items-center gap-3 rounded-xl border border-white/8 bg-black/40 p-3">
                  <div
                    className="h-10 w-10 shrink-0 rounded-full flex items-center justify-center text-lg font-black text-black"
                    style={{ background: dev.avatar_color || "#22c55e" }}
                  >
                    {dev.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-white text-sm truncate">{dev.name}</p>
                    <p className="text-xs text-secondary truncate">
                      {Array.isArray(dev.skills) && dev.skills.slice(0, 3).join(", ")}
                    </p>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <button
                      onClick={() => handleRespond(dev, "accepted")}
                      disabled={isLoading}
                      className="rounded-full bg-primary px-3 py-1.5 text-xs font-bold text-black transition-opacity hover:opacity-80 disabled:opacity-40"
                    >
                      {isLoading ? "…" : "✓ Accept"}
                    </button>
                    <button
                      onClick={() => handleRespond(dev, "declined")}
                      disabled={isLoading}
                      className="rounded-full border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-xs font-bold text-red-400 hover:bg-red-500/20 transition-colors disabled:opacity-40"
                    >
                      {isLoading ? "…" : "✕ Decline"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="mb-6 flex flex-col gap-3 sm:flex-row">
        <input
          className="input-glow flex-1"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search name, skills, or location…"
        />
        <div className="flex gap-2 flex-wrap">
          {["all", "available", "open_to_offers", "busy"].map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={cn(
                "rounded-full border px-3 py-2 text-xs font-semibold transition-all",
                statusFilter === s
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-white/10 text-secondary hover:border-white/20"
              )}
            >
              {s === "all" ? "All" : STATUS_STYLE[s]?.label ?? s}
            </button>
          ))}
        </div>
      </div>

      <p className="mb-5 text-sm text-secondary">{filtered.length} developer{filtered.length !== 1 ? "s" : ""} found</p>

      {/* Grid */}
      {dataLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-52 rounded-2xl border border-white/5 bg-white/3 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-white/8 bg-white/3 p-12 text-center">
          <p className="text-4xl mb-3">👥</p>
          <p className="text-white font-semibold">No developers found</p>
          <p className="text-sm text-secondary mt-1">Try adjusting your filters.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((dev, idx) => {
            const statusInfo = STATUS_STYLE[dev.working_status] ?? STATUS_STYLE.busy;
            return (
              <div
                key={dev.id}
                className="card-3d group relative rounded-2xl border border-white/8 bg-gradient-to-br from-white/3 to-transparent p-5 cursor-pointer transition-all duration-300 hover:border-primary/30"
                onClick={() => setSelectedDev(dev)}
              >
                <div className="absolute top-3 right-3 rounded-full border border-white/10 bg-black/50 px-2 py-0.5 text-[10px] font-bold text-secondary">
                  #{idx + 1}
                </div>
                <div className="mb-3 flex items-center gap-3">
                  <div
                    className="relative h-12 w-12 shrink-0 rounded-full flex items-center justify-center text-xl font-black text-black"
                    style={{ background: dev.avatar_color || "#22c55e" }}
                  >
                    {dev.name.charAt(0).toUpperCase()}
                    <span className={cn("absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-black", statusInfo.dot)} />
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-white truncate">{dev.name}</p>
                    <p className="text-xs text-secondary truncate">{dev.location || "No location"}</p>
                  </div>
                </div>
                {dev.bio && <p className="text-xs text-secondary mb-3 line-clamp-2">{dev.bio}</p>}
                {Array.isArray(dev.skills) && dev.skills.length > 0 && (
                  <div className="mb-3 flex flex-wrap gap-1">
                    {dev.skills.slice(0, 4).map((s: string) => (
                      <span key={s} className="rounded-full border border-primary/20 bg-primary/5 px-2 py-0.5 text-[10px] text-primary">{s}</span>
                    ))}
                    {dev.skills.length > 4 && (
                      <span className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] text-secondary">+{dev.skills.length - 4}</span>
                    )}
                  </div>
                )}
                <div className="flex items-center justify-between border-t border-white/5 pt-3">
                  <div className="flex gap-3 text-xs text-secondary">
                    <span>🔥 {dev.contributions ?? 0}</span>
                    {dev.hourly_rate ? <span>💵 ${dev.hourly_rate}/hr</span> : null}
                  </div>
                  <ConnectButton
                    dev={dev}
                    loading={!!actionLoading[dev.id]}
                    onSend={(e) => { e.stopPropagation(); handleSendRequest(dev); }}
                    onAccept={(e) => { e.stopPropagation(); handleRespond(dev, "accepted"); }}
                    onDecline={(e) => { e.stopPropagation(); handleRespond(dev, "declined"); }}
                    onMessage={(e) => { e.stopPropagation(); router.push("/developer-dashboard/messages"); }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Dev detail modal */}
      {selectedDev && (
        <DevModal
          dev={selectedDev}
          loading={!!actionLoading[selectedDev.id]}
          onClose={() => setSelectedDev(null)}
          onSend={() => handleSendRequest(selectedDev)}
          onAccept={() => handleRespond(selectedDev, "accepted")}
          onDecline={() => handleRespond(selectedDev, "declined")}
          onMessage={() => { setSelectedDev(null); router.push("/developer-dashboard/messages"); }}
        />
      )}
    </DashboardShell>
  );
}

// ── ConnectButton (card inline) ───────────────────────────────────────────────

function ConnectButton({ dev, loading, onSend, onAccept, onDecline, onMessage }: {
  dev: DeveloperPublicProfile;
  loading: boolean;
  onSend: (e: React.MouseEvent) => void;
  onAccept: (e: React.MouseEvent) => void;
  onDecline: (e: React.MouseEvent) => void;
  onMessage: (e: React.MouseEvent) => void;
}) {
  const status = dev.friendship_status ?? "none";

  if (status === "accepted") return (
    <button onClick={onMessage}
      className="rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 text-[10px] font-bold text-primary hover:bg-primary/20 transition-colors">
      💬 Message
    </button>
  );

  if (status === "pending_sent") return (
    <span className="rounded-full border border-white/10 px-2.5 py-0.5 text-[10px] font-semibold text-secondary">Pending…</span>
  );

  if (status === "pending_received") return (
    <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
      <button onClick={onAccept} disabled={loading}
        className="rounded-full bg-primary px-2.5 py-0.5 text-[10px] font-bold text-black disabled:opacity-40 hover:opacity-80 transition-opacity">
        {loading ? "…" : "✓"}
      </button>
      <button onClick={onDecline} disabled={loading}
        className="rounded-full border border-red-500/30 bg-red-500/10 px-2.5 py-0.5 text-[10px] font-bold text-red-400 disabled:opacity-40">
        {loading ? "…" : "✕"}
      </button>
    </div>
  );

  return (
    <button onClick={onSend} disabled={loading}
      className="rounded-full border border-white/10 px-2.5 py-0.5 text-[10px] font-semibold text-secondary hover:border-primary/30 hover:text-primary transition-all disabled:opacity-50">
      {loading ? "…" : "+ Connect"}
    </button>
  );
}

// ── DevModal ─────────────────────────────────────────────────────────────────

function DevModal({ dev, loading, onClose, onSend, onAccept, onDecline, onMessage }: {
  dev: DeveloperPublicProfile;
  loading: boolean;
  onClose: () => void;
  onSend: () => void;
  onAccept: () => void;
  onDecline: () => void;
  onMessage: () => void;
}) {
  const statusInfo = STATUS_STYLE[dev.working_status] ?? STATUS_STYLE.busy;
  const fs = dev.friendship_status ?? "none";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-lg rounded-3xl border border-white/10 bg-black/90 p-7 shadow-2xl overflow-y-auto max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-secondary hover:text-white text-xl">✕</button>

        {/* Avatar + name */}
        <div className="flex items-center gap-4 mb-6">
          <div className="relative h-16 w-16 shrink-0 rounded-full flex items-center justify-center text-2xl font-black text-black"
            style={{ background: dev.avatar_color || "#22c55e" }}>
            {dev.name.charAt(0).toUpperCase()}
            <span className={cn("absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-black", statusInfo.dot)} />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-white">{dev.name}</h2>
            <p className={cn("text-sm font-semibold", statusInfo.color)}>{statusInfo.label}</p>
            {dev.location && <p className="text-xs text-secondary">{dev.location}</p>}
          </div>
        </div>

        {/* Stats */}
        <div className="mb-5 grid grid-cols-3 gap-3">
          {[
            { label: "Rank",          value: `#${dev.rank}` },
            { label: "Contributions", value: String(dev.contributions ?? 0) },
            { label: "Rate",          value: dev.hourly_rate ? `$${dev.hourly_rate}/hr` : "—" },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-white/8 bg-white/3 p-3 text-center">
              <p className="text-lg font-black text-primary">{s.value}</p>
              <p className="text-[10px] text-secondary uppercase tracking-wider">{s.label}</p>
            </div>
          ))}
        </div>

        {dev.bio && <p className="mb-5 text-sm text-secondary leading-relaxed">{dev.bio}</p>}

        {/* Contribution heatmap */}
        <div className="mb-5">
          <ContributionHeatmap devId={dev.id} compact />
        </div>

        {Array.isArray(dev.skills) && dev.skills.length > 0 && (
          <div className="mb-5">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-secondary/60">Skills</p>
            <div className="flex flex-wrap gap-1.5">
              {dev.skills.map((s: string) => (
                <span key={s} className="rounded-full border border-primary/20 bg-primary/5 px-2.5 py-0.5 text-xs text-primary">{s}</span>
              ))}
            </div>
          </div>
        )}

        {Array.isArray(dev.experience) && dev.experience.length > 0 && (
          <div className="mb-5">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-secondary/60">Experience</p>
            {dev.experience.map((exp, i) => (
              <div key={i} className="mb-3 rounded-xl border border-white/8 bg-white/3 p-3">
                <p className="font-semibold text-white text-sm">{exp.role} @ {exp.company}</p>
                <p className="text-xs text-secondary">{exp.duration}</p>
                {exp.description && <p className="text-xs text-secondary/70 mt-1">{exp.description}</p>}
              </div>
            ))}
          </div>
        )}

        <div className="mb-6 flex flex-wrap gap-3">
          {dev.github_url && <a href={dev.github_url} target="_blank" rel="noopener noreferrer" className="text-xs text-secondary hover:text-white transition-colors border border-white/10 rounded-lg px-3 py-1.5">GitHub ↗</a>}
          {dev.linkedin_url && <a href={dev.linkedin_url} target="_blank" rel="noopener noreferrer" className="text-xs text-secondary hover:text-white transition-colors border border-white/10 rounded-lg px-3 py-1.5">LinkedIn ↗</a>}
          {dev.portfolio_url && <a href={dev.portfolio_url} target="_blank" rel="noopener noreferrer" className="text-xs text-secondary hover:text-white transition-colors border border-white/10 rounded-lg px-3 py-1.5">Portfolio ↗</a>}
        </div>

        {/* ── Connection actions ── */}
        {fs === "none" && (
          <button onClick={onSend} disabled={loading}
            className="w-full btn-glow rounded-2xl bg-primary py-3 font-bold text-black transition-all hover:-translate-y-0.5 disabled:opacity-40">
            {loading ? "Sending…" : "+ Send Connect Request"}
          </button>
        )}
        {fs === "pending_sent" && (
          <div className="rounded-2xl border border-white/8 bg-white/3 py-3 text-center text-sm font-semibold text-secondary">
            Request sent — waiting for response…
          </div>
        )}
        {fs === "pending_received" && (
          <div className="flex gap-3">
            <button onClick={onAccept} disabled={loading}
              className="flex-1 rounded-2xl bg-primary py-3 font-bold text-black disabled:opacity-40 hover:opacity-80 transition-opacity">
              {loading ? "…" : "✓ Accept Request"}
            </button>
            <button onClick={onDecline} disabled={loading}
              className="flex-1 rounded-2xl border border-red-500/30 bg-red-500/10 py-3 font-bold text-red-400 hover:bg-red-500/20 transition-colors disabled:opacity-40">
              {loading ? "…" : "✕ Decline"}
            </button>
          </div>
        )}
        {fs === "accepted" && (
          <button onClick={onMessage}
            className="w-full btn-glow rounded-2xl bg-primary py-3 font-bold text-black transition-all hover:-translate-y-0.5">
            💬 Send Message
          </button>
        )}
      </div>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
    </div>
  );
}
