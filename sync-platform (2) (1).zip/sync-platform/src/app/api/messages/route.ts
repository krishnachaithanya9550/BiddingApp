import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

// ─── GET /api/messages?with=userId — get DMs between two users ───────────────
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const withUser = req.nextUrl.searchParams.get("with");
  if (!withUser) return NextResponse.json({ error: "Missing ?with= param." }, { status: 400 });

  const db = getDb();
  const messages = db.prepare(`
    SELECT m.*, u.name as sender_name, u.avatar_color as sender_avatar_color
    FROM messages m
    JOIN users u ON u.id = m.sender_id
    WHERE m.group_id IS NULL
      AND (
        (m.sender_id = ? AND m.recipient_id = ?)
        OR (m.sender_id = ? AND m.recipient_id = ?)
      )
    ORDER BY m.created_at ASC
    LIMIT 200
  `).all(session.sub, withUser, withUser, session.sub);

  // Mark incoming messages in this conversation as read (best-effort — column may not exist yet)
  try {
    db.prepare(`
      UPDATE messages SET is_read = 1
      WHERE group_id IS NULL AND sender_id = ? AND recipient_id = ? AND is_read = 0
    `).run(withUser, session.sub);
  } catch { /* is_read column may not exist on older DB instances */ }

  return NextResponse.json({ messages });
}

// ─── POST /api/messages — send a DM ──────────────────────────────────────────
export async function POST(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const { recipient_id, content } = await req.json();
  if (!recipient_id || !content?.trim()) {
    return NextResponse.json({ error: "Missing fields." }, { status: 400 });
  }

  // Only allow messaging accepted friends
  const db = getDb();
  const friendship = db.prepare(`
    SELECT id FROM friendships
    WHERE status = 'accepted'
      AND ((requester_id = ? AND addressee_id = ?) OR (requester_id = ? AND addressee_id = ?))
  `).get(session.sub, recipient_id, recipient_id, session.sub);
  if (!friendship) return NextResponse.json({ error: "You are not friends with this user." }, { status: 403 });

  const id = crypto.randomUUID();
  db.prepare(
    "INSERT INTO messages (id, sender_id, recipient_id, content) VALUES (?, ?, ?, ?)"
  ).run(id, session.sub, recipient_id, content.trim());

  return NextResponse.json({ id, created_at: new Date().toISOString() }, { status: 201 });
}
