import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

// GET /api/messages/unread — returns count of unread DMs for the current user
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ count: 0 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ count: 0 });

  const db = getDb();
  const row = db.prepare(`
    SELECT COUNT(*) as count FROM messages
    WHERE recipient_id = ? AND is_read = 0 AND group_id IS NULL
  `).get(session.sub) as { count: number };

  return NextResponse.json({ count: row?.count ?? 0 });
}
