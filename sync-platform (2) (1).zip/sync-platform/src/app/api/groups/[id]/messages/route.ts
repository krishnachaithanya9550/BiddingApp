import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

type Params = { params: Promise<{ id: string }> };

// ─── GET /api/groups/[id]/messages — get group messages ──────────────────────
export async function GET(req: NextRequest, { params }: Params) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const { id } = await params;
  const db = getDb();

  const member = db.prepare("SELECT 1 FROM group_members WHERE group_id = ? AND user_id = ?").get(id, session.sub);
  if (!member) return NextResponse.json({ error: "Not a member of this group." }, { status: 403 });

  const messages = db.prepare(`
    SELECT m.*, u.name as sender_name, u.avatar_color as sender_avatar_color
    FROM messages m
    JOIN users u ON u.id = m.sender_id
    WHERE m.group_id = ?
    ORDER BY m.created_at ASC
    LIMIT 200
  `).all(id);

  return NextResponse.json({ messages });
}

// ─── POST /api/groups/[id]/messages — send a message to the group ────────────
export async function POST(req: NextRequest, { params }: Params) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const { id } = await params;
  const { content } = await req.json();
  if (!content?.trim()) return NextResponse.json({ error: "Empty message." }, { status: 400 });

  const db = getDb();
  const member = db.prepare("SELECT 1 FROM group_members WHERE group_id = ? AND user_id = ?").get(id, session.sub);
  if (!member) return NextResponse.json({ error: "Not a member." }, { status: 403 });

  const msgId = crypto.randomUUID();
  db.prepare(
    "INSERT INTO messages (id, sender_id, group_id, content) VALUES (?, ?, ?, ?)"
  ).run(msgId, session.sub, id, content.trim());

  return NextResponse.json({ id: msgId, created_at: new Date().toISOString() }, { status: 201 });
}
