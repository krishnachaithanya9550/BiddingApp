import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

// ─── GET /api/groups — list groups the user belongs to ────────────────────────
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const db = getDb();
  const groups = db.prepare(`
    SELECT g.*, 
      (SELECT COUNT(*) FROM group_members gm2 WHERE gm2.group_id = g.id) as member_count,
      (SELECT content FROM messages WHERE group_id = g.id ORDER BY created_at DESC LIMIT 1) as last_message
    FROM group_chats g
    JOIN group_members gm ON gm.group_id = g.id AND gm.user_id = ?
    ORDER BY g.created_at DESC
  `).all(session.sub);

  return NextResponse.json({ groups });
}

// ─── POST /api/groups — create a new group chat ────────────────────────────────
export async function POST(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const { name, member_ids, problem_id } = await req.json();
  if (!name?.trim() || !Array.isArray(member_ids)) {
    return NextResponse.json({ error: "Missing name or member_ids." }, { status: 400 });
  }

  const db = getDb();
  const groupId = crypto.randomUUID();
  db.prepare(
    "INSERT INTO group_chats (id, name, created_by, problem_id) VALUES (?, ?, ?, ?)"
  ).run(groupId, name.trim(), session.sub, problem_id ?? null);

  // Add creator + all invited members
  const allMembers = [...new Set([session.sub, ...member_ids])];
  const insertMember = db.prepare("INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?, ?)");
  for (const uid of allMembers) {
    insertMember.run(groupId, uid);
  }

  return NextResponse.json({ id: groupId, name: name.trim() }, { status: 201 });
}
