import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { getDb } from "@/lib/db";
import { signSession, COOKIE_NAME, MAX_AGE } from "@/lib/session";

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json({ error: "Missing email or password." }, { status: 400 });
    }

    const db = getDb();
    const user = db
      .prepare("SELECT id, name, email, password_hash, role, created_at FROM users WHERE email = ?")
      .get(email) as { id: string; name: string; email: string; password_hash: string; role: string; created_at: string } | undefined;

    if (!user) {
      return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
    }

    const { password_hash: _, ...profile } = user;
    const token = await signSession({ sub: user.id, name: user.name, email: user.email, role: user.role });

    const res = NextResponse.json({ profile });
    res.cookies.set(COOKIE_NAME, token, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: MAX_AGE,
    });
    return res;
  } catch (err) {
    console.error("[SYNC] login error:", err);
    return NextResponse.json({ error: "Login failed." }, { status: 500 });
  }
}
