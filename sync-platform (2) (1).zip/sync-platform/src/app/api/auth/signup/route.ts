import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { getDb } from "@/lib/db";
import { signSession, COOKIE_NAME, MAX_AGE } from "@/lib/session";

export async function POST(req: NextRequest) {
  try {
    const { name, email, password, role } = await req.json();

    if (!name || !email || !password || !role) {
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }

    // Only "user" or "company" can self-register — "0" (admin) is DB-only
    if (role !== "user" && role !== "company") {
      return NextResponse.json({ error: "Invalid role." }, { status: 400 });
    }

    if (password.length < 6) {
      return NextResponse.json({ error: "Password must be at least 6 characters." }, { status: 400 });
    }

    const db = getDb();

    const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
    if (existing) {
      return NextResponse.json(
        { error: "An account with that email already exists." },
        { status: 409 }
      );
    }

    const id = crypto.randomUUID();
    const password_hash = await bcrypt.hash(password, 12);
    const created_at = new Date().toISOString();

    db.prepare(
      "INSERT INTO users (id, name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?, ?)"
    ).run(id, name, email, password_hash, role, created_at);

    const token = await signSession({ sub: id, name, email, role });
    const profile = { id, name, email, role, created_at };

    const res = NextResponse.json({ profile }, { status: 201 });
    res.cookies.set(COOKIE_NAME, token, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: MAX_AGE,
    });
    return res;
  } catch (err) {
    console.error("[SYNC] signup error:", err);
    return NextResponse.json({ error: "Failed to create account." }, { status: 500 });
  }
}
