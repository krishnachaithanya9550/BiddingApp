import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

// GET /api/profile/heatmap?id=USER_ID
// Returns daily submission counts for the past 365 days for any developer.
// If no id is provided, defaults to the logged-in user.
// Any authenticated user can view any developer's heatmap.
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const targetId = searchParams.get("id") ?? session.sub;

  const db = getDb();

  // Count submissions grouped by day for the past 365 days
  const rows = db
    .prepare(`
      SELECT date(created_at) AS day, COUNT(*) AS count
      FROM submissions
      WHERE developer_id = ?
        AND created_at >= date('now', '-364 days')
      GROUP BY day
      ORDER BY day ASC
    `)
    .all(targetId) as { day: string; count: number }[];

  const total = rows.reduce((s, r) => s + r.count, 0);

  return NextResponse.json({ heatmap: rows, total });
}
