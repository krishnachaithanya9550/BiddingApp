import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

// ─── GET /api/profile — get current user's full profile ──────────────────────
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const db = getDb();
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(session.sub) as Record<string, unknown> | undefined;
  if (!user) return NextResponse.json({ error: "User not found." }, { status: 404 });

  // Parse JSON fields; never expose password hash
  const { password_hash: _, ...rest } = user as { password_hash: string } & Record<string, unknown>;
  const profile = {
    ...rest,
    skills:     safeParseJson(rest.skills as string, []),
    experience: safeParseJson(rest.experience as string, []),
  };

  return NextResponse.json({ profile });
}

// ─── PATCH /api/profile — update current user's profile ──────────────────────
export async function PATCH(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const body = await req.json();
  const allowed = ["name", "bio", "skills", "experience", "github_url", "linkedin_url",
                   "portfolio_url", "location", "hourly_rate", "working_status", "avatar_color"];

  const fields: string[] = [];
  const values: unknown[] = [];

  for (const key of allowed) {
    if (key in body) {
      fields.push(`${key} = ?`);
      values.push(
        (key === "skills" || key === "experience") && Array.isArray(body[key])
          ? JSON.stringify(body[key])
          : body[key]
      );
    }
  }

  if (!fields.length) return NextResponse.json({ error: "Nothing to update." }, { status: 400 });

  values.push(session.sub);
  getDb().prepare(`UPDATE users SET ${fields.join(", ")} WHERE id = ?`).run(...values);
  return NextResponse.json({ success: true });
}

function safeParseJson(val: string, fallback: unknown) {
  try { return JSON.parse(val); } catch { return fallback; }
}
