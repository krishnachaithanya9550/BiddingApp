import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

type Params = { params: Promise<{ id: string }> };

// ─── PATCH /api/friendships/[id] — accept or decline a request ───────────────
export async function PATCH(req: NextRequest, { params }: Params) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const { id } = await params;
  const { status } = await req.json();
  if (!["accepted", "declined"].includes(status)) {
    return NextResponse.json({ error: "Invalid status." }, { status: 400 });
  }

  const db = getDb();
  const row = db.prepare("SELECT * FROM friendships WHERE id = ?").get(id) as { addressee_id: string } | undefined;
  if (!row) return NextResponse.json({ error: "Not found." }, { status: 404 });
  if (row.addressee_id !== session.sub) return NextResponse.json({ error: "Forbidden." }, { status: 403 });

  db.prepare("UPDATE friendships SET status = ? WHERE id = ?").run(status, id);
  return NextResponse.json({ success: true });
}

// ─── DELETE /api/friendships/[id] — remove a friendship / cancel request ─────
export async function DELETE(req: NextRequest, { params }: Params) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const { id } = await params;
  const db = getDb();
  const row = db.prepare("SELECT * FROM friendships WHERE id = ?").get(id) as { requester_id: string; addressee_id: string } | undefined;
  if (!row) return NextResponse.json({ error: "Not found." }, { status: 404 });
  if (row.requester_id !== session.sub && row.addressee_id !== session.sub) {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  db.prepare("DELETE FROM friendships WHERE id = ?").run(id);
  return NextResponse.json({ success: true });
}
