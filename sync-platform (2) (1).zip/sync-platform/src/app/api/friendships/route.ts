import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

// ─── GET /api/friendships — list friendships for current user ─────────────────
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const db = getDb();
  const rows = db.prepare(`
    SELECT f.*, 
      CASE WHEN f.requester_id = ? THEN u2.name ELSE u1.name END as other_name,
      CASE WHEN f.requester_id = ? THEN u2.email ELSE u1.email END as other_email,
      CASE WHEN f.requester_id = ? THEN u2.id ELSE u1.id END as other_id,
      CASE WHEN f.requester_id = ? THEN u2.role ELSE u1.role END as other_role,
      CASE WHEN f.requester_id = ? THEN u2.avatar_color ELSE u1.avatar_color END as other_avatar_color
    FROM friendships f
    JOIN users u1 ON u1.id = f.requester_id
    JOIN users u2 ON u2.id = f.addressee_id
    WHERE f.requester_id = ? OR f.addressee_id = ?
    ORDER BY f.created_at DESC
  `).all(
    session.sub, session.sub, session.sub, session.sub, session.sub,
    session.sub, session.sub
  );

  return NextResponse.json({ friendships: rows });
}

// ─── POST /api/friendships — send a friend request ────────────────────────────
export async function POST(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const { addressee_id } = await req.json();
  if (!addressee_id) return NextResponse.json({ error: "Missing addressee_id." }, { status: 400 });
  if (addressee_id === session.sub) return NextResponse.json({ error: "Cannot add yourself." }, { status: 400 });

  const db = getDb();
  const target = db.prepare("SELECT id FROM users WHERE id = ?").get(addressee_id);
  if (!target) return NextResponse.json({ error: "User not found." }, { status: 404 });

  try {
    const id = crypto.randomUUID();
    db.prepare(
      "INSERT INTO friendships (id, requester_id, addressee_id, status) VALUES (?, ?, ?, 'pending')"
    ).run(id, session.sub, addressee_id);
    return NextResponse.json({ id, status: "pending" }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Request already sent." }, { status: 409 });
  }
}
