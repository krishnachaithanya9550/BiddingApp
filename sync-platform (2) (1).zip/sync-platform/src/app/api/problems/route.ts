import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";
import type { Problem } from "@/types";

// ─── GET /api/problems — list all open problems ────────────────────────────────
export async function GET() {
  const db = getDb();
  const rows = db
    .prepare("SELECT * FROM problems WHERE status = 'open' ORDER BY created_at DESC")
    .all() as (Omit<Problem, "skills"> & { skills: string })[];

  const problems: Problem[] = rows.map((r) => ({
    ...r,
    skills: JSON.parse(r.skills),
  }));

  return NextResponse.json({ problems });
}

// ─── POST /api/problems — create a new problem (business only) ────────────────
export async function POST(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  if (session.role !== "company" && session.role !== "0") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  try {
    const { title, description, budget, deadline, skills } = await req.json();

    if (!title || !description || budget == null || !deadline) {
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }

    const db = getDb();
    const id = crypto.randomUUID();
    const created_at = new Date().toISOString();
    const skillsJson = JSON.stringify(Array.isArray(skills) ? skills : []);

    db.prepare(
      "INSERT INTO problems (id, company_id, title, description, budget, deadline, skills, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?)"
    ).run(id, session.sub, title, description, budget, deadline, skillsJson, created_at);

    const problem: Problem = {
      id,
      company_id: session.sub,
      title,
      description,
      budget,
      deadline,
      skills: Array.isArray(skills) ? skills : [],
      status: "open",
      created_at,
    };

    return NextResponse.json({ problem }, { status: 201 });
  } catch (err) {
    console.error("[SYNC] post problem error:", err);
    return NextResponse.json({ error: "Failed to post problem." }, { status: 500 });
  }
}
