import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";
import type { Problem } from "@/types";

// ─── GET /api/problems/company — problems posted by the current user ───────────
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const db = getDb();
  const rows = db
    .prepare("SELECT * FROM problems WHERE company_id = ? ORDER BY created_at DESC")
    .all(session.sub) as (Omit<Problem, "skills"> & { skills: string })[];

  const problems: Problem[] = rows.map((r) => ({ ...r, skills: JSON.parse(r.skills) }));
  return NextResponse.json({ problems });
}
