import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";
import type { Problem } from "@/types";

type Params = { params: Promise<{ id: string }> };

// ─── GET /api/problems/[id] ────────────────────────────────────────────────────
export async function GET(_req: NextRequest, { params }: Params) {
  const { id } = await params;
  const db = getDb();
  const row = db
    .prepare("SELECT * FROM problems WHERE id = ?")
    .get(id) as (Omit<Problem, "skills"> & { skills: string }) | undefined;

  if (!row) return NextResponse.json({ error: "Problem not found." }, { status: 404 });

  const problem: Problem = { ...row, skills: JSON.parse(row.skills) };
  return NextResponse.json({ problem });
}

// ─── PATCH /api/problems/[id] — update status (business/admin only) ───────────
export async function PATCH(req: NextRequest, { params }: Params) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const { id } = await params;
  const { status } = await req.json();

  const validStatuses = ["open", "closed", "in_review"];
  if (!validStatuses.includes(status)) {
    return NextResponse.json({ error: "Invalid status." }, { status: 400 });
  }

  const db = getDb();
  const problem = db
    .prepare("SELECT company_id FROM problems WHERE id = ?")
    .get(id) as { company_id: string } | undefined;

  if (!problem) return NextResponse.json({ error: "Problem not found." }, { status: 404 });

  if (session.role !== "0" && problem.company_id !== session.sub) {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  db.prepare("UPDATE problems SET status = ? WHERE id = ?").run(status, id);
  return NextResponse.json({ success: true });
}
