import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

async function getSession(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySession(token);
}

// PATCH /api/marketplace/[id] — edit own listing
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const { id } = await params;
  const db = getDb();
  const listing = db.prepare("SELECT seller_id FROM marketplace_listings WHERE id = ?").get(id) as { seller_id: string } | undefined;
  if (!listing) return NextResponse.json({ error: "Listing not found." }, { status: 404 });

  const isOwner = listing.seller_id === session.sub;
  const isAdmin = session.role === "0";
  if (!isOwner && !isAdmin) return NextResponse.json({ error: "Forbidden." }, { status: 403 });

  const body = await req.json();
  const { title, description, category, tags, price, demo_url, repo_url, status } = body;

  if (title !== undefined)       db.prepare("UPDATE marketplace_listings SET title = ? WHERE id = ?").run(title.trim(), id);
  if (description !== undefined) db.prepare("UPDATE marketplace_listings SET description = ? WHERE id = ?").run(description.trim(), id);
  if (category !== undefined)    db.prepare("UPDATE marketplace_listings SET category = ? WHERE id = ?").run(category.trim(), id);
  if (tags !== undefined)        db.prepare("UPDATE marketplace_listings SET tags = ? WHERE id = ?").run(
    typeof tags === "string" ? tags : JSON.stringify(Array.isArray(tags) ? tags : []), id
  );
  if (price !== undefined)       db.prepare("UPDATE marketplace_listings SET price = ? WHERE id = ?").run(Number(price), id);
  if (demo_url !== undefined)    db.prepare("UPDATE marketplace_listings SET demo_url = ? WHERE id = ?").run(demo_url.trim(), id);
  if (repo_url !== undefined)    db.prepare("UPDATE marketplace_listings SET repo_url = ? WHERE id = ?").run(repo_url.trim(), id);
  if (status !== undefined && ["active", "draft", "paused"].includes(status))
    db.prepare("UPDATE marketplace_listings SET status = ? WHERE id = ?").run(status, id);

  return NextResponse.json({ success: true });
}

// DELETE /api/marketplace/[id] — delete own listing or admin can delete any
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const { id } = await params;
  const db = getDb();
  const listing = db.prepare("SELECT seller_id FROM marketplace_listings WHERE id = ?").get(id) as { seller_id: string } | undefined;
  if (!listing) return NextResponse.json({ error: "Listing not found." }, { status: 404 });

  const isOwner = listing.seller_id === session.sub;
  const isAdmin = session.role === "0";
  if (!isOwner && !isAdmin) return NextResponse.json({ error: "Forbidden." }, { status: 403 });

  db.prepare("DELETE FROM marketplace_listings WHERE id = ?").run(id);
  return NextResponse.json({ success: true });
}
