import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";
import { randomUUID } from "crypto";

function getSession(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySession(token);
}

// GET /api/marketplace — browse all active listings with seller info, cart & purchase status
export async function GET(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const db = getDb();
  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category") ?? "";
  const search   = searchParams.get("q") ?? "";

  let query = `
    SELECT
      l.*,
      u.name  AS seller_name,
      u.avatar_color AS seller_avatar_color,
      u.role  AS seller_role,
      (SELECT COUNT(*) FROM purchases p WHERE p.listing_id = l.id) AS purchase_count,
      (SELECT id FROM cart_items ci WHERE ci.listing_id = l.id AND ci.user_id = ?) AS cart_item_id,
      (SELECT id FROM purchases pu WHERE pu.listing_id = l.id AND pu.buyer_id = ?) AS purchase_id
    FROM marketplace_listings l
    JOIN users u ON u.id = l.seller_id
    WHERE l.status = 'active'
  `;
  const params: (string | number)[] = [session.sub, session.sub];

  if (category) { query += " AND l.category = ?"; params.push(category); }
  if (search)   { query += " AND (lower(l.title) LIKE ? OR lower(l.description) LIKE ?)"; params.push(`%${search.toLowerCase()}%`, `%${search.toLowerCase()}%`); }

  query += " ORDER BY l.created_at DESC";

  const rows = db.prepare(query).all(...params) as Record<string, unknown>[];
  const listings = rows.map((r) => ({
    ...r,
    tags:      safeJson(r.tags as string, []),
    in_cart:   !!r.cart_item_id,
    purchased: !!r.purchase_id,
  }));

  return NextResponse.json({ listings });
}

// POST /api/marketplace — create a listing (developer only)
export async function POST(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  if (session.role !== "user") return NextResponse.json({ error: "Only developers can list products." }, { status: 403 });

  const body = await req.json();
  const { title, description, category, tags, price, demo_url, repo_url, status } = body;

  if (!title?.trim())       return NextResponse.json({ error: "Title is required." }, { status: 400 });
  if (!description?.trim()) return NextResponse.json({ error: "Description is required." }, { status: 400 });
  if (price === undefined || price < 0) return NextResponse.json({ error: "Price must be >= 0." }, { status: 400 });

  const safeStatus = ["active", "draft", "paused"].includes(status) ? status : "active";
  const db = getDb();
  const id = randomUUID();

  db.prepare(`
    INSERT INTO marketplace_listings (id, seller_id, title, description, category, tags, price, demo_url, repo_url, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, session.sub,
    title.trim(), description.trim(),
    category?.trim() || "automation",
    typeof tags === "string" ? tags : JSON.stringify(Array.isArray(tags) ? tags : []),
    Number(price),
    demo_url?.trim() ?? "",
    repo_url?.trim() ?? "",
    safeStatus,
  );

  return NextResponse.json({ success: true, id }, { status: 201 });
}

function safeJson(val: string, fallback: unknown) {
  try { return JSON.parse(val); } catch { return fallback; }
}
