import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

function safeJson(v: unknown, fallback: unknown) {
  try { return JSON.parse(v as string); } catch { return fallback; }
}

function getSession(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySession(token);
}

// GET /api/marketplace/mine — developer's own listings with purchase counts
export async function GET(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  if (session.role !== "user") return NextResponse.json({ error: "Developers only." }, { status: 403 });

  const db = getDb();

  const rows = db.prepare(`
    SELECT
      l.*,
      (SELECT COUNT(*) FROM purchases p WHERE p.listing_id = l.id) AS purchase_count
    FROM marketplace_listings l
    WHERE l.seller_id = ?
    ORDER BY l.created_at DESC
  `).all(session.sub) as Record<string, unknown>[];

  const listings = rows.map((r) => ({
    ...r,
    tags: safeJson(r.tags, []),
  }));

  return NextResponse.json({ listings });
}
