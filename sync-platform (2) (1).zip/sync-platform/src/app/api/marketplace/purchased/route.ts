import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

function safeJson(v: unknown, fallback: unknown) {
  try { return JSON.parse(v as string); } catch { return fallback; }
}

function getSession(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySession(token);
}

// GET /api/marketplace/purchased — items the current user has already purchased
export async function GET(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const db = getDb();

  const rows = db.prepare(`
    SELECT
      pu.id,
      pu.price_paid,
      pu.purchased_at,
      l.title,
      l.description,
      l.category,
      l.tags,
      l.demo_url,
      l.repo_url,
      u.name AS seller_name
    FROM purchases pu
    JOIN marketplace_listings l ON l.id = pu.listing_id
    JOIN users u ON u.id = l.seller_id
    WHERE pu.buyer_id = ?
    ORDER BY pu.purchased_at DESC
  `).all(session.sub) as Record<string, unknown>[];

  const purchases = rows.map((r) => ({
    ...r,
    tags: safeJson(r.tags, []),
  }));

  return NextResponse.json({ purchases });
}
