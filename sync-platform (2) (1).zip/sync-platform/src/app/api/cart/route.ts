import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";
import { randomUUID } from "crypto";

async function getSession(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySession(token);
}

// GET /api/cart — get the logged-in user's cart with full listing details
export async function GET(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const db = getDb();
  const items = db.prepare(`
    SELECT
      ci.id AS cart_item_id,
      ci.added_at,
      l.id, l.title, l.description, l.category, l.tags,
      l.price, l.demo_url, l.status,
      u.name AS seller_name,
      u.avatar_color AS seller_avatar_color
    FROM cart_items ci
    JOIN marketplace_listings l ON l.id = ci.listing_id
    JOIN users u ON u.id = l.seller_id
    WHERE ci.user_id = ?
    ORDER BY ci.added_at DESC
  `).all(session.sub) as Record<string, unknown>[];

  const cart = items.map((r) => ({
    ...r,
    tags: safeJson(r.tags as string, []),
  }));

  const total = cart.reduce((s, item) => s + (item.price as number), 0);
  return NextResponse.json({ cart, total, count: cart.length });
}

// POST /api/cart — add item to cart
export async function POST(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const { listing_id } = await req.json();
  if (!listing_id) return NextResponse.json({ error: "Missing listing_id." }, { status: 400 });

  const db = getDb();
  const listing = db.prepare("SELECT id, seller_id, status FROM marketplace_listings WHERE id = ?").get(listing_id) as { id: string; seller_id: string; status: string } | undefined;
  if (!listing) return NextResponse.json({ error: "Listing not found." }, { status: 404 });
  if (listing.status !== "active") return NextResponse.json({ error: "Listing is not available." }, { status: 400 });
  if (listing.seller_id === session.sub) return NextResponse.json({ error: "You cannot buy your own product." }, { status: 400 });

  // Check already purchased
  const already = db.prepare("SELECT id FROM purchases WHERE buyer_id = ? AND listing_id = ?").get(session.sub, listing_id);
  if (already) return NextResponse.json({ error: "Already purchased." }, { status: 400 });

  try {
    db.prepare("INSERT INTO cart_items (id, user_id, listing_id) VALUES (?, ?, ?)").run(randomUUID(), session.sub, listing_id);
  } catch {
    return NextResponse.json({ error: "Already in cart." }, { status: 400 });
  }

  return NextResponse.json({ success: true });
}

// DELETE /api/cart — remove an item from cart
export async function DELETE(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const { listing_id } = await req.json();
  if (!listing_id) return NextResponse.json({ error: "Missing listing_id." }, { status: 400 });

  const db = getDb();
  db.prepare("DELETE FROM cart_items WHERE user_id = ? AND listing_id = ?").run(session.sub, listing_id);
  return NextResponse.json({ success: true });
}

// PATCH /api/cart — checkout: convert all cart items to purchases
export async function PATCH(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const db = getDb();
  const cartItems = db.prepare(`
    SELECT ci.listing_id, l.price
    FROM cart_items ci
    JOIN marketplace_listings l ON l.id = ci.listing_id
    WHERE ci.user_id = ?
  `).all(session.sub) as { listing_id: string; price: number }[];

  if (cartItems.length === 0) return NextResponse.json({ error: "Cart is empty." }, { status: 400 });

  const insertPurchase = db.prepare(
    "INSERT OR IGNORE INTO purchases (id, buyer_id, listing_id, price_paid) VALUES (?, ?, ?, ?)"
  );
  const deleteCart = db.prepare("DELETE FROM cart_items WHERE user_id = ? AND listing_id = ?");

  const checkout = db.transaction(() => {
    for (const item of cartItems) {
      insertPurchase.run(randomUUID(), session.sub, item.listing_id, item.price);
      deleteCart.run(session.sub, item.listing_id);
    }
  });
  checkout();

  return NextResponse.json({ success: true, purchased: cartItems.length });
}

function safeJson(val: string, fallback: unknown) {
  try { return JSON.parse(val); } catch { return fallback; }
}
