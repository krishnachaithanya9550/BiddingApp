import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";
import type { Submission } from "@/types";

function safeParseJson(val: unknown, fallback: unknown) {
  try { return JSON.parse(val as string); } catch { return fallback; }
}

function hydrateRows(rows: Record<string, unknown>[]) {
  return rows.map((r) => ({
    ...r,
    tech_stack: safeParseJson(r.tech_stack, []),
    developer_skills: safeParseJson(r.developer_skills, []),
  }));
}

// ─── GET /api/submissions — company views submissions for their problems ───────
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const db = getDb();

  if (session.role === "user") {
    // Regular user sees their own submissions
    const rows = db
      .prepare(`
        SELECT s.*, p.title as problem_title
        FROM submissions s
        JOIN problems p ON p.id = s.problem_id
        WHERE s.developer_id = ?
        ORDER BY s.created_at DESC
      `)
      .all(session.sub) as Record<string, unknown>[];
    return NextResponse.json({ submissions: hydrateRows(rows) });
  }

  // Business or admin — see all submissions for their problems
  if (session.role === "0") {
    const rows = db
      .prepare(`
        SELECT s.*,
          p.title as problem_title,
          u.name as developer_name, u.email as developer_email,
          u.bio as developer_bio, u.skills as developer_skills,
          u.github_url as developer_github, u.linkedin_url as developer_linkedin,
          u.portfolio_url as developer_portfolio,
          u.working_status as developer_working_status,
          u.contributions as developer_contributions,
          u.avatar_color as developer_avatar_color,
          (SELECT COUNT(*) FROM submissions s2 WHERE s2.developer_id = u.id AND s2.status='accepted') as accepted_count
        FROM submissions s
        JOIN problems p ON p.id = s.problem_id
        JOIN users u ON u.id = s.developer_id
        ORDER BY s.created_at DESC
      `)
      .all() as Record<string, unknown>[];
    return NextResponse.json({ submissions: hydrateRows(rows) });
  }

  const rows = db
    .prepare(`
      SELECT s.*,
        p.title as problem_title,
        u.name as developer_name, u.email as developer_email,
        u.bio as developer_bio, u.skills as developer_skills,
        u.github_url as developer_github, u.linkedin_url as developer_linkedin,
        u.portfolio_url as developer_portfolio,
        u.working_status as developer_working_status,
        u.contributions as developer_contributions,
        u.avatar_color as developer_avatar_color,
        (SELECT COUNT(*) FROM submissions s2 WHERE s2.developer_id = u.id AND s2.status='accepted') as accepted_count
      FROM submissions s
      JOIN problems p ON p.id = s.problem_id
      JOIN users u ON u.id = s.developer_id
      WHERE p.company_id = ?
      ORDER BY s.created_at DESC
    `)
    .all(session.sub) as Record<string, unknown>[];

  return NextResponse.json({ submissions: hydrateRows(rows) });
}

// ─── POST /api/submissions — developer submits a proposal ─────────────────────
export async function POST(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  if (session.role !== "user" && session.role !== "0") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  try {
    const { problem_id, proposal, solution_notes, tech_stack, repo_url, demo_url, estimated_hours } = await req.json();

    if (!problem_id || !proposal) {
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }

    const db = getDb();
    const id = crypto.randomUUID();
    const created_at = new Date().toISOString();

    db.prepare(
      `INSERT INTO submissions (id, problem_id, developer_id, proposal, solution_notes, tech_stack, repo_url, demo_url, estimated_hours, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`
    ).run(
      id, problem_id, session.sub, proposal,
      solution_notes ?? "", JSON.stringify(tech_stack ?? []),
      repo_url ?? "", demo_url ?? "", estimated_hours ?? 0,
      created_at
    );

    // Increment contributions count
    db.prepare("UPDATE users SET contributions = contributions + 1 WHERE id = ?").run(session.sub);

    const submission: Submission = {
      id, problem_id, developer_id: session.sub, proposal,
      solution_notes, tech_stack, repo_url, demo_url, estimated_hours,
      status: "pending", created_at,
    };

    return NextResponse.json({ submission }, { status: 201 });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes("UNIQUE constraint")) {
      return NextResponse.json({ error: "You have already submitted for this problem." }, { status: 409 });
    }
    console.error("[SYNC] submission error:", err);
    return NextResponse.json({ error: "Failed to submit proposal." }, { status: 500 });
  }
}
