import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

type Params = { params: Promise<{ id: string }> };

// ─── PATCH /api/submissions/[id] — accept or reject a submission ──────────────
export async function PATCH(req: NextRequest, { params }: Params) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const session = await verifySession(token);
  if (!session) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const { id } = await params;
  const { status } = await req.json();

  const validStatuses = ["pending", "accepted", "rejected"];
  if (!validStatuses.includes(status)) {
    return NextResponse.json({ error: "Invalid status." }, { status: 400 });
  }

  const db = getDb();

  // Verify the submission exists and the caller owns the problem
  const row = db
    .prepare(`
      SELECT s.id, p.company_id
      FROM submissions s
      JOIN problems p ON p.id = s.problem_id
      WHERE s.id = ?
    `)
    .get(id) as { id: string; company_id: string } | undefined;

  if (!row) return NextResponse.json({ error: "Submission not found." }, { status: 404 });

  if (session.role !== "0" && row.company_id !== session.sub) {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  db.prepare("UPDATE submissions SET status = ? WHERE id = ?").run(status, id);
  return NextResponse.json({ success: true });
}
