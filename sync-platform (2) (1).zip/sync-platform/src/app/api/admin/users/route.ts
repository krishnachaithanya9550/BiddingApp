import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";
import bcrypt from "bcryptjs";
import { randomUUID } from "crypto";

async function requireAdmin(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const session = await verifySession(token);
  if (!session || session.role !== "0") return null;
  return session;
}

export async function GET(req: NextRequest) {
  const session = await requireAdmin(req);
  if (!session) return NextResponse.json({ error: "Forbidden." }, { status: 403 });

  const db = getDb();

  const users = db
    .prepare("SELECT id, name, email, role, created_at, contributions, working_status FROM users ORDER BY created_at DESC")
    .all();

  // Platform totals
  const problems    = db.prepare("SELECT COUNT(*) as c FROM problems").get() as { c: number };
  const openProbs   = db.prepare("SELECT COUNT(*) as c FROM problems WHERE status = 'open'").get() as { c: number };
  const submissions = db.prepare("SELECT COUNT(*) as c FROM submissions").get() as { c: number };
  const accepted    = db.prepare("SELECT COUNT(*) as c FROM submissions WHERE status = 'accepted'").get() as { c: number };
  const pending     = db.prepare("SELECT COUNT(*) as c FROM submissions WHERE status = 'pending'").get() as { c: number };
  const messages    = db.prepare("SELECT COUNT(*) as c FROM messages").get() as { c: number };
  const friendships = db.prepare("SELECT COUNT(*) as c FROM friendships WHERE status = 'accepted'").get() as { c: number };
  const groups      = db.prepare("SELECT COUNT(*) as c FROM group_chats").get() as { c: number };

  // Signups per day for last 14 days
  const signupTrend = db.prepare(`
    SELECT date(created_at) as day, COUNT(*) as count
    FROM users
    WHERE created_at >= date('now', '-13 days')
    GROUP BY day ORDER BY day ASC
  `).all() as { day: string; count: number }[];

  // Submissions per day for last 14 days
  const submissionTrend = db.prepare(`
    SELECT date(created_at) as day, COUNT(*) as count
    FROM submissions
    WHERE created_at >= date('now', '-13 days')
    GROUP BY day ORDER BY day ASC
  `).all() as { day: string; count: number }[];

  // Top 5 contributors
  const topDevs = db.prepare(`
    SELECT name, contributions, avatar_color
    FROM users WHERE role = 'user'
    ORDER BY contributions DESC LIMIT 5
  `).all() as { name: string; contributions: number; avatar_color: string }[];

  // Problems by status breakdown
  const problemsByStatus = db.prepare(`
    SELECT status, COUNT(*) as count FROM problems GROUP BY status
  `).all() as { status: string; count: number }[];

  // Submission status breakdown
  const subsByStatus = db.prepare(`
    SELECT status, COUNT(*) as count FROM submissions GROUP BY status
  `).all() as { status: string; count: number }[];

  // Working status breakdown for devs
  const devsByStatus = db.prepare(`
    SELECT working_status, COUNT(*) as count FROM users WHERE role='user' GROUP BY working_status
  `).all() as { working_status: string; count: number }[];

  return NextResponse.json({
    users,
    stats: {
      problems: problems.c,
      open_problems: openProbs.c,
      submissions: submissions.c,
      accepted_submissions: accepted.c,
      pending_submissions: pending.c,
      messages: messages.c,
      friendships: friendships.c,
      groups: groups.c,
    },
    charts: {
      signupTrend,
      submissionTrend,
      topDevs,
      problemsByStatus,
      subsByStatus,
      devsByStatus,
    },
  });
}

// POST /api/admin/users — create a new user
export async function POST(req: NextRequest) {
  const session = await requireAdmin(req);
  if (!session) return NextResponse.json({ error: "Forbidden." }, { status: 403 });

  const { name, email, password, role } = await req.json();
  if (!name || !email || !password) return NextResponse.json({ error: "Name, email and password are required." }, { status: 400 });
  const safeRole = ["0", "user", "company"].includes(role) ? role : "user";

  const db = getDb();
  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (existing) return NextResponse.json({ error: "Email already in use." }, { status: 409 });

  const id            = randomUUID();
  const password_hash = await bcrypt.hash(password, 12);
  const created_at    = new Date().toISOString();
  db.prepare("INSERT INTO users (id, name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?, ?)").run(id, name, email, password_hash, safeRole, created_at);

  return NextResponse.json({ success: true, id });
}

// PATCH /api/admin/users — edit user (name, email, role, password)
export async function PATCH(req: NextRequest) {
  const session = await requireAdmin(req);
  if (!session) return NextResponse.json({ error: "Forbidden." }, { status: 403 });

  const { id, role, name, email, password } = await req.json();
  if (!id) return NextResponse.json({ error: "Missing id." }, { status: 400 });

  const db = getDb();
  const user = db.prepare("SELECT id, role FROM users WHERE id = ?").get(id) as { id: string; role: string } | undefined;
  if (!user) return NextResponse.json({ error: "User not found." }, { status: 404 });

  // Role change
  if (role !== undefined) {
    if (!["0", "user", "company"].includes(role)) return NextResponse.json({ error: "Invalid role." }, { status: 400 });
    if (id === session.sub && role !== "0") return NextResponse.json({ error: "Cannot demote yourself." }, { status: 403 });
    db.prepare("UPDATE users SET role = ? WHERE id = ?").run(role, id);
  }

  // Name update
  if (name !== undefined) {
    if (!name.trim()) return NextResponse.json({ error: "Name cannot be empty." }, { status: 400 });
    db.prepare("UPDATE users SET name = ? WHERE id = ?").run(name.trim(), id);
  }

  // Email update
  if (email !== undefined) {
    if (!email.trim()) return NextResponse.json({ error: "Email cannot be empty." }, { status: 400 });
    const conflict = db.prepare("SELECT id FROM users WHERE email = ? AND id != ?").get(email.trim(), id);
    if (conflict) return NextResponse.json({ error: "Email already in use." }, { status: 409 });
    db.prepare("UPDATE users SET email = ? WHERE id = ?").run(email.trim(), id);
  }

  // Password reset
  if (password !== undefined) {
    if (password.length < 6) return NextResponse.json({ error: "Password must be at least 6 characters." }, { status: 400 });
    const hash = await bcrypt.hash(password, 12);
    db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, id);
  }

  return NextResponse.json({ success: true });
}

// DELETE /api/admin/users — delete a user
export async function DELETE(req: NextRequest) {
  const session = await requireAdmin(req);
  if (!session) return NextResponse.json({ error: "Forbidden." }, { status: 403 });

  const { id } = await req.json();
  if (!id) return NextResponse.json({ error: "Missing id." }, { status: 400 });
  if (id === session.sub) return NextResponse.json({ error: "Cannot delete your own account." }, { status: 403 });

  const db = getDb();
  const result = db.prepare("DELETE FROM users WHERE id = ?").run(id);
  if (result.changes === 0) return NextResponse.json({ error: "User not found." }, { status: 404 });

  return NextResponse.json({ success: true });
}
