import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { getDb } from "@/lib/db";

async function requireAdmin(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const session = await verifySession(token);
  if (!session || session.role !== "0") return null;
  return session;
}

// GET /api/admin/problems — list all problems with company info
export async function GET(req: NextRequest) {
  const session = await requireAdmin(req);
  if (!session) return NextResponse.json({ error: "Forbidden." }, { status: 403 });

  const db = getDb();
  const problems = db.prepare(`
    SELECT
      p.id, p.title, p.description, p.budget, p.deadline,
      p.skills, p.status, p.created_at,
      u.id   AS company_id,
      u.name AS company_name,
      u.email AS company_email,
      (SELECT COUNT(*) FROM submissions s WHERE s.problem_id = p.id) AS submission_count
    FROM problems p
    JOIN users u ON u.id = p.company_id
    ORDER BY p.created_at DESC
  `).all();

  return NextResponse.json({ problems });
}

// PATCH /api/admin/problems — edit a problem
export async function PATCH(req: NextRequest) {
  const session = await requireAdmin(req);
  if (!session) return NextResponse.json({ error: "Forbidden." }, { status: 403 });

  const { id, title, description, budget, deadline, skills, status } = await req.json();
  if (!id) return NextResponse.json({ error: "Missing id." }, { status: 400 });

  const db = getDb();
  const problem = db.prepare("SELECT id FROM problems WHERE id = ?").get(id);
  if (!problem) return NextResponse.json({ error: "Problem not found." }, { status: 404 });

  if (title !== undefined)       db.prepare("UPDATE problems SET title = ? WHERE id = ?").run(title, id);
  if (description !== undefined) db.prepare("UPDATE problems SET description = ? WHERE id = ?").run(description, id);
  if (budget !== undefined)      db.prepare("UPDATE problems SET budget = ? WHERE id = ?").run(Number(budget), id);
  if (deadline !== undefined)    db.prepare("UPDATE problems SET deadline = ? WHERE id = ?").run(deadline, id);
  if (skills !== undefined)      db.prepare("UPDATE problems SET skills = ? WHERE id = ?").run(
    typeof skills === "string" ? skills : JSON.stringify(skills), id
  );
  if (status !== undefined) {
    if (!["open", "closed", "in_review"].includes(status))
      return NextResponse.json({ error: "Invalid status." }, { status: 400 });
    db.prepare("UPDATE problems SET status = ? WHERE id = ?").run(status, id);
  }

  return NextResponse.json({ success: true });
}

// DELETE /api/admin/problems — delete a problem (cascades to submissions)
export async function DELETE(req: NextRequest) {
  const session = await requireAdmin(req);
  if (!session) return NextResponse.json({ error: "Forbidden." }, { status: 403 });

  const { id } = await req.json();
  if (!id) return NextResponse.json({ error: "Missing id." }, { status: 400 });

  const db = getDb();
  const result = db.prepare("DELETE FROM problems WHERE id = ?").run(id);
  if (result.changes === 0) return NextResponse.json({ error: "Problem not found." }, { status: 404 });

  return NextResponse.json({ success: true });
}
