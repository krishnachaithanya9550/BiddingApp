"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import { cn } from "@/lib/utils";
import ContributionHeatmap from "@/components/ui/ContributionHeatmap";
import type { DeveloperPublicProfile, WorkExperience } from "@/types";

const STATUS_STYLE: Record<string, { label: string; color: string; dot: string }> = {
  available:      { label: "Available",      color: "text-primary",    dot: "bg-primary" },
  open_to_offers: { label: "Open to Offers", color: "text-yellow-400", dot: "bg-yellow-400" },
  busy:           { label: "Unavailable",    color: "text-red-400",    dot: "bg-red-400" },
};

const RANK_BADGE: Record<number, string> = {
  1: "bg-yellow-400 text-black",
  2: "bg-gray-300 text-black",
  3: "bg-amber-600 text-white",
};

export default function LeaderboardPage() {
  const { profile, loading } = useAuth(["0", "company"]);
  const [developers, setDevelopers] = useState<DeveloperPublicProfile[]>([]);
  const [dataLoading, setDataLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<DeveloperPublicProfile | null>(null);

  useEffect(() => {
    if (!profile) return;
    fetch("/api/community")
      .then((r) => r.ok ? r.json() : { developers: [] })
      .then((d: { developers?: DeveloperPublicProfile[] }) => { setDevelopers(d.developers ?? []); setDataLoading(false); })
      .catch(() => setDataLoading(false));
  }, [profile]);

  if (loading || !profile) return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
    </div>
  );

  const filtered = developers.filter((d) =>
    !search ||
    d.name.toLowerCase().includes(search.toLowerCase()) ||
    d.location?.toLowerCase().includes(search.toLowerCase()) ||
    (Array.isArray(d.skills) && d.skills.some((s: string) => s.toLowerCase().includes(search.toLowerCase())))
  );

  return (
    <DashboardShell profile={profile}>
      {/* Header */}
      <div className="mb-8">
        <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-yellow-400">Community</p>
        <h1 className="text-3xl font-extrabold text-white">Developer Leaderboard</h1>
        <p className="mt-2 text-secondary text-sm">
          Top developers ranked by contributions. Click any card to view their full profile.
        </p>
      </div>

      {/* Search */}
      <div className="mb-6">
        <input
          className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-secondary/50 outline-none focus:border-primary/40 transition-colors"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, skills, or location…"
        />
      </div>

      {/* Top 3 podium */}
      {!search && !dataLoading && developers.length >= 3 && (
        <div className="mb-8 grid grid-cols-3 gap-4">
          {[developers[1], developers[0], developers[2]].map((dev, podiumIdx) => {
            const actualRank = podiumIdx === 0 ? 2 : podiumIdx === 1 ? 1 : 3;
            const statusInfo = STATUS_STYLE[dev.working_status] ?? STATUS_STYLE.busy;
            return (
              <div
                key={dev.id}
                onClick={() => setSelected(dev)}
                className={cn(
                  "cursor-pointer rounded-2xl border p-5 text-center transition-all hover:scale-[1.02]",
                  actualRank === 1
                    ? "border-yellow-400/30 bg-yellow-400/5 mt-0"
                    : "border-white/8 bg-white/3 mt-6"
                )}
              >
                <div className={cn(
                  "mx-auto mb-3 flex h-6 w-6 items-center justify-center rounded-full text-xs font-black",
                  RANK_BADGE[actualRank] ?? "bg-white/10 text-white"
                )}>
                  {actualRank === 1 ? "🥇" : actualRank === 2 ? "🥈" : "🥉"}
                </div>
                <div
                  className="mx-auto mb-3 relative h-14 w-14 rounded-full flex items-center justify-center text-xl font-black text-black"
                  style={{ background: dev.avatar_color || "#22c55e" }}
                >
                  {dev.name.charAt(0).toUpperCase()}
                  <span className={cn("absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-black", statusInfo.dot)} />
                </div>
                <p className="font-bold text-white text-sm truncate">{dev.name}</p>
                <p className="text-xs text-secondary truncate">{dev.location || "—"}</p>
                <p className="mt-2 text-xl font-black text-primary">{dev.contributions ?? 0}</p>
                <p className="text-[10px] text-secondary uppercase tracking-wider">contributions</p>
              </div>
            );
          })}
        </div>
      )}

      {/* Full ranked list */}
      {dataLoading ? (
        <div className="space-y-3">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-20 rounded-2xl border border-white/5 bg-white/3 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-white/8 bg-white/3 p-12 text-center">
          <p className="text-4xl mb-3">🏆</p>
          <p className="text-white font-semibold">No developers found</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((dev) => {
            const statusInfo = STATUS_STYLE[dev.working_status] ?? STATUS_STYLE.busy;
            return (
              <div
                key={dev.id}
                onClick={() => setSelected(dev)}
                className="group flex items-center gap-4 rounded-2xl border border-white/8 bg-white/3 px-5 py-4 cursor-pointer transition-all hover:border-primary/30 hover:bg-white/5"
              >
                {/* Rank */}
                <div className={cn(
                  "shrink-0 flex h-9 w-9 items-center justify-center rounded-full text-sm font-black",
                  dev.rank <= 3 ? (RANK_BADGE[dev.rank] ?? "bg-white/10 text-secondary") : "bg-white/5 text-secondary"
                )}>
                  {dev.rank <= 3
                    ? (dev.rank === 1 ? "🥇" : dev.rank === 2 ? "🥈" : "🥉")
                    : `#${dev.rank}`}
                </div>

                {/* Avatar */}
                <div className="relative shrink-0 h-10 w-10 rounded-full flex items-center justify-center text-sm font-black text-black"
                  style={{ background: dev.avatar_color || "#22c55e" }}>
                  {dev.name.charAt(0).toUpperCase()}
                  <span className={cn("absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-black", statusInfo.dot)} />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-bold text-white">{dev.name}</p>
                    <span className={cn("text-xs font-semibold", statusInfo.color)}>● {statusInfo.label}</span>
                  </div>
                  <div className="flex items-center gap-3 mt-1 flex-wrap">
                    {dev.location && <p className="text-xs text-secondary">📍 {dev.location}</p>}
                    {dev.hourly_rate ? <p className="text-xs text-secondary">💵 ${dev.hourly_rate}/hr</p> : null}
                    {Array.isArray(dev.skills) && dev.skills.length > 0 && (
                      <div className="flex gap-1 flex-wrap">
                        {dev.skills.slice(0, 3).map((s: string) => (
                          <span key={s} className="rounded-full border border-primary/20 bg-primary/5 px-1.5 py-0.5 text-[10px] text-primary">{s}</span>
                        ))}
                        {dev.skills.length > 3 && (
                          <span className="text-[10px] text-secondary">+{dev.skills.length - 3}</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Contributions */}
                <div className="shrink-0 text-right">
                  <p className="text-xl font-black text-primary">{dev.contributions ?? 0}</p>
                  <p className="text-[10px] text-secondary uppercase tracking-wider">contributions</p>
                </div>

                {/* Arrow */}
                <span className="shrink-0 text-secondary group-hover:text-primary transition-colors">→</span>
              </div>
            );
          })}
        </div>
      )}

      {/* Dev profile modal */}
      {selected && (
        <DevProfileModal dev={selected} onClose={() => setSelected(null)} />
      )}
    </DashboardShell>
  );
}

// ── DevProfileModal ───────────────────────────────────────────────────────────

function DevProfileModal({ dev, onClose }: { dev: DeveloperPublicProfile; onClose: () => void }) {
  const statusInfo = STATUS_STYLE[dev.working_status] ?? STATUS_STYLE.busy;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/75 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-lg rounded-3xl border border-white/10 bg-black/90 p-7 shadow-2xl overflow-y-auto max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-secondary hover:text-white text-xl">✕</button>

        {/* Rank badge */}
        {dev.rank <= 3 && (
          <div className="mb-4 flex justify-center">
            <span className={cn("rounded-full px-4 py-1 text-sm font-black",
              dev.rank === 1 ? "bg-yellow-400/20 text-yellow-400" :
              dev.rank === 2 ? "bg-gray-300/20 text-gray-300" : "bg-amber-600/20 text-amber-500"
            )}>
              {dev.rank === 1 ? "🥇 #1 Top Contributor" : dev.rank === 2 ? "🥈 #2 Developer" : "🥉 #3 Developer"}
            </span>
          </div>
        )}

        {/* Avatar + name */}
        <div className="flex items-center gap-4 mb-6">
          <div className="relative h-16 w-16 shrink-0 rounded-full flex items-center justify-center text-2xl font-black text-black"
            style={{ background: dev.avatar_color || "#22c55e" }}>
            {dev.name.charAt(0).toUpperCase()}
            <span className={cn("absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-black", statusInfo.dot)} />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-white">{dev.name}</h2>
            <p className={cn("text-sm font-semibold", statusInfo.color)}>{statusInfo.label}</p>
            {dev.location && <p className="text-xs text-secondary">📍 {dev.location}</p>}
          </div>
        </div>

        {/* Stats */}
        <div className="mb-5 grid grid-cols-3 gap-3">
          {[
            { label: "Rank",          value: `#${dev.rank}` },
            { label: "Contributions", value: String(dev.contributions ?? 0) },
            { label: "Rate",          value: dev.hourly_rate ? `$${dev.hourly_rate}/hr` : "—" },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-white/8 bg-white/3 p-3 text-center">
              <p className="text-lg font-black text-primary">{s.value}</p>
              <p className="text-[10px] text-secondary uppercase tracking-wider">{s.label}</p>
            </div>
          ))}
        </div>

        {dev.bio && <p className="mb-5 text-sm text-secondary leading-relaxed">{dev.bio}</p>}

        {/* Contribution heatmap */}
        <div className="mb-5">
          <ContributionHeatmap devId={dev.id} compact />
        </div>

        {/* Skills */}
        {Array.isArray(dev.skills) && dev.skills.length > 0 && (
          <div className="mb-5">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-secondary/60">Skills</p>
            <div className="flex flex-wrap gap-1.5">
              {dev.skills.map((s: string) => (
                <span key={s} className="rounded-full border border-primary/20 bg-primary/5 px-2.5 py-0.5 text-xs text-primary">{s}</span>
              ))}
            </div>
          </div>
        )}

        {/* Experience */}
        {Array.isArray(dev.experience) && dev.experience.length > 0 && (
          <div className="mb-5">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-secondary/60">Experience</p>
            {(dev.experience as WorkExperience[]).map((exp, i) => (
              <div key={i} className="mb-3 rounded-xl border border-white/8 bg-white/3 p-3">
                <p className="font-semibold text-white text-sm">{exp.role} @ {exp.company}</p>
                <p className="text-xs text-secondary">{exp.duration}</p>
                {exp.description && <p className="text-xs text-secondary/70 mt-1">{exp.description}</p>}
              </div>
            ))}
          </div>
        )}

        {/* Links */}
        <div className="flex flex-wrap gap-3">
          {dev.github_url && (
            <a href={dev.github_url} target="_blank" rel="noopener noreferrer"
              className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-secondary hover:text-white transition-colors">
              GitHub ↗
            </a>
          )}
          {dev.linkedin_url && (
            <a href={dev.linkedin_url} target="_blank" rel="noopener noreferrer"
              className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-secondary hover:text-white transition-colors">
              LinkedIn ↗
            </a>
          )}
          {dev.portfolio_url && (
            <a href={dev.portfolio_url} target="_blank" rel="noopener noreferrer"
              className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-secondary hover:text-white transition-colors">
              Portfolio ↗
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
