﻿"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useAuth } from "@/lib/useAuth";
import DashboardShell from "@/components/ui/DashboardShell";
import {
  getCompanyProblems,
  getCompanySubmissions,
  updateProblemStatus,
} from "@/lib/problems";
import { cn } from "@/lib/utils";
import type { Problem, Submission } from "@/types";

// ─── Status Config ────────────────────────────────────────────────────────────

const STATUS_STYLE: Record<Problem["status"], string> = {
  open:      "border-primary/30 bg-primary/10 text-primary",
  in_review: "border-yellow-500/30 bg-yellow-500/10 text-yellow-400",
  closed:    "border-white/10 bg-white/5 text-secondary",
};

const STATUS_OPTIONS: { value: Problem["status"]; label: string; icon: string }[] = [
  { value: "open",      label: "Open",      icon: "🟢" },
  { value: "in_review", label: "In Review", icon: "🔍" },
  { value: "closed",    label: "Closed",    icon: "🔒" },
];

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function CompanyDashboard() {
  const { profile, loading } = useAuth(["0", "company"]);
  const searchParams = useSearchParams();
  const justPosted = searchParams.get("posted") === "1";

  const [problems,      setProblems]      = useState<Problem[]>([]);
  const [submissions,   setSubmissions]   = useState<Submission[]>([]);
  const [dataLoading,   setDataLoading]   = useState(true);
  const [statusError,   setStatusError]   = useState<string | null>(null);
  const [updatingId,    setUpdatingId]    = useState<string | null>(null);
  const [successBanner, setSuccessBanner] = useState(justPosted);

  // ── Fetch ──────────────────────────────────────────────────────────────────
  const fetchData = useCallback(async (companyId: string) => {
    const [p, s] = await Promise.all([
      getCompanyProblems(companyId),
      getCompanySubmissions(companyId),
    ]);
    setProblems(p.problems);
    setSubmissions(s.submissions);
    setDataLoading(false);
  }, []);

  useEffect(() => {
    if (!profile) return;
    fetchData(profile.id);
  }, [profile, fetchData]);

  // Auto-dismiss success banner
  useEffect(() => {
    if (!successBanner) return;
    const t = setTimeout(() => setSuccessBanner(false), 5000);
    return () => clearTimeout(t);
  }, [successBanner]);

  // ── Status update ─────────────────────────────────────────────────────────
  async function handleStatusChange(problemId: string, newStatus: Problem["status"]) {
    setStatusError(null);
    setUpdatingId(problemId);
    const { error } = await updateProblemStatus(problemId, newStatus);
    if (error) {
      setStatusError(error);
    } else {
      setProblems((prev) =>
        prev.map((p) => (p.id === problemId ? { ...p, status: newStatus } : p))
      );
    }
    setUpdatingId(null);
  }

  if (loading || !profile) return <LoadingSkeleton />;

  const openCount   = problems.filter((p) => p.status === "open").length;
  const pendingSubs = submissions.filter((s) => s.status === "pending").length;

  return (
    <DashboardShell profile={profile}>

      {/* Success banner */}
      {successBanner && (
        <div
          role="status"
          className="mb-8 flex items-center gap-3 rounded-2xl border border-primary/30 bg-primary/10 px-5 py-4 text-sm font-medium text-primary"
        >
          <span className="text-lg">🎉</span>
          <span>Problem posted successfully! Developers can now submit proposals.</span>
          <button
            onClick={() => setSuccessBanner(false)}
            className="ml-auto text-primary/60 hover:text-primary transition-colors"
            aria-label="Dismiss"
          >
            ✕
          </button>
        </div>
      )}

      {/* Header */}
      <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-blue-400">
            Business Hub
          </p>
          <h1 className="text-4xl font-extrabold text-white">Welcome, {profile.name} 👋</h1>
          <p className="mt-2 text-secondary text-sm">
            Manage your problems, review submissions and grow your team.
          </p>
        </div>
        <Link
          href="/post-problem"
          className="shrink-0 rounded-full bg-primary px-6 py-3 text-sm font-bold text-black transition-opacity hover:opacity-80"
        >
          + Post a Problem
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 mb-10">
        {[
          { label: "Total Problems",    value: dataLoading ? "…" : String(problems.length),    icon: "💼" },
          { label: "Open Problems",     value: dataLoading ? "…" : String(openCount),           icon: "🟢" },
          { label: "Total Submissions", value: dataLoading ? "…" : String(submissions.length), icon: "📥" },
          { label: "Pending Review",    value: dataLoading ? "…" : String(pendingSubs),         icon: "⏳" },
        ].map((s) => (
          <div key={s.label} className="card-3d rounded-2xl border border-white/8 bg-gradient-to-br from-blue-500/5 to-transparent p-6">
            <p className="text-2xl font-black text-blue-400">{s.value}</p>
            <p className="mt-1 text-xs text-secondary uppercase tracking-wider flex items-center gap-1.5">
              <span>{s.icon}</span>{s.label}
            </p>
          </div>
        ))}
      </div>

      {/* Nav cards */}
      <div className="grid gap-4 sm:grid-cols-3 mb-12">
        {[
          {
            icon: "📝",
            title: "Post a Problem",
            desc: "Find developers for your next challenge",
            href: "/post-problem",
            cta: "Post Now",
            accent: "hover:border-primary/40",
          },
          {
            icon: "📥",
            title: "View Submissions",
            desc: "Review proposals from developers",
            href: "/submissions",
            cta: `View${pendingSubs > 0 ? ` (${pendingSubs} pending)` : " All"}`,
            accent: "hover:border-blue-500/40",
          },
          {
            icon: "⚙️",
            title: "Manage Projects",
            desc: "Track and update your active problems below",
            href: "#problems",
            cta: "Manage Below",
            accent: "hover:border-yellow-500/40",
          },
        ].map((card) => (
          <Link
            key={card.title}
            href={card.href}
            className={cn(
              "card-3d flex flex-col justify-between rounded-2xl border border-white/8 bg-white/3 p-6 transition-all duration-300 hover:bg-white/[0.07]",
              card.accent
            )}
          >
            <div>
              <span className="mb-3 block text-3xl">{card.icon}</span>
              <h3 className="font-bold text-white">{card.title}</h3>
              <p className="mt-1 text-xs text-secondary">{card.desc}</p>
            </div>
            <span className="mt-4 text-xs font-semibold text-blue-400">{card.cta} →</span>
          </Link>
        ))}
      </div>

      {/* ── Manage Projects ──────────────────────────────────────────────────── */}
      <section id="problems" aria-labelledby="problems-heading">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h2 id="problems-heading" className="text-xl font-bold text-white">Manage Projects</h2>
            <p className="text-xs text-secondary mt-0.5">
              Update status, track submissions and manage all your posted problems.
            </p>
          </div>
          <Link
            href="/post-problem"
            className="text-xs font-semibold text-primary hover:opacity-75 transition-opacity"
          >
            + New Problem
          </Link>
        </div>

        {statusError && (
          <div role="alert" className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">
            {statusError}
          </div>
        )}

        {dataLoading ? (
          <ProjectsSkeleton />
        ) : problems.length === 0 ? (
          <EmptyProjects />
        ) : (
          <div className="flex flex-col gap-3">
            {problems.map((p) => (
              <ProblemCard
                key={p.id}
                problem={p}
                submissionCount={submissions.filter((s) => s.problem_id === p.id).length}
                pendingCount={submissions.filter(
                  (s) => s.problem_id === p.id && s.status === "pending"
                ).length}
                isUpdating={updatingId === p.id}
                onStatusChange={(status) => handleStatusChange(p.id, status)}
              />
            ))}
          </div>
        )}
      </section>

    </DashboardShell>
  );
}

// ─── Problem Card with inline status management ───────────────────────────────

interface ProblemCardProps {
  problem: Problem;
  submissionCount: number;
  pendingCount: number;
  isUpdating: boolean;
  onStatusChange: (status: Problem["status"]) => void;
}

function ProblemCard({
  problem: p,
  submissionCount,
  pendingCount,
  isUpdating,
  onStatusChange,
}: ProblemCardProps) {
  const [showMenu, setShowMenu] = useState(false);

  return (
    <article className="rounded-2xl border border-white/10 bg-white/5 px-6 py-5 transition hover:border-white/20">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">

        {/* Left: problem info */}
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="font-semibold text-white">{p.title}</span>
            <span className={cn(
              "rounded-full border px-2.5 py-0.5 text-xs font-semibold capitalize",
              STATUS_STYLE[p.status]
            )}>
              {p.status.replace("_", " ")}
            </span>
          </div>

          {/* Skills */}
          <div className="flex flex-wrap gap-1.5 mb-3">
            {p.skills.slice(0, 5).map((sk) => (
              <span
                key={sk}
                className="rounded-full border border-white/10 bg-white/5 px-2.5 py-0.5 text-xs text-secondary"
              >
                {sk}
              </span>
            ))}
            {p.skills.length > 5 && (
              <span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-0.5 text-xs text-secondary">
                +{p.skills.length - 5} more
              </span>
            )}
          </div>

          {/* Meta */}
          <div className="flex flex-wrap items-center gap-4 text-xs text-secondary">
            <span className="font-semibold text-white">${p.budget.toLocaleString()}</span>
            <span>Due {new Date(p.deadline).toLocaleDateString("en-US", { day: "numeric", month: "short", year: "numeric" })}</span>
            <span>Posted {new Date(p.created_at).toLocaleDateString("en-US", { day: "numeric", month: "short" })}</span>
            <Link
              href={`/submissions?problem=${p.id}`}
              className="flex items-center gap-1.5 text-blue-400 hover:text-blue-300 transition-colors"
            >
              📥 {submissionCount} submission{submissionCount !== 1 ? "s" : ""}
              {pendingCount > 0 && (
                <span className="rounded-full border border-yellow-500/30 bg-yellow-500/10 px-1.5 py-0.5 text-yellow-400 font-bold">
                  {pendingCount} pending
                </span>
              )}
            </Link>
          </div>
        </div>

        {/* Right: status picker dropdown */}
        <div className="shrink-0 relative">
          <button
            onClick={() => setShowMenu((v) => !v)}
            disabled={isUpdating}
            aria-expanded={showMenu}
            aria-haspopup="listbox"
            className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-semibold text-secondary transition hover:border-white/20 hover:text-white disabled:opacity-40"
          >
            {isUpdating ? (
              <>
                <svg className="h-3.5 w-3.5 animate-spin" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                </svg>
                Updating…
              </>
            ) : (
              <>
                <span>⚙️</span>
                Set Status
                <svg
                  className={cn("h-3.5 w-3.5 transition-transform", showMenu && "rotate-180")}
                  fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
              </>
            )}
          </button>

          {showMenu && (
            <>
              <div
                className="fixed inset-0 z-10"
                onClick={() => setShowMenu(false)}
                aria-hidden="true"
              />
              <ul
                role="listbox"
                aria-label="Set problem status"
                className="absolute right-0 top-full z-20 mt-1.5 w-44 overflow-hidden rounded-xl border border-white/10 bg-[#0f0f0f] shadow-2xl"
              >
                {STATUS_OPTIONS.map((opt) => (
                  <li key={opt.value}>
                    <button
                      role="option"
                      aria-selected={p.status === opt.value}
                      onClick={() => {
                        setShowMenu(false);
                        if (p.status !== opt.value) onStatusChange(opt.value);
                      }}
                      className={cn(
                        "flex w-full items-center gap-2.5 px-4 py-3 text-xs font-semibold transition",
                        p.status === opt.value
                          ? "bg-white/10 text-white"
                          : "text-secondary hover:bg-white/5 hover:text-white"
                      )}
                    >
                      <span>{opt.icon}</span>
                      {opt.label}
                      {p.status === opt.value && (
                        <svg className="ml-auto h-3.5 w-3.5 text-primary" fill="none" viewBox="0 0 24 24"
                          stroke="currentColor" strokeWidth={3}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      </div>
    </article>
  );
}

// ─── Empty / Skeleton States ──────────────────────────────────────────────────

function EmptyProjects() {
  return (
    <div className="rounded-2xl border border-dashed border-white/10 p-14 text-center">
      <p className="text-5xl mb-4">📭</p>
      <p className="text-lg font-bold text-white mb-2">No problems posted yet</p>
      <p className="text-sm text-secondary mb-8 max-w-xs mx-auto">
        Post your first problem to attract developer proposals.
      </p>
      <Link
        href="/post-problem"
        className="rounded-full bg-primary px-8 py-3 text-sm font-bold text-black transition-opacity hover:opacity-80"
      >
        Post a Problem
      </Link>
    </div>
  );
}

function ProjectsSkeleton() {
  return (
    <div className="flex flex-col gap-3">
      {Array.from({ length: 3 }).map((_, i) => (
        <div
          key={i}
          className="rounded-2xl border border-white/10 bg-white/5 px-6 py-5 animate-pulse"
        >
          <div className="flex flex-col gap-3">
            <div className="h-4 w-56 rounded bg-white/10" />
            <div className="flex gap-2">
              {Array.from({ length: 3 }).map((__, j) => (
                <div key={j} className="h-3 w-16 rounded-full bg-white/10" />
              ))}
            </div>
            <div className="h-3 w-48 rounded bg-white/10" />
          </div>
        </div>
      ))}
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="flex flex-col items-center gap-4">
        <svg className="h-8 w-8 animate-spin text-blue-400" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
        </svg>
        <p className="text-sm text-secondary">Loading business hub…</p>
      </div>
    </div>
  );
}