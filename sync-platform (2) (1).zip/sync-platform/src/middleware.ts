/**
 * middleware.ts — SYNC Route Protection Middleware
 *
 * Runs on every matched request before the page renders.
 * Verifies the sync-session JWT cookie and enforces role-based access.
 */

import { NextRequest, NextResponse } from "next/server";
import { verifySession, COOKIE_NAME } from "@/lib/session";
import { isPublicRoute, getProtectedRoute, getRoleHome, canAccess } from "@/lib/rbac";
import type { UserRole } from "@/types";

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // ── 1. Always allow public routes ──────────────────────────────────────────
  if (isPublicRoute(pathname)) {
    return NextResponse.next();
  }

  // ── 2. Only process protected routes ───────────────────────────────────────
  const protectedRoute = getProtectedRoute(pathname);
  if (!protectedRoute) {
    return NextResponse.next();
  }

  // ── 3. Verify session JWT from cookie ──────────────────────────────────────
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) {
    return redirectToLogin(req);
  }

  const session = await verifySession(token);
  if (!session) {
    return redirectToLogin(req);
  }

  const role = session.role as UserRole;

  // ── 4. Check authorization ─────────────────────────────────────────────────
  if (!canAccess(pathname, role)) {
    const url = req.nextUrl.clone();
    url.pathname = getRoleHome(role);
    return NextResponse.redirect(url);
  }

  // ── 5. Authorized — attach role header for downstream use ──────────────────
  const res = NextResponse.next();
  res.headers.set("x-sync-role", role);
  return res;
}

function redirectToLogin(req: NextRequest): NextResponse {
  const url = req.nextUrl.clone();
  url.pathname = "/login";
  url.searchParams.set("next", req.nextUrl.pathname);
  return NextResponse.redirect(url);
}

// ─── Matcher ───────────────────────────────────────────────────────────────────
export const config = {
  matcher: [
    "/admin/:path*",
    "/developer-dashboard/:path*",
    "/company-dashboard/:path*",
    "/post-problem/:path*",
    "/submissions/:path*",
    "/dashboard/:path*",
  ],
};
