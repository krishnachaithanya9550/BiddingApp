/**
 * cn — Conditional className utility.
 * Merges Tailwind classes safely without duplicates.
 *
 * Usage:
 *   cn("px-4 py-2", isActive && "bg-primary", className)
 */

type ClassValue = string | boolean | null | undefined;

export function cn(...classes: ClassValue[]): string {
  return classes.filter(Boolean).join(" ");
}
