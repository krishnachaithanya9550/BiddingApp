import type { Problem, PostProblemPayload, Submission } from "@/types";

// ─── Problems ──────────────────────────────────────────────────────────────────

/** Post a new problem. company_id is taken from the session cookie server-side. */
export async function postProblem(
  _companyId: string,
  payload: PostProblemPayload
): Promise<{ problem: Problem | null; error: string | null }> {
  try {
    const res = await fetch("/api/problems", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) return { problem: null, error: data.error ?? "Failed to post problem." };
    return { problem: data.problem, error: null };
  } catch {
    return { problem: null, error: "Could not connect to server." };
  }
}

/** Fetch all problems posted by the current user's company. */
export async function getCompanyProblems(
  _companyId: string
): Promise<{ problems: Problem[]; error: string | null }> {
  try {
    const res = await fetch("/api/problems/company");
    const data = await res.json();
    if (!res.ok) return { problems: [], error: data.error ?? "Failed to load problems." };
    return { problems: data.problems, error: null };
  } catch {
    return { problems: [], error: "Could not connect to server." };
  }
}

/** Fetch a single problem by ID. */
export async function getProblemById(
  id: string
): Promise<{ problem: Problem | null; error: string | null }> {
  try {
    const res = await fetch(`/api/problems/${id}`);
    const data = await res.json();
    if (!res.ok) return { problem: null, error: data.error ?? "Problem not found." };
    return { problem: data.problem, error: null };
  } catch {
    return { problem: null, error: "Could not connect to server." };
  }
}

/** Update problem status. */
export async function updateProblemStatus(
  id: string,
  status: Problem["status"]
): Promise<{ error: string | null }> {
  try {
    const res = await fetch(`/api/problems/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    if (!res.ok) return { error: data.error ?? "Failed to update status." };
    return { error: null };
  } catch {
    return { error: "Could not connect to server." };
  }
}

// ─── Submissions ───────────────────────────────────────────────────────────────

/** Fetch all submissions for the current user's problems. */
export async function getCompanySubmissions(
  _companyId: string
): Promise<{ submissions: Submission[]; error: string | null }> {
  try {
    const res = await fetch("/api/submissions");
    const data = await res.json();
    if (!res.ok) return { submissions: [], error: data.error ?? "Failed to load submissions." };
    return { submissions: data.submissions, error: null };
  } catch {
    return { submissions: [], error: "Could not connect to server." };
  }
}

/** Update a submission status (accept/reject). */
export async function updateSubmissionStatus(
  id: string,
  status: Submission["status"]
): Promise<{ error: string | null }> {
  try {
    const res = await fetch(`/api/submissions/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    if (!res.ok) return { error: data.error ?? "Failed to update submission." };
    return { error: null };
  } catch {
    return { error: "Could not connect to server." };
  }
}

/** Fetch submissions for a specific problem. */
export async function getSubmissionsForProblem(
  problemId: string
): Promise<{ submissions: Submission[]; error: string | null }> {
  try {
    const res = await fetch(`/api/submissions?problem_id=${problemId}`);
    const data = await res.json();
    if (!res.ok) return { submissions: [], error: data.error ?? "Failed to load submissions." };
    return { submissions: data.submissions, error: null };
  } catch {
    return { submissions: [], error: "Could not connect to server." };
  }
}
