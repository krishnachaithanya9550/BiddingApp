"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { getProfile } from "@/lib/auth";
import { canAccess, getRoleHome } from "@/lib/rbac";
import type { UserProfile } from "@/types";

interface UseAuthResult {
  profile: UserProfile | null;
  loading: boolean;
}

export function useAuth(requiredRole?: UserProfile["role"] | UserProfile["role"][]): UseAuthResult {
  const router = useRouter();
  const pathname = usePathname();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getProfile().then(({ profile, error }) => {
      if (error || !profile) {
        router.replace(`/login?next=${encodeURIComponent(pathname)}`);
        return;
      }

      if (!canAccess(pathname, profile.role)) {
        router.replace(getRoleHome(profile.role));
        return;
      }

      if (requiredRole) {
        const allowed = Array.isArray(requiredRole) ? requiredRole : [requiredRole];
        if (!allowed.includes(profile.role)) {
          router.replace(getRoleHome(profile.role));
          return;
        }
      }

      setProfile(profile);
      setLoading(false);
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { profile, loading };
}

