import type { SignUpPayload, LoginPayload, UserProfile } from "@/types";

export async function signUp(
  payload: SignUpPayload
): Promise<{ profile: UserProfile | null; error: string | null }> {
  try {
    const res = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) return { profile: null, error: data.error ?? "Sign up failed." };
    return { profile: data.profile, error: null };
  } catch {
    return { profile: null, error: "Could not connect to server." };
  }
}

export async function signIn(
  payload: LoginPayload
): Promise<{ profile: UserProfile | null; error: string | null }> {
  try {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) return { profile: null, error: data.error ?? "Login failed." };
    return { profile: data.profile, error: null };
  } catch {
    return { profile: null, error: "Could not connect to server." };
  }
}

export async function signOut(): Promise<{ error: string | null }> {
  try {
    await fetch("/api/auth/logout", { method: "POST" });
    return { error: null };
  } catch {
    return { error: "Sign out failed." };
  }
}

export async function getProfile(): Promise<{
  profile: UserProfile | null;
  error: string | null;
}> {
  try {
    const res = await fetch("/api/auth/me");
    if (!res.ok) return { profile: null, error: null };
    const data = await res.json();
    return { profile: data.profile, error: null };
  } catch {
    return { profile: null, error: "Failed to load profile." };
  }
}