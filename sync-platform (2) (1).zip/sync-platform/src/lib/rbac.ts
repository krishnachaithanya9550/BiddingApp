﻿import type { UserRole } from "@/types";

// "0" = admin (DB-only), "user" = developer/user, "company" = business
export const ROLE_HOME: Record<UserRole, string> = {
  "0":       "/admin",
  "user":    "/developer-dashboard",
  "company": "/company-dashboard",
};

export const PROTECTED_ROUTES: { prefix: string; allowedRoles: UserRole[] }[] = [
  { prefix: "/admin",               allowedRoles: ["0"] },
  { prefix: "/developer-dashboard", allowedRoles: ["0", "user"] },
  { prefix: "/company-dashboard",   allowedRoles: ["0", "company"] },
  { prefix: "/post-problem",        allowedRoles: ["0", "company"] },
  { prefix: "/submissions",         allowedRoles: ["0", "company"] },
];

export const PUBLIC_ROUTES = ["/", "/login", "/signup", "/api/auth", "/api/problems"];

export function isPublicRoute(pathname: string): boolean {
  return PUBLIC_ROUTES.some(
    (pub) => pathname === pub || pathname.startsWith(pub + "/")
  );
}

export function getProtectedRoute(pathname: string) {
  return PROTECTED_ROUTES.find((r) => pathname.startsWith(r.prefix)) ?? null;
}

export function canAccess(pathname: string, role: UserRole): boolean {
  const route = getProtectedRoute(pathname);
  if (!route) return true;
  return route.allowedRoles.includes(role);
}

export function getRoleHome(role: UserRole): string {
  return ROLE_HOME[role] ?? "/";
}
