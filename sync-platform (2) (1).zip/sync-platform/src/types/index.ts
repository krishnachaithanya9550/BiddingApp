/**
 * Shared TypeScript types for the SYNC platform.
 * Add domain-specific types here as the app grows.
 */

/** Generic API response envelope */
export interface ApiResponse<T = unknown> {
  data: T;
  message?: string;
  success: boolean;
}

/** Generic paginated list shape */
export interface PaginatedResponse<T = unknown> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  hasNextPage: boolean;
}

/** Navigation link shape used by the Navbar */
export interface NavLink {
  label: string;
  href: string;
  external?: boolean;
}

/** Database result wrapper */
export interface DbResult<T = unknown> {
  data: T | null;
  error: string | null;
}

/** User roles supported by SYNC.
 * "0"       = admin (set manually in DB only)
 * "user"    = regular developer/user
 * "company" = business/company user
 */
export type UserRole = "0" | "user" | "company";

/** User profile stored in the `users` table */
export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  created_at: string;
  // Extended developer profile fields
  bio?: string;
  skills?: string[];
  experience?: WorkExperience[];
  github_url?: string;
  linkedin_url?: string;
  portfolio_url?: string;
  location?: string;
  hourly_rate?: number;
  working_status?: "available" | "busy" | "open_to_offers";
  avatar_color?: string;
  contributions?: number;
}

export interface WorkExperience {
  company: string;
  role: string;
  duration: string;  // e.g. "Jan 2022 – Mar 2024"
  description?: string;
}

/** Signup form payload */
export interface SignUpPayload {
  name: string;
  email: string;
  password: string;
  role: "user" | "company";
}

/** Login form payload */
export interface LoginPayload {
  email: string;
  password: string;
}

// ─── Business Domain ───────────────────────────────────────────────────────────

/** Problem posted by a business */
export interface Problem {
  id: string;
  company_id: string;
  title: string;
  description: string;
  budget: number;
  deadline: string;         // ISO date string
  skills: string[];         // array of skill tags
  status: "open" | "closed" | "in_review";
  created_at: string;
}

/** Form payload for posting a new problem */
export interface PostProblemPayload {
  title: string;
  description: string;
  budget: number;
  deadline: string;
  skills: string[];
}

/** Submission by a developer for a problem */
export interface Submission {
  id: string;
  problem_id: string;
  developer_id: string;
  proposal: string;
  solution_notes?: string;
  tech_stack?: string[];
  repo_url?: string;
  demo_url?: string;
  estimated_hours?: number;
  status: "pending" | "accepted" | "rejected";
  created_at: string;
  // Joined fields
  developer_name?: string;
  developer_email?: string;
  developer_bio?: string;
  developer_skills?: string[];
  developer_github?: string;
  developer_linkedin?: string;
  developer_portfolio?: string;
  developer_working_status?: string;
  developer_contributions?: number;
  developer_rank?: number;
  problem_title?: string;
}

// ─── Social ────────────────────────────────────────────────────────────────────

export interface Friendship {
  id: string;
  requester_id: string;
  addressee_id: string;
  status: "pending" | "accepted" | "declined";
  created_at: string;
  // Joined fields
  other_name?: string;
  other_email?: string;
  other_role?: UserRole;
}

export interface Message {
  id: string;
  sender_id: string;
  recipient_id?: string;
  group_id?: string;
  content: string;
  created_at: string;
  sender_name?: string;
}

export interface GroupChat {
  id: string;
  name: string;
  created_by: string;
  problem_id?: string;
  created_at: string;
  member_count?: number;
  last_message?: string;
}

export interface DeveloperPublicProfile {
  id: string;
  name: string;
  email: string;
  bio: string;
  skills: string[];
  experience: WorkExperience[];
  github_url: string;
  linkedin_url: string;
  portfolio_url: string;
  location: string;
  hourly_rate: number;
  working_status: string;
  avatar_color: string;
  contributions: number;
  rank: number;
  created_at: string;
  friendship_status?: "none" | "pending_sent" | "pending_received" | "accepted";
  friendship_id?: string | null;
}
