"use client";

import { useEffect, useState } from "react";

type Cell = { date: string; count: number } | null;

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
// Mon, Wed, Fri labels for the 7 rows (Sunday=0 to Saturday=6)
const DAY_LABELS = ["", "M", "", "W", "", "F", ""];

function cellBg(count: number): string {
  if (count === 0) return "rgba(255,255,255,0.05)";
  if (count === 1) return "#14532d";
  if (count === 2) return "#166534";
  if (count <= 4) return "#15803d";
  if (count <= 6) return "#16a34a";
  return "#22c55e";
}

// Build a grid of weeks (columns) × days (rows: Sun–Sat)
// Pads the start to align the first date to its correct day of week.
function buildGrid(data: { day: string; count: number }[]): Cell[][] {
  const map: Record<string, number> = {};
  data.forEach((d) => { map[d.day] = d.count; });

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // 365 days going back from today (inclusive)
  const days: Cell[] = [];
  for (let i = 364; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const s = d.toISOString().split("T")[0];
    days.push({ date: s, count: map[s] ?? 0 });
  }

  // Pad the front so the first day falls on the correct weekday column (Sun=0)
  const startDow = new Date((days[0] as { date: string }).date).getDay();
  const padded: Cell[] = [...Array(startDow).fill(null), ...days];
  // Pad end so the array is divisible into full weeks of 7
  while (padded.length % 7 !== 0) padded.push(null);

  const weeks: Cell[][] = [];
  for (let i = 0; i < padded.length; i += 7) {
    weeks.push(padded.slice(i, i + 7));
  }
  return weeks;
}

// Generate month label positions based on when a new month first appears
function getMonthLabels(weeks: Cell[][]): { col: number; text: string }[] {
  const out: { col: number; text: string }[] = [];
  let lastMonth = -1;
  weeks.forEach((week, col) => {
    const cell = week.find((c) => c !== null);
    if (!cell) return;
    const m = new Date((cell as { date: string }).date).getMonth();
    if (m !== lastMonth) {
      out.push({ col, text: MONTHS[m] });
      lastMonth = m;
    }
  });
  return out;
}

interface Props {
  devId: string;
  compact?: boolean;
}

export default function ContributionHeatmap({ devId, compact = false }: Props) {
  const [data, setData]         = useState<{ day: string; count: number }[]>([]);
  const [total, setTotal]       = useState(0);
  const [loading, setLoading]   = useState(true);
  const [hovered, setHovered]   = useState<{ date: string; count: number } | null>(null);

  useEffect(() => {
    if (!devId) return;
    setLoading(true);
    setData([]);
    fetch(`/api/profile/heatmap?id=${encodeURIComponent(devId)}`)
      .then((r) => (r.ok ? r.json() : { heatmap: [], total: 0 }))
      .then((d) => {
        setData(d.heatmap ?? []);
        setTotal(d.total ?? 0);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [devId]);

  if (loading) {
    return (
      <div className="rounded-2xl border border-white/8 bg-white/3 p-5">
        <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-secondary">Contribution Activity</p>
        <div className="h-24 animate-pulse rounded-xl bg-white/5" />
      </div>
    );
  }

  const CELL = compact ? 10 : 12;
  const GAP  = 2;
  const STEP = CELL + GAP;

  const weeks   = buildGrid(data);
  const mlabels = getMonthLabels(weeks);

  return (
    <div className="rounded-2xl border border-white/8 bg-white/3 p-5">
      {/* Header row */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs font-semibold uppercase tracking-wider text-secondary">
          Contribution Activity
        </p>
        <p className="text-xs text-secondary">
          <span className="font-bold text-white">{total}</span>{" "}
          submission{total !== 1 ? "s" : ""} in the past year
        </p>
      </div>

      {/* Scrollable grid */}
      <div style={{ overflowX: "auto", overflowY: "visible" }}>
        <div style={{ position: "relative", paddingTop: 18, display: "inline-block" }}>

          {/* Month labels */}
          {mlabels.map((m) => (
            <span
              key={m.text + m.col}
              style={{
                position: "absolute",
                top: 0,
                // offset by the day-label column width (16px) + col position
                left: 16 + m.col * STEP,
                fontSize: 9,
                color: "#6b7280",
                whiteSpace: "nowrap",
                lineHeight: "1",
                userSelect: "none",
              }}
            >
              {m.text}
            </span>
          ))}

          {/* Grid: day-of-week labels + week columns */}
          <div style={{ display: "flex", gap: GAP, alignItems: "flex-start" }}>

            {/* Day-of-week labels (Mon, Wed, Fri) */}
            <div style={{ display: "flex", flexDirection: "column", gap: GAP, width: 12, flexShrink: 0 }}>
              {DAY_LABELS.map((label, i) => (
                <div
                  key={i}
                  style={{
                    height: CELL,
                    fontSize: 8,
                    color: "#6b7280",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "flex-end",
                    userSelect: "none",
                  }}
                >
                  {label}
                </div>
              ))}
            </div>

            {/* Week columns */}
            {weeks.map((week, wi) => (
              <div key={wi} style={{ display: "flex", flexDirection: "column", gap: GAP, flexShrink: 0 }}>
                {week.map((cell, di) => (
                  <div
                    key={di}
                    title={
                      cell
                        ? `${cell.date}: ${cell.count} submission${cell.count !== 1 ? "s" : ""}`
                        : ""
                    }
                    style={{
                      width: CELL,
                      height: CELL,
                      borderRadius: 2,
                      backgroundColor: cell ? cellBg(cell.count) : "transparent",
                      flexShrink: 0,
                      transition: "opacity 0.1s",
                      opacity: cell ? 1 : 0,
                    }}
                    onMouseEnter={() => cell && setHovered(cell)}
                    onMouseLeave={() => setHovered(null)}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tooltip + Legend */}
      <div className="mt-2 flex items-center justify-between min-h-[18px]">
        <div className="text-[10px] text-secondary">
          {hovered ? (
            <>
              <span className="font-semibold text-white">
                {hovered.count > 0
                  ? `${hovered.count} submission${hovered.count !== 1 ? "s" : ""}`
                  : "No submissions"}
              </span>{" "}
              on {hovered.date}
            </>
          ) : (
            <span className="opacity-0 select-none">·</span>
          )}
        </div>

        {/* Color legend */}
        <div style={{ display: "flex", alignItems: "center", gap: 3 }}>
          <span style={{ fontSize: 9, color: "#6b7280" }}>Less</span>
          {([0, 1, 2, 4, 6, 9] as const).map((v) => (
            <div
              key={v}
              style={{
                width: 9,
                height: 9,
                borderRadius: 1.5,
                backgroundColor: cellBg(v),
              }}
            />
          ))}
          <span style={{ fontSize: 9, color: "#6b7280" }}>More</span>
        </div>
      </div>
    </div>
  );
}
