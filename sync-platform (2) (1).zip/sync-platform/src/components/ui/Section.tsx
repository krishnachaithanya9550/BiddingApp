import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

interface SectionProps extends HTMLAttributes<HTMLElement> {
  id?: string;
  as?: "section" | "div" | "article";
  contained?: boolean;
}

export default function Section({
  id,
  as: Tag = "section",
  contained = true,
  className,
  children,
  ...props
}: SectionProps) {
  return (
    <Tag id={id} className={cn("w-full", className)} {...props}>
      {contained ? (
        <div className="mx-auto max-w-7xl px-6">{children}</div>
      ) : (
        children
      )}
    </Tag>
  );
}
