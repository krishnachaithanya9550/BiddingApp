import Section from "@/components/ui/Section";

const features = [
  {
    icon: "🏢",
    title: "Post Challenges",
    description: "Companies post real problems with budgets and deadlines. Get targeted proposals from vetted developers within hours.",
    accent: "from-green-500/10 to-emerald-500/5",
  },
  {
    icon: "⚡",
    title: "Instant Matching",
    description: "Our platform connects the right developer to the right problem. No middlemen, no overhead — just results.",
    accent: "from-blue-500/10 to-cyan-500/5",
  },
  {
    icon: "💼",
    title: "Manage Proposals",
    description: "Companies review, accept, or reject submissions with full context. Developers track every application in real-time.",
    accent: "from-violet-500/10 to-purple-500/5",
  },
  {
    icon: "🔒",
    title: "Secure by Design",
    description: "Role-based access, JWT sessions, and bcrypt hashing built in. Your data stays safe without extra configuration.",
    accent: "from-rose-500/10 to-pink-500/5",
  },
  {
    icon: "🚀",
    title: "Ship Faster",
    description: "Skip weeks of talent search. Post today, receive quality proposals tomorrow, and ship by next week.",
    accent: "from-amber-500/10 to-orange-500/5",
  },
  {
    icon: "🌍",
    title: "Real-Time Status",
    description: "Live submission tracking, problem status updates, and dashboard analytics keep every stakeholder informed.",
    accent: "from-teal-500/10 to-green-500/5",
  },
];

export default function Features() {
  return (
    <Section id="features" className="py-32 border-t border-white/5">
      <div className="mb-20 text-center">
        <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-primary">
          Why SYNC
        </p>
        <h2 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
          Everything you need to{" "}
          <span
            className="bg-clip-text text-transparent"
            style={{ backgroundImage: "linear-gradient(90deg, #22c55e, #86efac)" }}
          >
            close the gap
          </span>
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-secondary">
          A full-stack platform connecting companies with developers. No noise, just signal.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((feature, i) => (
          <div
            key={feature.title}
            className={`card-3d group relative rounded-2xl border border-white/8 bg-gradient-to-br ${feature.accent} p-8 transition-all duration-300`}
            style={{ animationDelay: `${i * 0.1}s` }}
          >
            {/* Shimmer overlay on hover */}
            <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 shimmer" />

            <span className="relative mb-5 block text-3xl">{feature.icon}</span>
            <h3 className="relative mb-2 text-lg font-bold text-white">{feature.title}</h3>
            <p className="relative text-sm leading-relaxed text-secondary">{feature.description}</p>

            {/* Bottom accent line */}
            <div className="absolute bottom-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>
        ))}
      </div>
    </Section>
  );
}
