import Link from "next/link";
import Section from "@/components/ui/Section";

export default function CTA() {
  return (
    <Section id="get-started" className="py-32 border-t border-white/5">
      <div className="gradient-border relative overflow-hidden rounded-3xl bg-black px-8 py-24 text-center sm:px-16">
        {/* Inner bg */}
        <div className="absolute inset-0 rounded-3xl" style={{ background: "radial-gradient(ellipse at 50% 0%, rgba(34,197,94,0.12) 0%, transparent 60%)" }} />
        <div className="absolute inset-0 grid-overlay opacity-40 rounded-3xl" />

        {/* Floating orbs */}
        <div aria-hidden="true" className="pointer-events-none">
          <div className="absolute -top-20 -left-20 h-40 w-40 rounded-full blur-[60px]" style={{ background: "rgba(34,197,94,0.15)" }} />
          <div className="absolute -bottom-20 -right-20 h-40 w-40 rounded-full blur-[60px]" style={{ background: "rgba(34,197,94,0.1)" }} />
        </div>

        <div className="relative">
          <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-primary">
            Get Started Today
          </p>
          <h2 className="mb-6 text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
            Ready to bridge the gap?
          </h2>
          <p className="mx-auto mb-10 max-w-lg text-secondary">
            Join as a company to find exceptional developers, or sign up as a developer to work on real-world problems that matter.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              href="/signup"
              className="btn-glow rounded-full bg-primary px-10 py-4 text-sm font-bold text-black transition-all duration-300 hover:-translate-y-1"
            >
              Create Free Account
            </Link>
            <Link
              href="/login"
              className="rounded-full border border-white/15 px-10 py-4 text-sm font-semibold text-secondary transition-all duration-300 hover:border-white/30 hover:text-white"
            >
              Sign In
            </Link>
          </div>
        </div>
      </div>
    </Section>
  );
}
