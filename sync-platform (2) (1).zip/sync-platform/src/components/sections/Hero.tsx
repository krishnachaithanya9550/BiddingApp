import Link from "next/link";
import { siteConfig } from "@/config/site";

export default function Hero() {
  return (
    <section
      id="hero"
      className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 text-center"
    >
      {/* Deep space background */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        {/* Primary glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[700px] w-[700px] rounded-full"
          style={{ background: "radial-gradient(circle, rgba(34,197,94,0.12) 0%, transparent 70%)" }} />
        {/* Secondary accent glows */}
        <div className="absolute top-1/4 right-1/4 h-64 w-64 rounded-full blur-[80px] opacity-40"
          style={{ background: "rgba(34,197,94,0.08)" }} />
        <div className="absolute bottom-1/3 left-1/5 h-48 w-48 rounded-full blur-[60px] opacity-30"
          style={{ background: "rgba(20,184,166,0.1)" }} />
      </div>

      {/* Grid overlay */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 grid-overlay opacity-60" />

      {/* Floating 3D cards in background */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="animate-float absolute top-20 right-[8%] hidden lg:block" style={{ perspective: "600px" }}>
          <div className="w-52 rounded-2xl glass p-5" style={{ transform: "rotateY(-15deg) rotateX(5deg)" }}>
            <div className="mb-3 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />
              <span className="text-xs text-secondary">Live Deploy</span>
            </div>
            <div className="text-sm font-bold text-white">v2.4.1 shipped</div>
            <div className="mt-1 text-xs text-secondary">0 errors · 3ms cold start</div>
            <div className="mt-3 h-1 rounded-full bg-white/10">
              <div className="h-1 w-4/5 rounded-full bg-primary" />
            </div>
          </div>
        </div>

        <div className="animate-float-delay absolute bottom-32 left-[6%] hidden lg:block" style={{ perspective: "600px" }}>
          <div className="w-48 rounded-2xl glass p-5" style={{ transform: "rotateY(15deg) rotateX(-5deg)" }}>
            <div className="mb-3 text-2xl">⚡</div>
            <div className="text-sm font-bold text-white">99.9% uptime</div>
            <div className="mt-1 text-xs text-primary">↑ 12% this month</div>
          </div>
        </div>

        <div className="animate-float-slow absolute top-36 left-[10%] hidden xl:block" style={{ perspective: "600px" }}>
          <div className="w-44 rounded-2xl glass p-4" style={{ transform: "rotateY(12deg) rotateX(8deg)" }}>
            <div className="flex items-center gap-2 mb-2">
              <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs">C</div>
              <span className="text-xs text-secondary">New match</span>
            </div>
            <div className="text-xs text-white leading-relaxed">React developer found for your project</div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center gap-6 max-w-5xl">
        {/* Badge */}
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-5 py-2 text-xs font-semibold uppercase tracking-widest text-primary">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
            Platform live · v{siteConfig.version}
          </span>
        </div>

        {/* Headline */}
        <div className="animate-fade-up-delay">
          <h1 className="text-7xl font-black tracking-tighter text-white sm:text-8xl lg:text-[9rem] leading-none">
            <span className="block">
              <span
                className="bg-clip-text text-transparent neon-text"
                style={{ backgroundImage: "linear-gradient(135deg, #22c55e 0%, #86efac 50%, #22c55e 100%)" }}
              >
                {siteConfig.name}
              </span>
            </span>
          </h1>
        </div>

        {/* Sub-headline */}
        <div className="animate-fade-up-delay-2">
          <p className="max-w-2xl text-lg font-medium leading-relaxed text-secondary sm:text-xl">
            Where{" "}
            <span className="text-white font-semibold">companies</span> find{" "}
            <span className="text-primary font-semibold">world-class developers</span>.
            Post challenges. Get proposals. Ship faster.
          </p>
        </div>

        {/* CTA */}
        <div className="animate-fade-up-delay-2 mt-2 flex flex-col items-center gap-4 sm:flex-row">
          <Link
            href="/signup"
            className="btn-glow relative rounded-full bg-primary px-9 py-3.5 text-sm font-bold text-black transition-all duration-300 hover:-translate-y-1"
          >
            Get Started Free
          </Link>
          <Link
            href="#features"
            className="rounded-full border border-white/15 px-9 py-3.5 text-sm font-semibold text-secondary transition-all duration-300 hover:border-primary/40 hover:text-white hover:-translate-y-0.5"
          >
            How it works ↓
          </Link>
        </div>

        {/* Social proof bar */}
        <div className="animate-fade-up-delay-2 mt-4 flex items-center gap-6 text-xs text-secondary">
          <span className="flex items-center gap-1.5">
            <span className="text-primary">✓</span> Free to join
          </span>
          <span className="h-3 w-px bg-white/10" />
          <span className="flex items-center gap-1.5">
            <span className="text-primary">✓</span> No credit card
          </span>
          <span className="h-3 w-px bg-white/10" />
          <span className="flex items-center gap-1.5">
            <span className="text-primary">✓</span> Ship in days
          </span>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-secondary/50">
        <div className="h-10 w-px bg-gradient-to-b from-transparent via-secondary/30 to-transparent" />
        <span className="text-[10px] tracking-widest uppercase">Scroll</span>
      </div>
    </section>
  );
}
