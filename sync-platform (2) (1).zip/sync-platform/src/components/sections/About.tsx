import Section from "@/components/ui/Section";

const stats = [
  { value: "2x",  label: "Faster hiring",      icon: "🚀" },
  { value: "100%", label: "Transparent process", icon: "🔍" },
  { value: "0",    label: "Hidden fees",         icon: "✔️" },
  { value: "24h",  label: "First proposals",     icon: "⚡" },
];

const steps = [
  { n: "01", title: "Company posts a problem", desc: "Describe the challenge, set budget & deadline, add required skills." },
  { n: "02", title: "Developers submit proposals", desc: "Qualified developers browse open problems and submit detailed proposals." },
  { n: "03", title: "Review & accept", desc: "Company reviews all proposals, accepts the best fit, and the work begins." },
];

export default function About() {
  return (
    <Section id="about" className="py-32 border-t border-white/5">
      {/* Header */}
      <div className="mb-20 text-center">
        <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-primary">How it works</p>
        <h2 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
          Simple. Transparent.{" "}
          <span
            className="bg-clip-text text-transparent"
            style={{ backgroundImage: "linear-gradient(90deg, #22c55e, #86efac)" }}
          >
            Effective.
          </span>
        </h2>
      </div>

      {/* Steps */}
      <div className="mb-24 grid gap-6 sm:grid-cols-3">
        {steps.map((step, i) => (
          <div key={step.n} className="relative">
            {i < steps.length - 1 && (
              <div className="absolute top-8 left-full w-full h-px bg-gradient-to-r from-primary/20 to-transparent hidden sm:block" />
            )}
            <div className="card-3d glass rounded-2xl p-8">
              <span
                className="mb-4 block text-4xl font-black"
                style={{ color: "rgba(34,197,94,0.3)" }}
              >
                {step.n}
              </span>
              <h3 className="mb-2 font-bold text-white">{step.title}</h3>
              <p className="text-sm text-secondary leading-relaxed">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-5 sm:grid-cols-4">
        {stats.map((s) => (
          <div
            key={s.label}
            className="card-3d relative overflow-hidden rounded-2xl border border-white/8 bg-gradient-to-br from-primary/5 to-transparent p-8 text-center"
          >
            <div className="absolute -top-4 -right-4 text-5xl opacity-10">{s.icon}</div>
            <p
              className="text-4xl font-black neon-text"
              style={{ color: "#22c55e" }}
            >
              {s.value}
            </p>
            <p className="mt-2 text-xs text-secondary uppercase tracking-wider">{s.label}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}
