﻿import Link from "next/link";
import { siteConfig } from "@/config/site";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-white/5 py-16 overflow-hidden">
      {/* Subtle glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-0 left-1/2 -translate-x-1/2 h-px w-1/2"
        style={{ background: "linear-gradient(90deg, transparent, rgba(34,197,94,0.4), transparent)" }}
      />

      <div className="mx-auto max-w-7xl px-6">
        <div className="flex flex-col items-center gap-8 sm:flex-row sm:justify-between">
          {/* Brand */}
          <div className="flex flex-col items-center gap-2 sm:items-start">
            <span className="text-xl font-black tracking-widest text-primary neon-text">
              {siteConfig.name}
            </span>
            <p className="text-xs text-secondary max-w-48 text-center sm:text-left">
              By devs. For devs. Always.
            </p>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap justify-center gap-x-8 gap-y-2">
            {[
              { label: "Features", href: "#features" },
              { label: "How it Works", href: "#about" },
              { label: "Sign In", href: "/login" },
              { label: "Sign Up", href: "/signup" },
            ].map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-sm text-secondary transition-colors hover:text-white"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Copyright */}
          <p className="text-xs text-secondary/50">
            &copy; {year} {siteConfig.name}
          </p>
        </div>
      </div>
    </footer>
  );
}
