﻿"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { siteConfig } from "@/config/site";
import { cn } from "@/lib/utils";
import { getProfile, signOut } from "@/lib/auth";
import { getRoleHome } from "@/lib/rbac";
import type { UserProfile } from "@/types";

const navLinks = [
  { label: "Features", href: "#features" },
  { label: "How it Works", href: "#about" },
];

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const router = useRouter();

  useEffect(() => {
    getProfile().then(({ profile }) => setProfile(profile ?? null));
  }, []);

  async function handleSignOut() {
    await signOut();
    setProfile(null);
    router.push("/");
    router.refresh();
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      {/* Gradient border bottom */}
      <div style={{ background: "linear-gradient(90deg, transparent, rgba(34,197,94,0.4), transparent)", height: "1px" }} className="absolute bottom-0 left-0 right-0" />

      <div
        className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6"
        style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)" }}
      >
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <span className="relative text-2xl font-black tracking-widest text-primary transition-all duration-300 group-hover:neon-text">
            {siteConfig.name}
          </span>
          <span className="hidden rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-widest text-primary sm:block">
            v{siteConfig.version}
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="relative text-sm font-medium text-secondary transition-colors hover:text-white after:absolute after:bottom-[-2px] after:left-0 after:h-px after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Auth buttons */}
        <div className="hidden items-center gap-3 md:flex">
          {profile ? (
            <>
              <Link
                href={getRoleHome(profile.role)}
                className="text-sm font-medium text-secondary transition-colors duration-200 hover:text-white"
              >
                Dashboard
              </Link>
              <button
                onClick={handleSignOut}
                className="rounded-full border border-white/10 px-5 py-2 text-sm font-medium text-secondary transition-all duration-200 hover:border-red-500/40 hover:text-red-400"
              >
                Sign Out
              </button>
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="text-sm font-medium text-secondary transition-colors duration-200 hover:text-white"
              >
                Sign In
              </Link>
              <Link
                href="/signup"
                className="btn-glow rounded-full bg-primary px-5 py-2 text-sm font-bold text-black transition-all duration-300 hover:-translate-y-0.5"
              >
                Get Started
              </Link>
            </>
          )}
        </div>

        {/* Mobile hamburger */}
        <button
          aria-label="Toggle navigation"
          className="flex flex-col gap-1.5 p-1 md:hidden"
          onClick={() => setMenuOpen((p) => !p)}
        >
          <span className={cn("block h-0.5 w-6 bg-white transition-transform duration-300", menuOpen && "translate-y-2 rotate-45")} />
          <span className={cn("block h-0.5 w-6 bg-white transition-opacity duration-300", menuOpen && "opacity-0")} />
          <span className={cn("block h-0.5 w-6 bg-white transition-transform duration-300", menuOpen && "-translate-y-2 -rotate-45")} />
        </button>
      </div>

      {/* Mobile menu */}
      <div
        className={cn(
          "overflow-hidden transition-all duration-300 md:hidden",
          menuOpen ? "max-h-64" : "max-h-0"
        )}
        style={{ background: "rgba(0,0,0,0.95)", backdropFilter: "blur(20px)" }}
      >
        <nav className="flex flex-col gap-4 border-t border-white/5 px-6 py-6">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="text-sm font-medium text-secondary hover:text-white transition-colors"
            >
              {link.label}
            </Link>
          ))}
          <div className="flex gap-3 pt-2 border-t border-white/5">
            {profile ? (
              <>
                <Link href={getRoleHome(profile.role)} onClick={() => setMenuOpen(false)}
                  className="flex-1 rounded-full border border-white/10 py-2 text-center text-sm font-medium text-secondary hover:text-white transition-colors">
                  Dashboard
                </Link>
                <button onClick={() => { setMenuOpen(false); handleSignOut(); }}
                  className="flex-1 rounded-full border border-red-500/20 py-2 text-center text-sm font-medium text-red-400 hover:bg-red-500/10 transition-colors">
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link href="/login" onClick={() => setMenuOpen(false)}
                  className="flex-1 rounded-full border border-white/10 py-2 text-center text-sm font-medium text-secondary hover:text-white transition-colors">
                  Sign In
                </Link>
                <Link href="/signup" onClick={() => setMenuOpen(false)}
                  className="flex-1 rounded-full bg-primary py-2 text-center text-sm font-bold text-black">
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </nav>
      </div>
    </header>
  );
}
