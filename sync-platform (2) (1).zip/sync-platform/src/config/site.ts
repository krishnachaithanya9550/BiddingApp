/**
 * Site-wide configuration constants.
 * Centralises app metadata so any change here propagates everywhere.
 */

export const siteConfig = {
  name: "SYNC",
  tagline: "For the vibe coders, To the vibecoders, From a vibe coder",
  description:
    "SYNC is the platform built by vibe coders, for vibe coders. Ship fast. Stay in flow.",
  url: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",
  version: "1.0.0",
} as const;

export type SiteConfig = typeof siteConfig;
