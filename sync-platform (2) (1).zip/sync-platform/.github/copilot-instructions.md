<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# SYNC — Copilot Instructions

## Project Overview
SYNC is a production-ready Next.js 14 application using the **App Router**, **TypeScript**, and **TailwindCSS v4**.

## Architecture
- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript (strict mode)
- **Styling**: TailwindCSS v4 with custom design tokens
- **Structure**: `src/` directory layout

## Folder Structure
```
src/
├── app/              # Next.js App Router pages & layouts
├── components/
│   ├── sections/     # Full-page landing sections (Hero, Features, etc.)
│   └── ui/           # Reusable atomic components (Button, Section, etc.)
├── config/           # App-wide configuration (site.ts)
├── lib/              # Service utilities (api.ts, utils.ts)
└── types/            # Shared TypeScript types (index.ts)
```

## Design Tokens
- **Primary**: `#22c55e` (light green) — use `text-primary`, `bg-primary`
- **Background**: `#000000` (black) — use `bg-black`
- **Text**: `#ffffff` (white) — use `text-white`
- **Secondary**: `#9ca3af` (grey) — use `text-secondary`

## Code Guidelines
1. **Server Components by default** — only add `"use client"` when using hooks or browser APIs.
2. **Absolute imports** using `@/` alias (configured in `tsconfig.json`).
3. **`cn()` utility** from `@/lib/utils` for conditional className merging.
4. **`siteConfig`** from `@/config/site` for all app metadata constants.
5. **`api`** from `@/lib/api` for all HTTP requests.
6. **Shared types** live in `@/types/index.ts`.
7. Keep components modular — one responsibility per file.
8. Prefer semantic HTML elements (`<section>`, `<nav>`, `<article>`, etc.).
9. All interactive elements must be keyboard-accessible.
10. Never hardcode colours — use Tailwind design token classes.
